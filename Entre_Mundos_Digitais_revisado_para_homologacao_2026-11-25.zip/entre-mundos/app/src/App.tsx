import { lazy, Suspense } from "react";
import { Routes, Route } from "react-router";

const Home = lazy(() => import("./pages/Home"));
const TeamPage = lazy(() => import("./pages/TeamPage"));
const ProjectionPage = lazy(() => import("./pages/ProjectionPage"));
const MediatorPage = lazy(() => import("./pages/MediatorPage"));
const ResearchPage = lazy(() => import("./pages/ResearchPage"));
const Login = lazy(() => import("./pages/Login"));
const NotFound = lazy(() => import("./pages/NotFound"));

export default function App() {
  return <Suspense fallback={<main className="loading-page" id="conteudo"><span className="loader-orbit" /><p>Abrindo este mundo…</p></main>}>
    <a className="skip-link" href="#conteudo">Saltar para o conteúdo principal</a>
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/dupla/:code?" element={<TeamPage />} />
      <Route path="/projecao/:code" element={<ProjectionPage />} />
      <Route path="/mediador/:code?" element={<MediatorPage />} />
      <Route path="/pesquisa" element={<ResearchPage />} />
      <Route path="/login" element={<Login />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  </Suspense>;
}
