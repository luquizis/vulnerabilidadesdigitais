import { useCallback, useEffect, useMemo, useState } from "react";
import { useParams } from "react-router";
import QRCode from "qrcode";
import { Check, Copy, Expand, Eye, EyeOff, Map, MessageCircle, Radio, UsersRound } from "lucide-react";
import { phaseById, phases, stopById } from "@contracts/game";
import { trpc } from "@/lib/trpc";
import { AvatarGlyph } from "@/components/game/AvatarGlyph";
import { Brand } from "@/components/game/Brand";
import { PhaseIcon } from "@/components/game/PhaseIcon";
import { useRealtime } from "@/hooks/useRealtime";

function CollectiveRadar({ values }: { values: number[] }) {
  const center = 150; const radius = 105;
  const point = (index: number, scale: number) => { const angle = -Math.PI / 2 + index * Math.PI * 2 / 5; return `${center + Math.cos(angle) * radius * scale},${center + Math.sin(angle) * radius * scale}`; };
  const polygon = (scale: number) => Array.from({ length: 5 }, (_, index) => point(index, scale)).join(" ");
  const max = Math.max(1, ...values); const points = values.map((value, index) => point(index, 0.18 + 0.82 * value / max)).join(" ");
  return <svg className="radar-chart" viewBox="0 0 300 300" role="img" aria-label="Radar coletivo das respostas protetivas, sem ranking entre duplas">
    {[0.25, 0.5, 0.75, 1].map((scale) => <polygon key={scale} points={polygon(scale)} fill="none" stroke="currentColor" opacity="0.22" />)}
    {Array.from({ length: 5 }, (_, index) => <line key={index} x1={center} y1={center} x2={point(index, 1).split(",")[0]} y2={point(index, 1).split(",")[1]} stroke="currentColor" opacity="0.22" />)}
    <polygon points={points} fill="#54C7AE" fillOpacity="0.24" stroke="#54C7AE" strokeWidth="3" />
    {values.map((value, index) => { const [cx, cy] = point(index, 0.18 + 0.82 * value / max).split(","); return <circle key={index} cx={cx} cy={cy} r="5" fill="#E3B95C" />; })}
  </svg>;
}

export default function ProjectionPage() {
  const { code = "" } = useParams(); const normalized = code.toUpperCase(); const utils = trpc.useUtils();
  const projection = trpc.game.projection.useQuery({ code: normalized }, { enabled: Boolean(normalized), refetchInterval: 30000 });
  const update = useCallback(() => { void utils.game.projection.invalidate(); }, [utils]);
  const connection = useRealtime(normalized, update);
  const [qr, setQr] = useState(""); const [copied, setCopied] = useState(false);
  useEffect(() => { const url = `${window.location.origin}/dupla/${normalized}`; void QRCode.toDataURL(url, { width: 360, margin: 2, color: { dark: "#14172B", light: "#F7F4EE" } }).then(setQr); }, [normalized]);
  const data = projection.data; const stop = data?.stop || null;
  const phase = stop ? phaseById[stop.phase] : null;
  const protectionIds = ["ontovuldig:MC5_Resiliencia", "ontovuldig:MC5_Transparencia", "ontovuldig:MC5_Participacao", "ontovuldig:MC5_Procedimentais", "ontovuldig:MC5_Reparacao_Coletiva"];
  const radar = protectionIds.map((id) => data?.responses.filter((response) => response.ontoResponse === id).length || 0);
  const choiceStats = useMemo(() => stop?.choices.map((choice) => ({ ...choice, count: data?.responses.filter((response) => response.choiceId === choice.id).length || 0 })) || [], [stop, data]);
  async function copyCode() { await navigator.clipboard.writeText(normalized); setCopied(true); setTimeout(() => setCopied(false), 1500); }
  async function fullScreen() { if (!document.fullscreenElement) await document.documentElement.requestFullscreen(); else await document.exitFullscreen(); }

  if (projection.isLoading) return <main className="projection-loading" id="conteudo"><span className="loader-orbit" /><p>Conectando o mapa coletivo…</p></main>;
  if (!data) return <main className="projection-loading" id="conteudo"><h1>Projeção não encontrada</h1><p>Confiram o código da sessão.</p></main>;
  const modeLabel = data.session.visibility === "reserved" ? "Mapa" : data.session.visibility === "debate" ? "Debate" : "Mural";
  const connectionLabel = connection === "sse" ? "tempo real" : connection === "polling" ? "consulta periódica" : "sem conexão";
  return <div className={`projection-shell projection-mode--${data.session.visibility}`}>
    <p className="sr-only" aria-live="polite">{stop ? `Parada projetada: ${stop.title}. Modo ${modeLabel}.` : "Aguardando o início da sessão."}</p>
    <header className="projection-header"><Brand inverse /><div className="projection-title"><span>PROJEÇÃO COLETIVA</span><strong>{data.session.title}</strong></div><div className="live-status"><Radio size={16} /><span>{connectionLabel}</span></div><button className="icon-button icon-button--dark" onClick={() => void fullScreen()} aria-label="Alternar tela cheia"><Expand /></button></header>
    <main className="projection-main" id="conteudo">
      <aside className="projection-sidebar">
        <div className="qr-block">{qr && <img src={qr} alt={`QR Code para entrar na sessão ${normalized}`} />}<div><small>ENTRE EM DUPLA</small><button onClick={() => void copyCode()}>{normalized}{copied ? <Check size={18} /> : <Copy size={18} />}</button><span>Apontem a câmera ou usem o código</span></div></div>
        <div className="projection-teams-heading"><UsersRound size={19} /><strong>{data.teams.length} duplas conectadas</strong></div>
        <div className="projection-team-list">{data.teams.map((team) => <div key={team.id}><AvatarGlyph id={team.avatarId} size={42} /><p><strong>{team.name}</strong><small>{team.currentStopId === "finished" ? "Síntese concluída" : stopById[team.currentStopId]?.title || "Escolhendo avatar"}</small></p></div>)}</div>
        <p className="privacy-reminder"><EyeOff size={16} /> Experiências pessoais nunca aparecem nesta tela.</p>
      </aside>

      <section className="projection-stage">
        {stop && phase ? <>
          <div className="projection-phase"><span style={{ color: phase.lightColor }}><PhaseIcon phase={phase.id} size={36} /></span><p>FASE {phase.number} · {phase.title}</p><div className={`visibility-badge visibility-badge--${data.session.visibility}`}>{data.session.visibility === "reserved" ? <Map /> : data.session.visibility === "debate" ? <MessageCircle /> : <Eye />}{modeLabel}</div></div>
          <div className="projection-case"><p className="eyebrow" style={{ color: phase.lightColor }}>{stop.kicker}</p><h1>{stop.title}</h1><p>{stop.scenario}</p></div>
          {data.session.visibility === "reserved" && <div className="projection-transit-map" aria-label="Distribuição agregada das duplas pelas fases">{phases.map((item, index) => {
            const count = data.teams.filter((team) => team.currentStopId !== "finished" && stopById[team.currentStopId]?.phase === item.id).length;
            return <div key={item.id} className={item.id === phase.id ? "is-current" : ""} style={{ "--phase-light": item.lightColor } as React.CSSProperties}><span className="transit-node"><PhaseIcon phase={item.id} size={40} /></span><strong>{item.title.replace("Vulnerabilidade ", "")}</strong><small>{count} {count === 1 ? "dupla" : "duplas"} neste trecho</small>{index < phases.length - 1 && <i aria-hidden="true" />}</div>;
          })}</div>}
          {data.session.visibility !== "reserved" && <div className="projection-choice-stats">{choiceStats.map((choice, index) => <div key={choice.id}><span>0{index + 1}</span><p><strong>{choice.label}</strong><small>{choice.protection}</small></p><div className="choice-bar"><i style={{ width: `${data.answerCount ? Math.max(4, choice.count / data.answerCount * 100) : 4}%`, background: phase.lightColor }} /></div><b>{choice.count}</b></div>)}</div>}
          {data.session.visibility === "debate" && <div className="projection-debate"><MessageCircle size={28} /><div><small>PERGUNTA PARA A TURMA</small><strong>{stop.debate}</strong></div><span>{data.answerCount}/{data.teams.length} respostas</span></div>}
        </> : <div className="projection-waiting"><span className="pulse-dot" /><p className="eyebrow">O mapa está aberto</p><h1>Esperando as duplas <br />atravessarem o portal.</h1><p>O mediador iniciará a primeira parada.</p></div>}
      </section>

      <aside className="collective-panel">
        <div className="collective-heading"><p className="eyebrow">Radar de proteção</p><span>Não é ranking</span></div>
        <CollectiveRadar values={radar} />
        <div className="radar-labels">{["Resiliência", "Transparência", "Participação", "Procedimentos", "Reparação"].map((label, index) => <div key={label}><span>{label}</span><strong>{data.session.visibility === "reserved" ? "—" : radar[index]}</strong></div>)}</div>
        {data.session.visibility !== "reserved" && <div className="projection-text-stream"><p className="eyebrow">Vozes autorizadas e moderadas</p>{data.responses.filter((response) => response.justification || response.contestation || response.candidateConcept).slice(0, 4).map((response) => <blockquote key={response.id}><span>Voz da turma · sem identificar a dupla</span><p>{response.contestation || response.justification || `Conceito candidato: ${response.candidateConcept}`}</p></blockquote>)}{!data.responses.some((response) => response.justification || response.contestation || response.candidateConcept) && <p className="empty-voices">Os textos aprovados pelo mediador aparecem aqui.</p>}</div>}
        {stop?.privacyChain.length ? <div className="privacy-chain"><small>CADEIA DE PRIVACIDADE PARA INVESTIGAR</small>{stop.privacyChain.map((item) => <span key={item}>{item.split(":").pop()}</span>)}</div> : null}
      </aside>
    </main>
    <footer className="projection-footer"><span>Vulnerabilidade é relacional, situacional e em camadas.</span><strong>Nenhuma dupla vence sozinha.</strong></footer>
  </div>;
}
