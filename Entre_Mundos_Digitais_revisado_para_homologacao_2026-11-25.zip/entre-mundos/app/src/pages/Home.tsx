import { joinTokenFor } from "@/lib/team-access";
import { useState } from "react";
import type { FormEvent } from "react";
import { Link, useNavigate } from "react-router";
import { ArrowRight, BookOpen, Monitor, ShieldCheck, UsersRound } from "lucide-react";
import { phases } from "@contracts/game";
import { trpc } from "@/lib/trpc";
import { CyberWorld } from "@/components/game/CyberWorld";
import { GameHeader } from "@/components/game/Brand";
import { useAuth } from "@/hooks/useAuth";

export default function Home() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [code, setCode] = useState("");
  const [title, setTitle] = useState("Turma entre mundos");
  const [error, setError] = useState("");
  const join = trpc.game.join.useMutation();
  const create = trpc.game.createSession.useMutation();

  async function joinSession(event: FormEvent) {
    event.preventDefault(); setError("");
    try {
      const normalized = code.trim().toUpperCase();
      const result = await join.mutateAsync({ code: normalized, joinToken: joinTokenFor(normalized) });
      localStorage.setItem(`emd_pair_${normalized}`, result.token);
      navigate(`/dupla/${normalized}`);
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Não foi possível entrar."); }
  }
  async function createSession(event: FormEvent) {
    event.preventDefault(); setError("");
    try {
      const result = await create.mutateAsync({ title });
      localStorage.setItem(`emd_mediator_${result.code}`, result.key);
      navigate(`/mediador/${result.code}`);
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Não foi possível criar a sessão."); }
  }

  return <div className="home-shell">
    <GameHeader inverse />
    <main id="conteudo">
      <section className="hero">
        <div className="hero-copy">
          <p className="eyebrow"><span /> RPG cooperativo · pesquisa · cidadania digital</p>
          <h1>Toda escolha abre <br />um <em>outro mundo.</em></h1>
          <p className="hero-lead">Uma jornada em duplas para investigar como contextos, plataformas e instituições produzem vulnerabilidades — e como podemos construir proteção em conjunto.</p>
          <div className="join-panel">
            <form onSubmit={joinSession}>
              <label htmlFor="session-code">Código da sessão</label>
              <div className="code-entry">
                <input id="session-code" value={code} onChange={(event) => setCode(event.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ""))} placeholder="ABC123" maxLength={8} autoComplete="off" required />
                <button className="button button--primary" type="submit" disabled={join.isPending}>{join.isPending ? "Entrando…" : "Entrar em dupla"}<ArrowRight size={18} /></button>
              </div>
              <small>Sem cadastro, nome real ou instalação de aplicativo.</small>
            </form>
            {error && <p className="form-error" role="alert">{error}</p>}
          </div>
          <div className="secondary-access">
            <Link to="/pesquisa"><BookOpen size={17} /> Área do pesquisador</Link>
            <span>ou</span>
            <a href="#criar-sessao">Criar sessão de mediação</a>
          </div>
        </div>
        <CyberWorld />
      </section>

      <section className="phase-ribbon" aria-label="Fases da jornada">
        {phases.map((phase) => <div key={phase.id}><span style={{ background: phase.color }}>{phase.short}</span><p><strong>{phase.title}</strong><small>{phase.principle}</small></p></div>)}
      </section>

      <section className="manifesto-grid">
        <div><p className="eyebrow">A bússola do jogo</p><h2>Vulnerável não é <br />uma etiqueta.</h2></div>
        <div className="manifesto-copy"><p>É uma relação que muda conforme o contexto, as camadas acumuladas e as decisões institucionais.</p><p>Por isso, o jogo não ranqueia pessoas ou grupos. As duplas podem contestar a taxonomia, dizer “não sei” e propor novos conceitos.</p></div>
        <div className="manifesto-note"><ShieldCheck size={28} /><strong>Imunidade não é pontuação.</strong><span>É a soma de proteções construídas durante a travessia.</span></div>
      </section>

      <section className="access-section" id="criar-sessao">
        <div className="access-intro"><p className="eyebrow">Para conduzir a experiência</p><h2>Uma tela para a turma. <br />Um mundo em cada dupla.</h2><p>O mediador controla o ritmo e a visibilidade. A projeção mostra somente escolhas autorizadas e textos aprovados.</p></div>
        <form className="create-form" onSubmit={createSession}>
          <Monitor size={28} />
          <label htmlFor="session-title">Nome da turma ou sessão</label>
          <input id="session-title" value={title} onChange={(event) => setTitle(event.target.value)} minLength={3} maxLength={120} required />
          {user?.role === "admin" ? <button className="button button--light" disabled={create.isPending}>{create.isPending ? "Preparando…" : "Criar sessão e QR Code"}<ArrowRight size={18} /></button> : <Link className="button button--light" to="/login">Entrar com uma conta administradora</Link>}
          <small>Um administrador cria a sessão e recebe a chave exclusiva de mediação.</small>
        </form>
        <div className="access-facts"><div><UsersRound /><strong>Em duplas</strong><span>Conversem antes de escolher.</span></div><div><Monitor /><strong>Em tempo real</strong><span>O mapa coletivo ganha forma.</span></div></div>
      </section>
    </main>
    <footer className="home-footer"><span>Entre Mundos Digitais · protótipo educacional e de pesquisa</span><span>Não solicite nem compartilhe dados pessoais nas respostas.</span></footer>
  </div>;
}
