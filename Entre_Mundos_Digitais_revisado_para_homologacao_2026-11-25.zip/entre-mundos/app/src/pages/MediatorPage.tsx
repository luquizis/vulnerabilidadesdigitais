import { useAuth } from "@/hooks/useAuth";
import { useCallback, useEffect, useState } from "react";
import type { FormEvent } from "react";
import { Link, useNavigate, useParams } from "react-router";
import QRCode from "qrcode";
import { ArrowRight, Check, Copy, ExternalLink, Eye, EyeOff, Flag, KeyRound, ListChecks, Map, MessageCircle, Play, ShieldCheck, Square, UsersRound, X } from "lucide-react";
import { optionSets } from "@contracts/game";
import { trpc } from "@/lib/trpc";
import { AvatarGlyph } from "@/components/game/AvatarGlyph";
import { GameHeader } from "@/components/game/Brand";
import { useRealtime } from "@/hooks/useRealtime";

const sourceLabel = (id: string | null) => id ? optionSets.source.find(([, value]) => value === id)?.[0] || id.split(":").pop()?.replaceAll("_", " ") : "Parada pulada";

export default function MediatorPage() {
  const { user } = useAuth();
  const params = useParams(); const navigate = useNavigate();
  const [code, setCode] = useState((params.code || "").toUpperCase());
  const [key, setKey] = useState(() => localStorage.getItem(`emd_mediator_${(params.code || "").toUpperCase()}`) || "");
  const [error, setError] = useState(""); const [qr, setQr] = useState(""); const [copied, setCopied] = useState(false);
  const [selected, setSelected] = useState<number[]>([]); const [queueFilter, setQueueFilter] = useState<"all" | "careful" | "projectable">("all");
  // Relógio com atualização periódica: o render não chama Date.now diretamente.
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => { const timer = setInterval(() => setNow(Date.now()), 30000); return () => clearInterval(timer); }, []);
  const utils = trpc.useUtils();
  const dashboard = trpc.game.moderator.useQuery({ code, key }, { enabled: Boolean(code && key), retry: false });
  const registration = trpc.game.setRegistration.useMutation();
  const start = trpc.game.start.useMutation(); const visibility = trpc.game.setVisibility.useMutation(); const setStop = trpc.game.setStop.useMutation();
  const moderate = trpc.game.moderate.useMutation(); const moderateBatch = trpc.game.moderateBatch.useMutation(); const finish = trpc.game.finish.useMutation(); const create = trpc.game.createSession.useMutation();
  const update = useCallback(() => { void utils.game.moderator.invalidate(); }, [utils]);
  useRealtime(code, update, "mediator", key);
  useEffect(() => { if (code) void QRCode.toDataURL(`${window.location.origin}/dupla/${code}`, { width: 280, margin: 2 }).then(setQr); }, [code]);
  async function action(callback: () => Promise<unknown>) { setError(""); try { await callback(); await update(); } catch (cause) { setError(cause instanceof Error ? cause.message : "A ação não foi concluída."); } }

  function access(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); const data = new FormData(event.currentTarget); const nextCode = String(data.get("code") || "").toUpperCase(); const nextKey = String(data.get("key") || "");
    localStorage.setItem(`emd_mediator_${nextCode}`, nextKey); setCode(nextCode); setKey(nextKey); navigate(`/mediador/${nextCode}`);
  }
  async function newSession(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); const data = new FormData(event.currentTarget);
    try { const result = await create.mutateAsync({ title: String(data.get("title")) }); localStorage.setItem(`emd_mediator_${result.code}`, result.key); setCode(result.code); setKey(result.key); navigate(`/mediador/${result.code}`); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "Não foi possível criar a sessão."); }
  }

  if (!code || !key || dashboard.error) return <div className="moderator-entry"><GameHeader /><main id="conteudo"><section><p className="eyebrow">Console do mediador</p><h1>A turma no mesmo ritmo. <br />Cada dupla no seu tempo.</h1><p>Abram uma sessão para gerar o QR Code e controlar o que pode ser projetado. A chave de mediação é separada do código dos estudantes.</p><div className="mediator-ethics"><ShieldCheck size={24} /><span>Antes de iniciar, confirmem consentimento/assentimento e combinem que ninguém precisa contar experiências pessoais.</span></div><details className="preclass-guide"><summary>Roteiro antes da aula</summary><ol><li>Criem a sessão e testem a rede e a projeção.</li><li>Imprimam ou projetem o QR Code.</li><li>Confirmem a entrada e os avatares das duplas.</li><li>Durante a atividade, acompanhem a fila e abram o debate quando fizer sentido.</li></ol></details></section><div className="mediator-entry-forms"><form onSubmit={newSession}><Play size={24} /><h2>Criar nova sessão</h2><label>Nome da turma<input name="title" defaultValue="Turma entre mundos" minLength={3} required /></label>{user?.role === "admin" ? <button className="button button--primary" disabled={create.isPending}>Criar sessão <ArrowRight size={18} /></button> : <Link className="button button--primary" to="/login">Entrar com uma conta administradora</Link>}</form><div className="form-divider">ou retomar</div><form onSubmit={access}><KeyRound size={24} /><h2>Acessar sessão</h2><label>Código<input name="code" defaultValue={code} maxLength={8} required /></label><label>Chave de mediação<input name="key" type="password" defaultValue={key} required /></label><button className="button button--outline">Abrir console</button></form>{(error || dashboard.error) && <p className="form-error">{error || dashboard.error?.message}</p>}</div></main></div>;
  if (dashboard.isLoading || !dashboard.data) return <main className="loading-page" id="conteudo"><span className="loader-orbit" /><p>Preparando o console…</p></main>;
  const data = dashboard.data;
  const { phases, stops } = data.content;
  const stopById = Object.fromEntries(stops.map((stop) => [stop.id, stop]));
  const pending = data.responses.filter((response) => response.moderationStatus === "pending");
  const filteredPending = pending.filter((response) => queueFilter === "careful" ? response.needsCarefulReview : queueFilter === "projectable" ? response.allowProjection : true);
  const allFilteredSelected = filteredPending.length > 0 && filteredPending.every((response) => selected.includes(response.id));
  function toggleAll() { setSelected((current) => allFilteredSelected ? current.filter((id) => !filteredPending.some((response) => response.id === id)) : Array.from(new Set([...current, ...filteredPending.map((response) => response.id)]))); }
  async function batch(decision: "approved" | "rejected") {
    const ids = selected.filter((id) => pending.some((response) => response.id === id));
    if (!ids.length) return;
    await action(async () => { for (let i = 0; i < ids.length; i += 40) await moderateBatch.mutateAsync({ code, key, responseIds: ids.slice(i, i + 40), decision }); }); setSelected([]);
  }

  return <div className="moderator-shell"><GameHeader /><main className="moderator-main" id="conteudo">
    <div className="moderator-title"><div><p className="eyebrow">Console do mediador · {data.session.code}</p><h1>{data.session.title}</h1></div><Link className="button button--outline" to={`/projecao/${data.session.code}`} target="_blank">Abrir projeção <ExternalLink size={17} /></Link></div>
    {error && <p className="form-error" role="alert">{error}</p>}
    <section className="moderator-overview">
      <div className="session-ticket"><div className="ticket-qr">{qr && <img src={qr} alt="QR Code de entrada das duplas" />}</div><div><small>CÓDIGO DAS DUPLAS</small><button onClick={() => { void navigator.clipboard.writeText(data.session.code); setCopied(true); setTimeout(() => setCopied(false), 1200); }}>{data.session.code}{copied ? <Check /> : <Copy />}</button><span>{data.teams.length} duplas inscritas</span><details><summary>Ver chave de mediação</summary><code>{key}</code></details></div></div>
      <div className="moderator-controls">{(data.session.status === "lobby" || data.session.status === "closed") && <div className="control-row"><span>{data.teams.length}/{data.session.capacity} duplas · inscrições {data.session.registrationOpen ? "abertas" : "encerradas"}</span><button className="button button--outline" disabled={registration.isPending} onClick={() => void action(() => registration.mutateAsync({ code, key, open: !data.session.registrationOpen }))}>{data.session.registrationOpen ? "Encerrar inscrições" : "Abrir inscrições"}</button></div>}<div className="control-row"><div><small>RITMO DA SESSÃO</small><strong>{(data.session.status === "lobby" || data.session.status === "closed") ? "Aguardando início" : data.session.status === "active" ? "Em andamento" : "Encerrada"}</strong></div>{(data.session.status === "lobby" || data.session.status === "closed") ? <button className="button button--primary" onClick={() => void action(() => start.mutateAsync({ code, key }))}><Play size={17} /> Iniciar travessia</button> : <button className="button button--outline" onClick={() => { if (window.confirm("Encerrar a sessão e abrir a síntese final na projeção?")) void action(() => finish.mutateAsync({ code, key })); }}><Square size={16} /> Encerrar</button>}</div><div className="control-row control-row--stack"><small>MODO DA PROJEÇÃO</small><div className="segmented-control">{([{ id: "reserved", label: "Mapa", icon: Map }, { id: "open", label: "Mural", icon: Eye }, { id: "debate", label: "Debate", icon: MessageCircle }] as const).map((item) => <button key={item.id} className={data.session.visibility === item.id ? "is-active" : ""} onClick={() => void action(() => visibility.mutateAsync({ code, key, visibility: item.id }))}><item.icon size={16} />{item.label}</button>)}</div></div><label className="stop-control">PARADA PROJETADA<select value={data.session.currentStopId || ""} onChange={(event) => void action(() => setStop.mutateAsync({ code, key, stopId: event.target.value }))}><option value="" disabled>Escolha uma parada</option>{phases.map((phase) => <optgroup key={phase.id} label={phase.title}>{stops.filter((stop) => stop.phase === phase.id).map((stop) => <option key={stop.id} value={stop.id}>{stop.title}</option>)}</optgroup>)}</select></label></div>
    </section>
    <div className="moderator-columns">
      <section className="moderator-teams"><div className="section-heading"><UsersRound /><h2>Andamento por parada</h2><span>{data.teams.length}</span></div>{data.teams.length === 0 && <p className="empty-state">Compartilhem o QR Code. As duplas aparecerão aqui ao entrar.</p>}<div>{data.teams.map((team) => <article key={team.id}><AvatarGlyph id={team.avatarId} size={48} /><div><strong>{team.name}</strong><small>{team.lastSeenAt && now - new Date(team.lastSeenAt).getTime() < 60000 ? "Atividade recente" : "Sem contato recente"}</small><span>{team.currentStopId === "finished" ? "Síntese concluída" : stopById[team.currentStopId]?.title || "Escolhendo avatar"}</span><div className="team-track"><i style={{ width: `${Math.min(100, team.completed / 9 * 100)}%` }} /></div></div><span className="layer-count"><ShieldCheck size={15} />{team.immunity}</span></article>)}</div></section>
      <section className="moderation-queue"><div className="section-heading"><MessageCircle /><h2>Fila de moderação</h2><span>{pending.length}</span></div><p>Somente textos abertos aguardam revisão. Experiências pessoais não aparecem neste painel.</p>
        {pending.length > 0 && <div className="batch-toolbar"><div className="queue-filters" aria-label="Filtrar fila">{([{ id: "all", label: "Todos" }, { id: "careful", label: "Com sinal" }, { id: "projectable", label: "Autorizados" }] as const).map((item) => <button key={item.id} className={queueFilter === item.id ? "is-active" : ""} onClick={() => setQueueFilter(item.id)}>{item.label}</button>)}</div><label className="select-all"><input type="checkbox" checked={allFilteredSelected} onChange={toggleAll} />Selecionar filtrados</label><div className="batch-actions"><button disabled={!selected.length || moderateBatch.isPending} onClick={() => void batch("approved")}><Check size={15} />Aprovar selecionados ({selected.length})</button><button disabled={!selected.length || moderateBatch.isPending} onClick={() => void batch("rejected")}><X size={15} />Não projetar</button></div></div>}
        {filteredPending.length === 0 && <p className="empty-state"><ListChecks size={20} /> Nenhum texto nesta visão da fila.</p>}
        {filteredPending.map((response) => <article key={response.id} className={selected.includes(response.id) ? "is-selected" : ""}><label className="moderation-select"><input type="checkbox" checked={selected.includes(response.id)} onChange={() => setSelected((current) => current.includes(response.id) ? current.filter((id) => id !== response.id) : [...current, response.id])} /><span className="sr-only">Selecionar texto para moderação em lote</span></label><div className="moderation-content"><div className="moderation-meta"><strong>{data.teams.find((team) => team.id === response.teamId)?.name}</strong><span>{stopById[response.stopId]?.title}</span>{!response.allowProjection && <em><EyeOff size={13} /> não projetar</em>}{response.needsCarefulReview && <em className="warning"><Flag size={13} /> revisar com cuidado</em>}</div>{response.hiddenFactor && <p><small>FATOR INVISÍVEL</small>{response.hiddenFactor}</p>}{response.justification && <p><small>JUSTIFICATIVA</small>{response.justification}</p>}{response.contestation && <p><small>CONTESTAÇÃO</small>{response.contestation}</p>}{response.candidateConcept && <p><small>CONCEITO CANDIDATO</small>{response.candidateConcept}</p>}<div className="moderation-actions"><button onClick={() => void action(() => moderate.mutateAsync({ code, key, responseId: response.id, decision: "approved" }))}><Check size={16} /> Aprovar texto</button><button onClick={() => void action(() => moderate.mutateAsync({ code, key, responseId: response.id, decision: "rejected" }))}><X size={16} /> Não projetar</button><button onClick={() => void action(() => moderate.mutateAsync({ code, key, responseId: response.id, decision: "revision_requested", note: "Solicitar ajuste com o mediador antes de autorizar a publicação." }))}>Solicitar ajuste</button></div></div></article>)}
      </section>
    </div>
    <section className="recent-responses"><div className="section-heading"><h2>Pulso da sessão</h2><span>{data.responses.length} registros recentes</span></div><div className="response-table-wrap"><table><thead><tr><th>Dupla</th><th>Parada</th><th>Leitura de origem</th><th>Projeção</th><th>Moderação</th></tr></thead><tbody>{data.responses.slice(0, 12).map((response) => <tr key={response.id}><td>{data.teams.find((team) => team.id === response.teamId)?.name}</td><td>{stopById[response.stopId]?.title}</td><td>{sourceLabel(response.sourceClassification)}</td><td>{response.allowProjection ? "Autorizada" : "Reservada"}</td><td>{response.moderationStatus === "approved" && <button onClick={() => void action(() => moderate.mutateAsync({ code, key, responseId: response.id, decision: "hidden" }))}>Ocultar texto</button>}{response.moderationStatus === "revision_requested" ? "Ajuste solicitado" : response.moderationStatus === "hidden" ? "Texto oculto" : response.moderationStatus === "pending" ? "Aguardando" : response.moderationStatus === "approved" ? "Texto aprovado" : response.moderationStatus === "rejected" ? "Texto recusado" : "Só escolhas"}</td></tr>)}</tbody></table></div></section>
  </main></div>;
}
