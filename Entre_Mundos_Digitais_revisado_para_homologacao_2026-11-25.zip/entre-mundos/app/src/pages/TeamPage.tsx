import { joinTokenFor } from "@/lib/team-access";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { FormEvent } from "react";
import type { inferRouterOutputs } from "@trpc/server";
import type { AppRouter } from "../../api/router";
import { Link, useNavigate, useParams } from "react-router";
import { ArrowLeft, ArrowRight, Check, EyeOff, HelpCircle, RefreshCw, ShieldCheck, Volume2, VolumeX, WifiOff } from "lucide-react";
import { hateDimensions as initialHateDimensions, optionSets as initialOptionSets, phaseById, phases as initialPhases, privacyGroups as initialPrivacyGroups } from "@contracts/game";
import { trpc } from "@/lib/trpc";
import { AvatarGlyph } from "@/components/game/AvatarGlyph";
import { AvatarPicker } from "@/components/game/AvatarPicker";
import { Brand } from "@/components/game/Brand";
import { PhaseIcon } from "@/components/game/PhaseIcon";
import { useRealtime } from "@/hooks/useRealtime";
import { clearDraft, enqueueSubmission, loadDraft, pendingSubmissions, removeQueuedSubmission, saveDraft } from "@/lib/offline";

type FormState = {
  choiceId: string; sourceClassification: string; ontoType: string; ontoIntensity: string; ontoScale: string; ontoOrigin: string;
  ontoManifestation: string; ontoVisibility: string; ontoObstacle: string; ontoResponse: string; privacyProblems: string[];
  hiddenFactor: string; hiddenFactorUnknown: boolean; hateMapping: "exact" | "close" | "related" | "none"; hateDimensions: string[];
  experience: "vivenciada" | "observada" | "conhecida" | "imaginada" | "nao_informar"; justification: string; contestation: string;
  candidateConcept: string; allowProjection: boolean; contributionKind: "agreement" | "contestation" | "proposal" | "unspecified";
};
type StepId = "reading" | "choice" | "classification" | "privacy" | "experience" | "hidden" | "review";
type DraftEnvelope = { form: FormState; step: StepId; classificationIndex: number };
type ClassificationKey = "sourceClassification" | "ontoType" | "ontoIntensity" | "ontoScale" | "ontoOrigin" | "ontoManifestation" | "ontoVisibility" | "ontoObstacle" | "ontoResponse";
type GameStateData = inferRouterOutputs<AppRouter>["game"]["state"];

const emptyForm: FormState = { choiceId: "", sourceClassification: "", ontoType: "", ontoIntensity: "", ontoScale: "", ontoOrigin: "", ontoManifestation: "", ontoVisibility: "", ontoObstacle: "", ontoResponse: "", privacyProblems: [], hiddenFactor: "", hiddenFactorUnknown: false, hateMapping: "none", hateDimensions: [], experience: "nao_informar", justification: "", contestation: "", candidateConcept: "", allowProjection: true, contributionKind: "unspecified" };
const initialClassificationFields: { key: ClassificationKey; label: string; prompt: string; options: readonly (readonly [string, string])[] }[] = [
  { key: "sourceClassification", label: "Origem da vulnerabilidade", prompt: "De onde vem principalmente esta vulnerabilidade?", options: initialOptionSets.source },
  { key: "ontoType", label: "MC1 · Tipo", prompt: "Ela aparece na decisão ou no resultado?", options: initialOptionSets.type },
  { key: "ontoIntensity", label: "MC1 · Intensidade", prompt: "Como as camadas se apresentam?", options: initialOptionSets.intensity },
  { key: "ontoScale", label: "MC1 · Escala", prompt: "Quem é alcançado nesta situação?", options: initialOptionSets.scale },
  { key: "ontoOrigin", label: "MC2 · Origem", prompt: "Qual origem melhor descreve a relação investigada?", options: initialOptionSets.origin },
  { key: "ontoManifestation", label: "MC3 · Manifestação", prompt: "O que a dupla consegue identificar: risco ou dano?", options: initialOptionSets.manifestation },
  { key: "ontoVisibility", label: "MC3 · Visibilidade", prompt: "Quanto dessa relação aparece na interface ou no caso?", options: initialOptionSets.visibility },
  { key: "ontoObstacle", label: "MC4 · Obstáculo", prompt: "Que obstáculo dificulta reconhecer ou reparar o problema?", options: initialOptionSets.obstacle },
  { key: "ontoResponse", label: "MC5 · Resposta protetiva", prompt: "Que resposta coletiva pode ampliar a proteção?", options: initialOptionSets.response },
];
const stepLabels: Record<StepId, string> = { reading: "Leitura", choice: "Travessia", classification: "Classificação", privacy: "Privacidade", experience: "Experiência", hidden: "Fator oculto", review: "Revisão" };

function FieldSelect({ label, value, options, onChange }: { label: string; value: string; options: readonly (readonly [string, string])[]; onChange: (value: string) => void }) {
  return <label className="field-select progressive-select"><span>{label}</span><select value={value} onChange={(event) => onChange(event.target.value)}><option value="">Selecione uma leitura — inclusive “não sei”</option>{options.map(([text, id]) => <option key={id} value={id}>{text}</option>)}</select></label>;
}
function playConfirmation() {
  try {
    const Audio = window.AudioContext || (window as typeof window & { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const context = new Audio();
    [0, 0.09, 0.18].forEach((delay, index) => {
      const oscillator = context.createOscillator(); const gain = context.createGain();
      oscillator.type = "sine"; oscillator.frequency.value = [440, 554, 659][index];
      gain.gain.setValueAtTime(0.0001, context.currentTime + delay); gain.gain.exponentialRampToValueAtTime(0.055, context.currentTime + delay + 0.02); gain.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + delay + 0.22);
      oscillator.connect(gain); gain.connect(context.destination); oscillator.start(context.currentTime + delay); oscillator.stop(context.currentTime + delay + 0.24);
    });
    setTimeout(() => void context.close(), 700);
  } catch { /* som é opcional */ }
}

export default function TeamPage() {
  const { code = "" } = useParams(); const normalizedCode = code.toUpperCase(); const navigate = useNavigate();
  const [token, setToken] = useState(() => localStorage.getItem(`emd_pair_${normalizedCode}`) || "");
  const [form, setForm] = useState<FormState>(emptyForm); const [loadedKey, setLoadedKey] = useState("");
  const [step, setStep] = useState<StepId>("reading"); const [classificationIndex, setClassificationIndex] = useState(0);
  const [pendingCount, setPendingCount] = useState(0); const [notice, setNotice] = useState(""); const [muted, setMuted] = useState(false); const [speaking, setSpeaking] = useState(false);
  const utils = trpc.useUtils();
  const serverState = trpc.game.state.useQuery({ code: normalizedCode, token }, { enabled: Boolean(token), retry: false });
  const [cachedState, setCachedState] = useState<GameStateData>();
  const cacheKey = normalizedCode + ":state:" + token;
  useEffect(() => {
    let active = true;
    setCachedState(undefined);
    if (token) void loadDraft<GameStateData>(cacheKey).then((value) => { if (active) setCachedState(value); }).catch(() => setNotice("O armazenamento local não está disponível."));
    return () => { active = false; };
  }, [cacheKey, token]);
  useEffect(() => {
    if (serverState.data) { setCachedState(serverState.data); void saveDraft(cacheKey, serverState.data).catch(() => setNotice("Não foi possível manter uma cópia local do percurso.")); }
  }, [serverState.data, cacheKey]);
  const state = { ...serverState, data: serverState.data || cachedState, error: !navigator.onLine && cachedState ? null : serverState.error, isLoading: serverState.isLoading && !cachedState };
  const content = state.data?.content;
  const optionSets = content?.optionSets || initialOptionSets;
  const privacyGroups = content?.privacyGroups || initialPrivacyGroups;
  const hateDimensions = content?.hateDimensions || initialHateDimensions;
  const phases = content?.phases || initialPhases;
  const stopById = Object.fromEntries((content?.stops || []).map((stop) => [stop.id, stop]));
  const axes: Record<ClassificationKey, keyof typeof optionSets> = { sourceClassification: "source", ontoType: "type", ontoIntensity: "intensity", ontoScale: "scale", ontoOrigin: "origin", ontoManifestation: "manifestation", ontoVisibility: "visibility", ontoObstacle: "obstacle", ontoResponse: "response" };
  const classificationFields = initialClassificationFields.map((field) => ({ ...field, options: optionSets[axes[field.key]] }));
  const [lastDecision, setLastDecision] = useState<{ title: string; protection: string; investigation: string } | null>(null);
  const join = trpc.game.join.useMutation(); const avatar = trpc.game.selectAvatar.useMutation(); const randomAvatar = trpc.game.randomAvatar.useMutation(); const submit = trpc.game.submit.useMutation(); const skip = trpc.game.skip.useMutation();
  const invalidate = useCallback(() => { void utils.game.state.invalidate(); }, [utils]);
  const connection = useRealtime(normalizedCode, invalidate, "team", token);
  const stop = state.data?.stop; const phase = stop ? phases.find((item) => item.id === stop.phase) || phaseById[stop.phase] : null;
  const isFinal = stop?.phase === "protection";
  const steps = useMemo<StepId[]>(() => isFinal ? ["reading", "choice", "hidden", "review"] : ["reading", "choice", "classification", "privacy", "experience", "hidden", "review"], [isFinal]);
  const stepIndex = Math.max(0, steps.indexOf(step));
  const draftKey = `${normalizedCode}:${state.data?.team.id || "none"}:${stop?.id || "none"}`;
  type SubmitInput = Parameters<typeof submit.mutateAsync>[0];

  const refreshQueue = useCallback(async () => { setPendingCount((await pendingSubmissions(normalizedCode, token)).length); }, [normalizedCode, token]);
  const flushing = useRef(false);
  const submitRef = useRef(submit.mutateAsync); submitRef.current = submit.mutateAsync;
  const flushQueue = useCallback(async () => {
    if (!navigator.onLine || !token || flushing.current) return;
    flushing.current = true;
    try {
    const queue = await pendingSubmissions(normalizedCode, token);
    for (const item of queue) {
      try { await submitRef.current(item.payload as SubmitInput); if (typeof item.payload.draftKey === "string") { await clearDraft(item.payload.draftKey); await clearDraft(item.payload.draftKey + ":request"); } if (item.id) await removeQueuedSubmission(item.id); }
      catch (cause) { setNotice(cause instanceof Error ? cause.message : "Não foi possível sincronizar. A resposta permanece neste aparelho."); break; }
    }
    await refreshQueue(); await invalidate();
    } finally { flushing.current = false; }
  }, [normalizedCode, token, refreshQueue, invalidate]);
  useEffect(() => { void refreshQueue(); }, [refreshQueue]);
  useEffect(() => { const online = () => { void flushQueue().catch(() => setNotice("Não foi possível ler a fila local.")); }; window.addEventListener("online", online); if (navigator.onLine) void flushQueue().catch(() => setNotice("Não foi possível ler a fila local.")); return () => window.removeEventListener("online", online); }, [flushQueue]);
  useEffect(() => {
    if (!stop) return; setLoadedKey(""); setNotice(""); setClassificationIndex(0); window.speechSynthesis?.cancel(); setSpeaking(false);
    void loadDraft<FormState | DraftEnvelope>(draftKey).then((draft) => {
      if (draft && "form" in draft) {
        setForm({ ...emptyForm, ...draft.form }); setStep(steps.includes(draft.step) ? draft.step : "reading"); setClassificationIndex(Math.min(8, draft.classificationIndex || 0));
      } else { setForm(draft ? { ...emptyForm, ...draft } : { ...emptyForm }); setStep("reading"); }
      setLoadedKey(draftKey);
    });
    // Intencional: o rascunho é recarregado somente quando a parada muda. draftKey
    // incorpora code, equipe e stop.id; incluir stop/steps recriaria o efeito a
    // cada resposta do servidor e sobrescreveria a edição em andamento.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [draftKey]);
  useEffect(() => { if (loadedKey === draftKey && stop) { const timer = setTimeout(() => void saveDraft(draftKey, { form, step, classificationIndex } satisfies DraftEnvelope), 250); return () => clearTimeout(timer); } }, [form, step, classificationIndex, loadedKey, draftKey, stop]);

  async function enter(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); const data = new FormData(event.currentTarget); const enteredCode = String(data.get("code") || "").toUpperCase();
    try { const recoveredToken = String(data.get("recoveryToken") || "").trim(); if (recoveredToken) { await utils.game.resume.fetch({ code: enteredCode, token: recoveredToken }); localStorage.setItem(`emd_pair_${enteredCode}`, recoveredToken); setToken(recoveredToken); navigate(`/dupla/${enteredCode}`); return; } const result = await join.mutateAsync({ code: enteredCode, joinToken: joinTokenFor(enteredCode) }); localStorage.setItem(`emd_pair_${enteredCode}`, result.token); setToken(result.token); navigate(`/dupla/${enteredCode}`); }
    catch (cause) { setNotice(cause instanceof Error ? cause.message : "Não foi possível entrar."); }
  }
  async function chooseAvatar(id: string) { await avatar.mutateAsync({ code: normalizedCode, token, avatarId: id }); await invalidate(); }
  async function balancedRandomAvatar() { await randomAvatar.mutateAsync({ code: normalizedCode, token }); await invalidate(); }
  function update<K extends keyof FormState>(key: K, value: FormState[K]) { setForm((current) => ({ ...current, [key]: value })); }
  function toggleList(key: "privacyProblems" | "hateDimensions", value: string) {
    setForm((current) => {
      if (key === "privacyProblems" && value === "unknown") return { ...current, privacyProblems: current.privacyProblems.includes(value) ? [] : ["unknown"] };
      const withoutUnknown = key === "privacyProblems" ? current.privacyProblems.filter((item) => item !== "unknown") : current[key];
      return { ...current, [key]: withoutUnknown.includes(value) ? withoutUnknown.filter((item) => item !== value) : [...withoutUnknown, value] };
    });
  }
  function moveTo(nextStep: StepId) { setNotice(""); setStep(nextStep); window.scrollTo({ top: 0, behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" }); setTimeout(() => document.getElementById("step-title")?.focus(), 50); }
  function nextStep() {
    if (step === "choice" && !form.choiceId) { setNotice("Escolham uma travessia para continuar. Não há escolha errada."); return; }
    if (step === "classification") {
      if (!form[classificationFields[classificationIndex].key]) { setNotice("Selecionem uma leitura para continuar. “Não sei” é uma resposta válida."); return; }
      if (classificationIndex < classificationFields.length - 1) { setNotice(""); setClassificationIndex((index) => index + 1); setTimeout(() => document.getElementById("step-title")?.focus(), 30); return; }
    }
    if (step === "hidden" && !isFinal && !form.hiddenFactorUnknown && !form.hiddenFactor.trim()) { setNotice("Descrevam uma hipótese ou escolham “Ainda não sabemos identificar”."); return; }
    const next = steps[Math.min(steps.length - 1, stepIndex + 1)]; moveTo(next);
  }
  function previousStep() {
    if (step === "classification" && classificationIndex > 0) { setClassificationIndex((index) => index - 1); setNotice(""); return; }
    moveTo(steps[Math.max(0, stepIndex - 1)]);
  }
  function toggleSpeech() {
    if (!stop || !("speechSynthesis" in window)) return;
    if (speaking) { window.speechSynthesis.cancel(); setSpeaking(false); return; }
    const utterance = new SpeechSynthesisUtterance(`${stop.title}. ${stop.scenario}. Pista para investigar: ${stop.investigation}`);
    utterance.lang = "pt-BR"; utterance.rate = 0.95; utterance.onend = () => setSpeaking(false); utterance.onerror = () => setSpeaking(false);
    window.speechSynthesis.speak(utterance); setSpeaking(true);
  }
  async function send(event: FormEvent) {
    event.preventDefault(); if (!stop || !token || step !== "review" || pendingCount > 0) return; setNotice("");
    try {
      const requestKey = draftKey + ":request";
      let idempotencyKey = await loadDraft<string>(requestKey);
      if (!idempotencyKey) { idempotencyKey = crypto.randomUUID(); await saveDraft(requestKey, idempotencyKey); }
      const payload = { code: normalizedCode, token, stopId: stop.id, draftKey, idempotencyKey, ...form, hateDimensions: form.hateMapping === "none" ? [] : form.hateDimensions, privacyGroup: privacyGroups.find((group) => group.items.some(([, id]) => form.privacyProblems.includes(id)))?.group };
      await enqueueSubmission(normalizedCode, payload);
      await refreshQueue();
      if (!navigator.onLine) { setNotice("Sem internet: a resposta foi guardada neste aparelho e será enviada ao reconectar."); return; }
      await flushQueue();
      if (!(await pendingSubmissions(normalizedCode, token)).some((row) => row.payload.stopId === stop.id)) {
        await clearDraft(draftKey); await clearDraft(requestKey);
        if (!muted) playConfirmation();
        setLastDecision({ title: stop.title, protection: stop.choices.find((choice) => choice.id === form.choiceId)?.protection || "Cuidado coletivo", investigation: stop.investigation });
        setNotice("Resposta confirmada. A proteção escolhida foi: " + (stop.choices.find((choice) => choice.id === form.choiceId)?.protection || "cuidado coletivo"));
        await invalidate(); window.scrollTo({ top: 0 });
      }
    } catch (cause) { setNotice(cause instanceof Error ? cause.message : "Não foi possível guardar a resposta neste aparelho."); }
  }

  async function skipStop() {
    if (!stop || !navigator.onLine) return;
    try { await skip.mutateAsync({ code: normalizedCode, token, stopId: stop.id, idempotencyKey: crypto.randomUUID() }); await clearDraft(draftKey); await invalidate(); window.scrollTo({ top: 0 }); }
    catch (cause) { setNotice(cause instanceof Error ? cause.message : "Não foi possível pular agora."); }
  }

  if (!token) return <main className="entry-page" id="conteudo"><Brand /><form className="entry-card" onSubmit={enter}><p className="eyebrow">Entrada da dupla</p><h1>O portal está esperando.</h1><p>Digitem o código projetado pelo mediador. Não usem nomes reais nem criem uma conta.</p><label>Código da sessão<input name="code" defaultValue={normalizedCode} maxLength={8} autoCapitalize="characters" autoComplete="off" required /></label><details><summary>Retomar uma dupla em outro aparelho</summary><label>Chave da dupla<input name="recoveryToken" type="password" autoComplete="off" maxLength={100} /></label><p>A chave é privada. Sem ela não é possível recuperar uma dupla pelo código público.</p></details>{notice && <p className="form-error">{notice}</p>}<button className="button button--primary" disabled={join.isPending}>Entrar <ArrowRight size={18} /></button><Link to="/"><ArrowLeft size={16} /> Voltar</Link></form></main>;
  if (state.isLoading) return <main className="loading-page" id="conteudo"><span className="loader-orbit" /><p>Abrindo o mapa da dupla…</p></main>;
  if (state.error || !state.data) return <main className="entry-page" id="conteudo"><Brand /><div className="entry-card"><WifiOff size={32} /><h1>Não foi possível retomar.</h1><p>{state.error?.message || "Confiram a conexão e o código. O rascunho continua neste aparelho."}</p><button className="button button--primary" onClick={() => { localStorage.removeItem(`emd_pair_${normalizedCode}`); setToken(""); }}>Entrar novamente</button></div></main>;

  const { team, session } = state.data;
  if (!team.avatarId) return <AvatarPicker teamName={team.name} sessionCode={session.code} pending={avatar.isPending || randomAvatar.isPending} onChoose={(id) => void chooseAvatar(id)} onRandom={() => void balancedRandomAvatar()} />;
  if (session.status === "lobby" || session.status === "closed") return <main className="lobby-page" id="conteudo"><Brand inverse /><div className="lobby-signal"><span className="pulse-dot" /> Portal aberto</div><AvatarGlyph id={team.avatarId} size={150} /><h1>{team.name}, <br />a travessia vai começar.</h1><p>O mediador iniciará a primeira fase. As decisões serão conversadas e nenhum relato pessoal é necessário.</p><div className="lobby-code">Código da sessão <strong>{session.code}</strong></div></main>;
  if (session.status === "finished" && team.currentStopId !== "finished") return <main className="entry-page" id="conteudo"><Brand /><div className="entry-card"><h1>Sessão encerrada</h1><p>As respostas confirmadas foram preservadas. Conversem com o mediador para a síntese coletiva.</p></div></main>;
  if (team.currentStopId === "finished") return <main className="completion-page" id="conteudo"><div className="completion-top"><Brand inverse /><span>Síntese da dupla</span></div><div className="completion-avatar"><div className="completion-ring" /><AvatarGlyph id={team.avatarId} size={142} /></div><p className="eyebrow">Perfil de proteção · sem ranking</p><h1>Vocês teceram <br /><em>{team.immunity} camadas de cuidado.</em></h1><p>A vulnerabilidade inerente não desaparece. O que muda é a capacidade coletiva de reduzir danos, contestar estruturas e ampliar direitos.</p><div className="protection-constellation">{phases.slice(0, 4).map((item) => <div key={item.id} style={{ "--phase-color": item.lightColor } as React.CSSProperties}><PhaseIcon phase={item.id} size={24} /><span>{item.title}</span></div>)}</div><div className="completion-note"><strong>Proteção é verbo coletivo.</strong><span>A síntese da turma aparece na projeção quando o mediador abrir o debate final.</span></div><Link className="button button--light" to={`/projecao/${session.code}`}>Ver a síntese coletiva <ArrowRight size={18} /></Link></main>;
  if (!stop || !phase) return null;

  const ownResponse = state.data.responses.find((response) => response.stopId === stop.id);
  const stopState = ownResponse?.skipped ? "pulada por sensibilidade" : ownResponse ? "confirmada" : pendingCount > 0 ? "enviada · aguardando conexão" : step !== "reading" || form.choiceId ? "rascunho" : "não iniciada";
  const canSubmit = Boolean(form.choiceId) && (isFinal || Boolean(classificationFields.every((field) => form[field.key]) && (form.hiddenFactorUnknown || form.hiddenFactor.trim())));
  const currentClassification = classificationFields[classificationIndex];
  const currentChoice = stop.choices.find((choice) => choice.id === form.choiceId);
  const projectionToggle = <label className="projection-consent projection-consent--compact"><input type="checkbox" checked={!form.allowProjection} onChange={(event) => update("allowProjection", !event.target.checked)} /><span><strong>Não projetar esta resposta</strong><small>A escolha fica guardada para a pesquisa, mas não aparece na tela coletiva.</small></span></label>;
  const connectionLabel = connection === "sse" ? "ao vivo" : connection === "polling" ? "sincronização periódica" : "sem conexão";

  return <div className="team-shell team-shell--progressive">
    <header className="team-header"><Brand inverse /><div className="team-identity"><AvatarGlyph id={team.avatarId} size={38} /><span><strong>{team.name}</strong><small>{session.code}</small><details><summary>Chave para retomar a dupla</summary><code>{token}</code></details></span></div><div className={`connection ${connection !== "offline" ? "is-online" : ""}`} title={connectionLabel}><span />{connectionLabel}</div><button className="icon-button" aria-label={muted ? "Ativar sons" : "Desativar sons"} onClick={() => setMuted(!muted)}>{muted ? <VolumeX /> : <Volume2 />}</button></header>
    {lastDecision && <section className="decision-feedback" role="status"><strong>Travessia registrada: {lastDecision.title}</strong><p>Proteção mobilizada: {lastDecision.protection}.</p><p>{lastDecision.investigation}</p><button type="button" onClick={() => setLastDecision(null)}>Continuar a jornada</button></section>}
    <div className="team-progress" aria-label={`Etapa ${stepIndex + 1} de ${steps.length}`}><div style={{ width: `${((stepIndex + 1) / steps.length) * 100}%`, background: phase.color }} /></div>
    <main className="team-main progressive-main" id="conteudo">
      <nav className="mini-phase-map" aria-label="Fases da travessia">{phases.map((item) => <div key={item.id} className={`${item.id === phase.id ? "is-current" : ""} ${team.completedStopIds.some((id) => stopById[id]?.phase === item.id) ? "is-past" : ""}`} style={{ "--phase-color": item.color } as React.CSSProperties}><PhaseIcon phase={item.id} size={35} /><small>{item.title.replace("Vulnerabilidade ", "")}</small></div>)}</nav>
      <div className="progressive-meta"><div><span className="phase-symbol" style={{ color: phase.color }}><PhaseIcon phase={phase.id} size={30} /></span><span>{phase.title}</span></div><span className="stop-state">{stopState}</span></div>
      <nav className="step-map" aria-label="Etapas desta parada">{steps.map((item, index) => <button key={item} type="button" className={`${item === step ? "is-current" : ""} ${index < stepIndex ? "is-past" : ""}`} disabled={index > stepIndex} onClick={() => moveTo(item)} aria-current={item === step ? "step" : undefined}><span>{index < stepIndex ? <Check size={14} /> : index + 1}</span>{stepLabels[item]}</button>)}</nav>

      <form onSubmit={send} className="response-form progressive-form">
        {step === "reading" && <section className="progressive-step reading-step" aria-labelledby="step-title">
          <p className="eyebrow" style={{ color: phase.color }}>{stop.kicker}</p><h1 id="step-title" tabIndex={-1}>{stop.title}</h1>
          <button type="button" className="listen-button" onClick={toggleSpeech}>{speaking ? <VolumeX size={20} /> : <Volume2 size={20} />}{speaking ? "Interromper leitura" : "Ouvir a situação"}</button>
          <div className="reading-scenario"><p>{stop.scenario}</p></div>
          <div className="investigation-card"><HelpCircle size={23} /><div><strong>Pista para investigar</strong><p>{stop.investigation}</p></div></div>
          <details className="source-details source-details--light"><summary>Fonte e contexto do caso <HelpCircle size={16} /></summary><p>{stop.source.note}</p>{stop.source.url && <a href={stop.source.url} target="_blank" rel="noreferrer">Consultar fonte pública <ArrowRight size={15} /></a>}</details>
        </section>}

        {step === "choice" && <section className="progressive-step" aria-labelledby="step-title"><p className="eyebrow">Uma decisão por vez</p><h1 id="step-title" tabIndex={-1}>Que travessia vocês escolhem?</h1><p className="step-intro">As duas ações podem proteger. Conversem sobre qual abre o caminho mais possível nesta situação.</p><div className="choice-grid">{stop.choices.map((choice, index) => <label key={choice.id} className={form.choiceId === choice.id ? "is-selected" : ""}><input type="radio" name="choice" value={choice.id} checked={form.choiceId === choice.id} onChange={() => update("choiceId", choice.id)} /><span className="choice-number">0{index + 1}</span><strong>{choice.label}</strong><p>{choice.detail}</p><small><ShieldCheck size={15} />{choice.protection}</small></label>)}</div></section>}

        {step === "classification" && <section className="progressive-step classification-step" aria-labelledby="step-title">
          <div className="question-count">Classificação · {classificationIndex + 1} de {classificationFields.length}</div><h1 id="step-title" tabIndex={-1}>{currentClassification.prompt}</h1><p className="step-intro">Contestação e concordância têm o mesmo valor. Se a proposta não couber, registrem isso na etapa de fator oculto.</p>
          <FieldSelect label={currentClassification.label} value={form[currentClassification.key]} options={currentClassification.options} onChange={(value) => update(currentClassification.key, value)} />
          <div className="classification-dots" aria-hidden="true">{classificationFields.map((field, index) => <span key={field.key} className={`${index === classificationIndex ? "is-current" : ""} ${form[field.key] ? "is-filled" : ""}`} />)}</div>
          {classificationIndex === 0 && <button type="button" className="contestation-link" onClick={() => moveTo("hidden")}>Queremos contestar ou propor outra leitura <ArrowRight size={17} /></button>}
        </section>}

        {step === "privacy" && <section className="progressive-step" aria-labelledby="step-title"><p className="eyebrow">Camada independente</p><h1 id="step-title" tabIndex={-1}>Que problemas de privacidade aparecem?</h1><p className="step-intro">Selecionem quantos forem necessários. Esses problemas não substituem a origem nem as macroclasses MC1–MC5.</p><div className="privacy-groups-progressive">{privacyGroups.map((group) => <fieldset className="privacy-group" key={group.id}><legend>{group.group}</legend><div>{group.items.map(([label, id]) => <label key={id} className={form.privacyProblems.includes(id) ? "is-checked" : ""}><input type="checkbox" checked={form.privacyProblems.includes(id)} onChange={() => toggleList("privacyProblems", id)} />{label}</label>)}</div></fieldset>)}</div><label className={`privacy-unknown ${form.privacyProblems.includes("unknown") ? "is-checked" : ""}`}><input type="checkbox" checked={form.privacyProblems.includes("unknown")} onChange={() => toggleList("privacyProblems", "unknown")} /><HelpCircle size={20} /><span><strong>Não sei</strong><small>Podemos seguir sem escolher um problema agora.</small></span></label>
          <details className="hate-details" open={stop.hateCase}><summary>Camada OntoHate <span>use somente quando houver relação com discurso de ódio</span></summary><p>Ofensa, assédio ou desinformação não são automaticamente discurso de ódio. Identifiquem alvo, marcador protegido e proposição antes de classificar.</p><label className="field-select"><span>Relação com OntoHate</span><select value={form.hateMapping} onChange={(event) => update("hateMapping", event.target.value as FormState["hateMapping"])}><option value="none">Não se aplica / nenhuma</option><option value="exact">Correspondência exata</option><option value="close">Correspondência próxima</option><option value="related">Relação parcial</option></select></label>{form.hateMapping !== "none" && <div className="hate-dimensions">{hateDimensions.map(([label, id]) => <label key={id}><input type="checkbox" checked={form.hateDimensions.includes(id)} onChange={() => toggleList("hateDimensions", id)} />{label}</label>)}</div>}</details>
        </section>}

        {step === "experience" && <section className="progressive-step private-step" aria-labelledby="step-title"><EyeOff size={32} /><p className="eyebrow">Tela privada e opcional</p><h1 id="step-title" tabIndex={-1}>Que relação vocês têm com esta situação?</h1><p className="step-intro">Esta pergunta ajuda a pesquisa a compreender a relação da turma com os casos. A resposta é facultativa e não muda o percurso. Esta informação <strong>nunca aparece na projeção, para o mediador ou para outras duplas.</strong> Não é necessário contar nenhum relato.</p><fieldset className="experience-options"><legend className="sr-only">Relação pessoal com a situação</legend>{[["nao_informar", "Prefiro não informar"], ["imaginada", "Imaginada"], ["conhecida", "Conhecida"], ["observada", "Observada"], ["vivenciada", "Vivenciada"]].map(([value, label]) => <label key={value} className={form.experience === value ? "is-selected" : ""}><input type="radio" name="experience" checked={form.experience === value} onChange={() => update("experience", value as FormState["experience"])} />{label}</label>)}</fieldset></section>}

        {step === "hidden" && <section className="progressive-step" aria-labelledby="step-title"><p className="eyebrow">Investigação aberta</p><h1 id="step-title" tabIndex={-1}>{isFinal ? "O que a turma precisa ouvir?" : "Que fator ainda está invisível?"}</h1>{!isFinal && <p className="step-intro">{stop.investigation}</p>}<div className="personal-data-warning"><EyeOff size={18} /><span>Não incluam nomes reais, contatos, senhas, endereços ou perfis de colegas.</span></div>{!isFinal && <><label className="open-question">Fator oculto ou hipótese<textarea value={form.hiddenFactor} onChange={(event) => update("hiddenFactor", event.target.value)} maxLength={600} placeholder="Descrevam sem incluir dados pessoais…" disabled={form.hiddenFactorUnknown} /></label>{projectionToggle}<label className="check-line unknown-line"><input type="checkbox" checked={form.hiddenFactorUnknown} onChange={(event) => update("hiddenFactorUnknown", event.target.checked)} /> Ainda não sabemos identificar</label></>}
          <details className="voice-details"><summary>Voz da dupla <span>opcional · concordar e contestar têm o mesmo espaço</span></summary><label className="open-question">Como vocês querem contribuir?<select value={form.contributionKind} onChange={(event) => update("contributionKind", event.target.value as FormState["contributionKind"])}><option value="unspecified">Prefiro não indicar</option><option value="agreement">Concordar com a leitura apresentada</option><option value="contestation">Contestar a leitura</option><option value="proposal">Propor outra leitura ou conceito</option></select></label><label className="open-question">Justificativa ou hipótese<textarea value={form.justification} onChange={(event) => update("justification", event.target.value)} maxLength={800} placeholder="O que sustenta a leitura de vocês?" /></label><label className="open-question">Contestar uma classificação<textarea value={form.contestation} onChange={(event) => update("contestation", event.target.value)} maxLength={800} placeholder="Que relação a taxonomia ainda não explica?" /></label><label className="open-question">Propor um conceito candidato<input value={form.candidateConcept} onChange={(event) => update("candidateConcept", event.target.value)} maxLength={120} placeholder="Um termo novo para investigar" /><small>Será enviado à curadoria; não vira uma classe automaticamente.</small></label>{isFinal && projectionToggle}</details>
        </section>}

        {step === "review" && <section className="progressive-step review-step" aria-labelledby="step-title"><p className="eyebrow">Antes de atravessar</p><h1 id="step-title" tabIndex={-1}>Revisem o que será compartilhado.</h1><div className="review-columns"><div><h2>Na projeção</h2><dl><div><dt>Travessia</dt><dd>{currentChoice?.label || "Não escolhida"}</dd></div>{!isFinal && <div><dt>Leitura de origem</dt><dd>{optionSets.source.find(([, id]) => id === form.sourceClassification)?.[0]}</dd></div>}<div><dt>Textos abertos</dt><dd>{form.allowProjection ? "Autorizados, somente após moderação" : "Não autorizados"}</dd></div></dl></div><div className="review-private"><h2><EyeOff size={20} /> Fora da projeção</h2><p>Experiência pessoal, texto ainda não aprovado e qualquer resposta marcada como “não projetar”.</p><p>A experiência privada também não aparece para o mediador.</p></div></div>{projectionToggle}{!canSubmit && <p className="form-error">Ainda falta uma etapa obrigatória. Voltem para revisar; “não sei” pode ser usado nas classificações.</p>}</section>}

        {notice && <div className="inline-notice" role="status">{notice}</div>}
        {pendingCount > 0 && <div className="queue-notice"><RefreshCw size={17} /> {pendingCount} resposta(s) aguardando conexão. Não enviem novamente.</div>}
        <div className="progressive-actions"><button type="button" className="button button--outline" onClick={previousStep} disabled={stepIndex === 0 && classificationIndex === 0}><ArrowLeft size={18} /> Voltar</button>{step !== "review" ? <button type="button" className="button button--primary" onClick={(event) => { event.preventDefault(); nextStep(); }}>Continuar <ArrowRight size={18} /></button> : <button className="button button--primary button--submit" disabled={!canSubmit || submit.isPending || pendingCount > 0}>{submit.isPending ? "Registrando…" : isFinal ? "Construir perfil de proteção" : "Registrar e atravessar"}<ArrowRight size={19} /></button>}</div>
        {stop.sensitive && <button type="button" className="button button--outline skip-button" onClick={() => void skipStop()} disabled={!navigator.onLine || skip.isPending || submit.isPending || pendingCount > 0}>Pular esta parada sensível, sem justificar</button>}
      </form>
    </main>
  </div>;
}
