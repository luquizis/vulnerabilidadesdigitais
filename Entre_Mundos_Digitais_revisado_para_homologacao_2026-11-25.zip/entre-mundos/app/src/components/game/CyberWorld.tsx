import { phases } from "@contracts/game";
import { AvatarGlyph } from "./AvatarGlyph";

const stars = [
  [44, 82, 2], [93, 145, 1], [151, 65, 1], [218, 119, 2], [286, 54, 1], [355, 95, 1],
  [421, 47, 2], [485, 118, 1], [553, 62, 1], [627, 129, 2], [681, 68, 1], [59, 298, 1],
  [666, 312, 1], [37, 439, 2], [680, 491, 1], [98, 582, 1], [615, 600, 2], [480, 635, 1],
];

export function CyberWorld() {
  return <div className="cyber-world">
    <div className="cyber-hud"><span>CIBERESPAÇO <b>//</b> TERRITÓRIO VIVO</span><span className="cyber-online"><i /> REDE ABERTA</span></div>
    <svg className="cyber-scene" viewBox="0 0 720 680" aria-hidden="true">
      <defs>
        <radialGradient id="world-space" cx="50%" cy="40%" r="72%"><stop offset="0" stopColor="#25245D" /><stop offset=".48" stopColor="#101A39" /><stop offset="1" stopColor="#080D20" /></radialGradient>
        <linearGradient id="world-route" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#62E8D0" /><stop offset=".48" stopColor="#7895FF" /><stop offset="1" stopColor="#E39BFF" /></linearGradient>
        <linearGradient id="world-island" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#344477" /><stop offset="1" stopColor="#151D40" /></linearGradient>
        <linearGradient id="world-core" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#81F4DA" /><stop offset=".5" stopColor="#708DFF" /><stop offset="1" stopColor="#D293FF" /></linearGradient>
        <filter id="world-glow" x="-80%" y="-80%" width="260%" height="260%"><feGaussianBlur stdDeviation="7" result="blur" /><feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
        <filter id="world-soft" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="18" /></filter>
        <pattern id="world-dots" width="24" height="24" patternUnits="userSpaceOnUse"><circle cx="2" cy="2" r="1" fill="#B9C8FF" opacity=".17" /></pattern>
      </defs>
      <rect width="720" height="680" rx="32" fill="url(#world-space)" />
      <rect width="720" height="680" rx="32" fill="url(#world-dots)" />
      <ellipse cx="360" cy="337" rx="186" ry="170" fill="#6267FF" opacity=".12" filter="url(#world-soft)" />
      <g fill="#DDE6FF">{stars.map(([cx, cy, r], index) => <circle key={index} cx={cx} cy={cy} r={r} opacity={index % 3 === 0 ? .85 : .45} />)}</g>
      <g className="cyber-constellation" fill="none" stroke="#7D93D9" strokeWidth="1" opacity=".24">
        <path d="M44 82 93 145 151 65 218 119 286 54M421 47 485 118 553 62 627 129 681 68M37 439 98 582M615 600 680 491 666 312" />
      </g>
      <g className="cyber-skyline">
        <path d="M0 290V221h26v-37h20v52h22v-83h29v111h22v-46h34v74M720 290v-89h-24v-45h-25v72h-22v-105h-31v138h-24v-53h-31v83" fill="#111A35" stroke="#344574" strokeWidth="2" />
        <g stroke="#65DCC8" strokeWidth="3" opacity=".65"><path d="M77 171v69M88 171v69M638 145v90M659 177v60M696 217v44" /></g>
        <g fill="#8AA4FF" opacity=".55">{[177,195,213,231].map((y) => <rect key={y} x="31" y={y} width="8" height="4" rx="1" />)}</g>
      </g>
      <g className="cyber-grid" fill="none" stroke="#6680C7" strokeWidth="1" opacity=".19">
        <path d="M360 261 0 680M360 261 120 680M360 261 240 680M360 261 360 680M360 261 480 680M360 261 600 680M360 261 720 680" />
        <path d="M244 310h232M196 350h328M137 402h446M67 468h586M0 552h720M0 650h720" />
      </g>
      <g className="cyber-routes" fill="none" strokeLinecap="round">
        <path d="M120 232C160 130 256 118 337 133S507 136 578 231 606 400 538 449 381 540 293 505 123 390 120 232Z" stroke="#11182E" strokeWidth="15" />
        <path d="M120 232C160 130 256 118 337 133S507 136 578 231 606 400 538 449 381 540 293 505 123 390 120 232Z" stroke="url(#world-route)" strokeWidth="3" opacity=".8" />
        <path className="cyber-data-flow" d="M120 232C160 130 256 118 337 133S507 136 578 231 606 400 538 449 381 540 293 505 123 390 120 232Z" stroke="#E6FFFA" strokeWidth="3" strokeDasharray="2 22" />
        <path d="M120 232Q235 290 352 337T578 231M337 133Q345 234 352 337T538 449M293 505Q320 416 352 337" stroke="#6E88D5" strokeWidth="2" strokeDasharray="5 9" opacity=".55" />
      </g>
      <g className="cyber-islands">
        <g transform="translate(120 238)"><ellipse cy="22" rx="74" ry="28" fill="#070C1C" opacity=".65" /><path d="M-65 0 0-27 65 0 0 31Z" fill="url(#world-island)" stroke="#66E5CD" strokeOpacity=".65" /><path d="M-65 0 0 31v23L-47 18Z" fill="#132A3B" /><path d="M65 0 0 31v23l47-36Z" fill="#1A2148" /><circle r="14" fill="#67E6CC" opacity=".17" filter="url(#world-glow)" /><circle r="7" fill="#8CF6DF" /></g>
        <g transform="translate(337 139)"><ellipse cy="22" rx="68" ry="25" fill="#070C1C" opacity=".65" /><path d="M-60 0 0-25 60 0 0 28Z" fill="url(#world-island)" stroke="#FFD166" strokeOpacity=".65" /><path d="M-60 0 0 28v22L-44 16Z" fill="#332A35" /><path d="M60 0 0 28v22l43-34Z" fill="#272348" /><path d="M-10 4V-27h20V4M-17-27h34" fill="#FFD166" opacity=".75" /></g>
        <g transform="translate(578 236)"><ellipse cy="22" rx="74" ry="28" fill="#070C1C" opacity=".65" /><path d="M-65 0 0-27 65 0 0 31Z" fill="url(#world-island)" stroke="#FF856C" strokeOpacity=".65" /><path d="M-65 0 0 31v23L-47 18Z" fill="#382337" /><path d="M65 0 0 31v23l47-36Z" fill="#272047" /><path d="m-14 8 7-31 13 19 12-25" fill="none" stroke="#FF9A84" strokeWidth="5" /></g>
        <g transform="translate(538 453)"><ellipse cy="22" rx="79" ry="30" fill="#070C1C" opacity=".65" /><path d="M-69 0 0-29 69 0 0 33Z" fill="url(#world-island)" stroke="#B48CFF" strokeOpacity=".65" /><path d="M-69 0 0 33v24L-50 19Z" fill="#292044" /><path d="M69 0 0 33v24L50 19Z" fill="#20214C" /><path d="M-23 6v-30h46V6M-23-12h46M0-24V6" fill="none" stroke="#C7A9FF" strokeWidth="4" /></g>
        <g transform="translate(293 511)"><ellipse cy="22" rx="87" ry="32" fill="#070C1C" opacity=".65" /><path d="M-76 0 0-31 76 0 0 35Z" fill="url(#world-island)" stroke="#7D9CFF" strokeOpacity=".8" /><path d="M-76 0 0 35v24L-55 20Z" fill="#182C4B" /><path d="M76 0 0 35v24L55 20Z" fill="#1C2554" /><path d="M0 10-20-7c-13-15 8-29 20-12 12-17 33-3 20 12Z" fill="#8DA8FF" filter="url(#world-glow)" /></g>
      </g>
      <g className="cyber-portal" transform="translate(360 340)">
        <ellipse cy="53" rx="91" ry="29" fill="#6478FF" opacity=".17" filter="url(#world-soft)" />
        <ellipse rx="90" ry="43" fill="none" stroke="#7895FF" strokeWidth="2" opacity=".28" />
        <ellipse rx="68" ry="33" fill="none" stroke="#78E8D1" strokeWidth="2" strokeDasharray="7 8" opacity=".65" />
        <ellipse rx="43" ry="84" fill="#687CFF" opacity=".12" filter="url(#world-glow)" />
        <ellipse rx="34" ry="72" fill="#111936" stroke="url(#world-core)" strokeWidth="5" filter="url(#world-glow)" />
        <ellipse rx="23" ry="57" fill="url(#world-core)" opacity=".24" />
        <path d="M-18 38 0-48 18 38M-26 6h52" fill="none" stroke="#DFFFF8" strokeWidth="2" opacity=".6" />
        <circle cy="-72" r="4" fill="#DFFFF8" />
      </g>
      <g className="cyber-packets" fill="#DFFFF8" filter="url(#world-glow)"><circle cx="206" cy="154" r="3" /><circle cx="504" cy="163" r="3" /><circle cx="578" cy="355" r="3" /><circle cx="410" cy="500" r="3" /><circle cx="154" cy="361" r="3" /></g>
    </svg>
    <div className="cyber-core-label"><small>NÚCLEO COLETIVO</small><strong>Rede de cuidado</strong></div>
    {phases.map((phase, index) => <div key={phase.id} className={`cyber-node cyber-node--${index + 1}`} style={{ "--phase-color": phase.color } as React.CSSProperties}>
      <span>{phase.short}</span><div><small>0{phase.number} / TERRITÓRIO</small><strong>{phase.title.replace("Vulnerabilidade ", "")}</strong></div>
    </div>)}
    <div className="cyber-avatar cyber-avatar--aurora"><AvatarGlyph id="aurora:00000" size={108} /><span>Aurora</span></div>
    <div className="cyber-avatar cyber-avatar--camila"><AvatarGlyph id="camila:00000" size={120} /><span>Camila</span></div>
    <div className="cyber-avatar cyber-avatar--benedito"><AvatarGlyph id="benedito:00000" size={94} /><span>Benedito</span></div>
    <div className="cyber-map-caption"><span className="pulse-dot" /><p><strong>Um território. Muitas leituras.</strong><small>Escolhas abrem rotas; proteções criam conexões.</small></p></div>
  </div>;
}
