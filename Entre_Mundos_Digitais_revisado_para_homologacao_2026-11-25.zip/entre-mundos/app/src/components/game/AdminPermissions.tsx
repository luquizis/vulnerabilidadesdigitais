import { useState } from "react";
import type { FormEvent } from "react";
import { trpc } from "@/lib/trpc";

export function AdminPermissions({ sessions }: { sessions: { id: number; code: string; title: string }[] }) {
  const users = trpc.admin.users.useQuery();
  const [userId, setUserId] = useState(0);
  const [sessionId, setSessionId] = useState(0);
  const [message, setMessage] = useState("");
  const [grant, setGrant] = useState({ canCurate: false, canExport: false, canReadExperience: false });
  const access = trpc.admin.access.useQuery({ sessionId }, { enabled: sessionId > 0 });
  const roleMutation = trpc.admin.setRole.useMutation();
  const accessMutation = trpc.admin.setAccess.useMutation();
  // Sincroniza o formulário com a concessão carregada usando ajuste de estado
  // durante o render (evita setState síncrono em efeito). A chave muda quando a
  // consulta carrega ou quando a dupla usuário/sessão muda; edições locais entre
  // recarregamentos são preservadas.
  const existing = access.data?.find((item) => item.userId === userId);
  const syncKey = access.data ? `${userId}:${sessionId}:${existing ? "grant" : "none"}` : "";
  const [loadedSyncKey, setLoadedSyncKey] = useState("");
  if (syncKey && syncKey !== loadedSyncKey) {
    setLoadedSyncKey(syncKey);
    setGrant({ canCurate: existing?.canCurate || false, canExport: existing?.canExport || false, canReadExperience: existing?.canReadExperience || false });
  }
  async function save(event: FormEvent, revoke = false) {
    event.preventDefault(); setMessage("");
    try {
      await accessMutation.mutateAsync({ userId, sessionId, ...grant, revoke });
      await access.refetch(); setMessage(revoke ? "Acesso à sessão revogado." : "Permissões da sessão atualizadas.");
    } catch (error) { setMessage(error instanceof Error ? error.message : "Não foi possível salvar."); }
  }
  return <details className="admin-permissions"><summary>Administrar usuários e permissões</summary>
    <p>O papel habilita a função. A concessão abaixo limita o acesso a cada sessão. Experiências pessoais exigem autorização separada.</p>
    {users.error && <p role="alert">{users.error.message}</p>}
    <div className="research-table-wrap"><table><thead><tr><th>Usuário</th><th>Papel</th></tr></thead><tbody>{users.data?.map((user) => <tr key={user.id}><td>{user.name || `Usuário ${user.id}`}</td><td><label><span className="sr-only">Papel de {user.name || user.id}</span><select value={user.role} disabled={roleMutation.isPending} onChange={async (event) => {
      try { await roleMutation.mutateAsync({ userId: user.id, role: event.target.value as "user" | "researcher" | "curator" | "admin" }); await users.refetch(); setMessage("Papel atualizado."); }
      catch (error) { setMessage(error instanceof Error ? error.message : "Não foi possível alterar o papel."); }
    }}><option value="user">Participante sem acesso à pesquisa</option><option value="researcher">Pesquisador</option><option value="curator">Curador</option><option value="admin">Administrador</option></select></label></td></tr>)}</tbody></table></div>
    <form onSubmit={(event) => void save(event)}>
      <label>Usuário<select required value={userId || ""} onChange={(event) => setUserId(Number(event.target.value))}><option value="" disabled>Selecione</option>{users.data?.map((user) => <option key={user.id} value={user.id}>{user.name || `Usuário ${user.id}`}</option>)}</select></label>
      <label>Sessão<select required value={sessionId || ""} onChange={(event) => setSessionId(Number(event.target.value))}><option value="" disabled>Selecione</option>{sessions.map((session) => <option key={session.id} value={session.id}>{session.code} · {session.title}</option>)}</select></label>
      <label><input type="checkbox" checked={grant.canCurate} onChange={(event) => setGrant({ ...grant, canCurate: event.target.checked })} /> Permitir curadoria quando o papel for curador</label>
      <label><input type="checkbox" checked={grant.canExport} onChange={(event) => setGrant({ ...grant, canExport: event.target.checked })} /> Permitir exportação</label>
      <label><input type="checkbox" checked={grant.canReadExperience} onChange={(event) => setGrant({ ...grant, canReadExperience: event.target.checked })} /> Permitir consulta à experiência pessoal facultativa</label>
      <button className="button button--primary" disabled={!userId || !sessionId || accessMutation.isPending}>Conceder ou atualizar acesso</button>
      <button className="button button--outline" type="button" disabled={!userId || !sessionId || accessMutation.isPending} onClick={(event) => void save(event, true)}>Revogar acesso</button>
    </form>
    {message && <p role="status">{message}</p>}
  </details>;
}
