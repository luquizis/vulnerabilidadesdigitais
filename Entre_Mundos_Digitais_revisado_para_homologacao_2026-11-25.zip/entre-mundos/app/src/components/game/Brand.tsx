import { Link } from "react-router";

export function Brand({ inverse = false }: { inverse?: boolean }) {
  return <Link to="/" className={`brand ${inverse ? "brand--inverse" : ""}`} aria-label="Entre Mundos Digitais — início">
    <svg viewBox="0 0 42 42" width="38" height="38" aria-hidden="true">
      <path d="M5 23C5 11 13 5 22 5c8 0 15 5 15 14 0 10-8 17-17 17" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M13 30C5 26 4 15 11 9M28 35c10-2 13-14 6-22" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
      <circle cx="21" cy="21" r="4" fill="currentColor" />
    </svg>
    <span><strong>Entre Mundos</strong><small>digitais</small></span>
  </Link>;
}

export function GameHeader({ inverse = false, children }: { inverse?: boolean; children?: React.ReactNode }) {
  return <header className={`game-header ${inverse ? "game-header--inverse" : ""}`}>
    <Brand inverse={inverse} />
    <nav aria-label="Acessos principais">
      <Link to="/">Jogar</Link><Link to="/mediador">Mediar</Link><Link to="/pesquisa">Pesquisa</Link>{children}
    </nav>
  </header>;
}
