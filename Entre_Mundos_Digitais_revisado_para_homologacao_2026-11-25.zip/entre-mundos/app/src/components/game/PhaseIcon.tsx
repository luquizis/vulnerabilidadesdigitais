import type { PhaseId } from "@contracts/game";

export function PhaseIcon({ phase, size = 34, className = "" }: { phase: PhaseId; size?: number; className?: string }) {
  const common = { fill: "none", stroke: "currentColor", strokeWidth: 1.8, vectorEffect: "non-scaling-stroke" as const };
  return <svg className={className} width={size} height={size} viewBox="0 0 36 36" aria-hidden="true">
    {phase === "inherent" && <circle cx="18" cy="18" r="12" {...common} />}
    {phase === "situational" && <rect x="6" y="6" width="24" height="24" rx="2" {...common} />}
    {phase === "pathogenic" && <path d="M18 5 32 30H4Z" {...common} />}
    {phase === "architectural" && <path d="m18 4 13 7v14l-13 7-13-7V11Z" {...common} />}
    {phase === "protection" && <path d="M18 4c4 4 8 5 12 5v9c0 7-5 11-12 14C11 29 6 25 6 18V9c4 0 8-1 12-5Z" {...common} />}
    <circle cx="18" cy="18" r="2.5" fill="currentColor" />
  </svg>;
}
