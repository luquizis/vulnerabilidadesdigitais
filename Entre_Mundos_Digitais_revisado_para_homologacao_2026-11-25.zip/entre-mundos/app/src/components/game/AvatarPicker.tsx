import { useState } from "react";
import { ArrowRight, Dices, Layers3, ShieldCheck } from "lucide-react";
import { avatarLayerFamilies, avatars, makeAvatarProfileId } from "@contracts/game";
import { AvatarGlyph } from "./AvatarGlyph";
import { Brand } from "./Brand";

export function AvatarPicker({ teamName, sessionCode, pending, onChoose, onRandom }: {
  teamName: string; sessionCode: string; pending: boolean;
  onChoose: (id: string) => void; onRandom: () => void;
}) {
  const [baseId, setBaseId] = useState("aurora");
  const [layers, setLayers] = useState([0, 0, 0, 0, 0]);
  const persona = avatars.find((item) => item.id === baseId) || avatars[0];
  const profileId = makeAvatarProfileId(baseId, layers);
  return <main className="avatar-builder">
    <header className="avatar-builder-header">
      <Brand inverse />
      <div className="avatar-header-meta"><span>ARQUIVO DE PERSONAS</span><strong>12 pontos de partida</strong></div>
      <button type="button" className="button button--random" onClick={onRandom} disabled={pending}><Dices size={18} /> Sorteio equilibrado</button>
    </header>
    <div className="avatar-builder-layout">
      <section className="avatar-personas" aria-labelledby="persona-title">
        <div className="avatar-section-heading">
          <p className="eyebrow"><span />{teamName} · sessão {sessionCode}</p>
          <h1 id="persona-title">Quem atravessa<br />este mundo?</h1>
          <p>Escolham uma persona fictícia. Corpo, idade, território e rotina constroem uma narrativa — nunca uma explicação automática para vulnerabilidade.</p>
        </div>
        <div className="persona-grid">{avatars.map((item, index) => <button type="button" key={item.id} className={baseId === item.id ? "is-selected" : ""} onClick={() => setBaseId(item.id)} aria-pressed={baseId === item.id} style={{ "--persona-color": item.color } as React.CSSProperties}>
          <span className="persona-number">{String(index + 1).padStart(2, "0")}</span>
          <span className="persona-art"><AvatarGlyph id={makeAvatarProfileId(item.id, baseId === item.id ? layers : [0, 0, 0, 0, 0])} size={128} /></span>
          <span className="persona-info"><strong>{item.name}</strong><small>{item.age} anos</small><span>{item.territory}</span></span>
          <span className="persona-selected" aria-hidden="true">✓</span>
        </button>)}</div>
      </section>
      <aside className="avatar-layers">
        <div className="avatar-preview" aria-live="polite">
          <div className="avatar-preview-stage">
            <div className="preview-grid" aria-hidden="true" />
            <span className="preview-status"><i /> PERSONA SELECIONADA</span>
            <AvatarGlyph id={profileId} size={218} />
            <span className="preview-object">{persona.object}</span>
          </div>
          <div className="avatar-preview-copy"><p className="eyebrow">Persona em travessia</p><h2>{persona.name}</h2><p>{persona.routine}</p><div><span>{persona.age} anos</span><span>{persona.territory}</span></div></div>
        </div>
        <div className="avatar-customization">
          <div className="layer-title"><Layers3 size={22} /><div><strong>Combinem as cinco camadas</strong><span>O perfil muda a história, não o valor da dupla.</span></div></div>
          {avatarLayerFamilies.map((family, familyIndex) => <label className="layer-select" key={family.id}><span><b>0{familyIndex + 1}</b>{family.label}</span><select value={layers[familyIndex]} onChange={(event) => setLayers((current) => current.map((value, index) => index === familyIndex ? Number(event.target.value) : value))}>{family.values.map((value, valueIndex) => <option key={value} value={valueIndex}>{value}</option>)}</select></label>)}
          <p className="resource-rule"><ShieldCheck size={20} /><span><strong>Recursos iniciais equivalentes.</strong> Todas as personas têm um destaque e um ponto em desenvolvimento. Condições de acesso pertencem à situação e podem ser transformadas.</span></p>
          <button type="button" className="button button--primary avatar-confirm" onClick={() => onChoose(profileId)} disabled={pending}>{pending ? "Guardando combinação…" : `Atravessar como ${persona.name}`}<ArrowRight size={19} /></button>
        </div>
      </aside>
    </div>
  </main>;
}
