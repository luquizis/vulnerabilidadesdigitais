import { useId } from "react";
import { avatarLayerIndexes, avatarPersonaById } from "@contracts/game";
import type { AvatarPersona } from "@contracts/game";

function BackHair({ avatar }: { avatar: AvatarPersona }) {
  const { hair, hairStyle } = avatar.visual;
  switch (hairStyle) {
    case "waves": return <path d="M48 62C43 33 58 15 81 15c27 0 39 22 32 51l5 52-25 8-12-25-15 25-25-9Z" fill={hair} />;
    case "afro": return <g fill={hair}>{[[52,42,18],[63,25,19],[83,20,21],[103,28,20],[113,46,18],[45,61,14],[116,64,14]].map(([cx,cy,r], i) => <circle key={i} cx={cx} cy={cy} r={r} />)}</g>;
    case "curls": return <g fill={hair}>{[[55,42,13],[61,28,14],[76,23,15],[92,25,15],[105,37,14],[108,51,12]].map(([cx,cy,r], i) => <circle key={i} cx={cx} cy={cy} r={r} />)}</g>;
    case "headwrap": return <path d="M49 65C43 35 57 20 80 20s38 17 31 46l-6 27H55Z" fill={hair} />;
    case "locs": return <g fill="none" stroke={hair} strokeWidth="8" strokeLinecap="round"><path d="M55 36 48 91M64 25 58 104M75 20 71 91M89 21 95 101M101 29 111 94M108 42 118 84" /></g>;
    case "bob": return <path d="M45 60C43 31 59 17 80 17 106 17 119 37 114 65l-3 34-23-9-8-19-9 19-24 9Z" fill={hair} />;
    case "braid": return <><path d="M47 62C43 34 57 18 80 18s37 18 33 47l-8 30H54Z" fill={hair} /><g fill={hair} transform="rotate(-8 110 102)">{[[109,82,10],[113,98,9],[111,114,8],[115,129,7]].map(([cx,cy,r], i) => <circle key={i} cx={cx} cy={cy} r={r} />)}</g></>;
    case "bun": return <><circle cx="82" cy="17" r="17" fill={hair} /><path d="M48 65C43 34 57 21 80 21s38 16 32 46l-8 25H55Z" fill={hair} /></>;
    case "ponytail": return <><path d="M49 62C45 34 59 18 81 18s35 17 31 45l-7 26H54Z" fill={hair} /><path d="M105 40c25 7 24 42 8 62-2-22-12-27-17-40Z" fill={hair} /></>;
    default: return <path d="M50 60C46 32 60 18 81 18s34 17 30 44l-6 19H54Z" fill={hair} />;
  }
}

function FrontHair({ avatar }: { avatar: AvatarPersona }) {
  const { hair, hairStyle } = avatar.visual;
  switch (hairStyle) {
    case "waves": return <path d="M52 59C46 36 58 18 80 18c23-1 36 17 31 42-10-6-16-17-19-28-8 15-22 20-40 27Z" fill={hair} />;
    case "senior": return <><path d="M54 48C53 28 65 20 81 20c17 0 28 9 27 29-12-10-40-11-54-1Z" fill={hair} /><path d="M53 47h7v25h-7zM101 47h7v25h-7z" fill={hair} /></>;
    case "afro": return <path d="M51 54c-2-23 11-37 30-37 22 0 34 15 29 39-11-13-44-16-59-2Z" fill={hair} />;
    case "curls": return <g fill={hair}>{[[58,42,10],[66,31,11],[80,29,12],[94,32,11],[104,43,10]].map(([cx,cy,r], i) => <circle key={i} cx={cx} cy={cy} r={r} />)}</g>;
    case "headwrap": return <><path d="M50 47C51 27 63 18 80 18s29 9 31 29c-17-9-43-9-61 0Z" fill={avatar.visual.outfitAccent} /><path d="m52 39 56 10M58 27l45 12" stroke={avatar.visual.outfit} strokeWidth="4" /><circle cx="104" cy="27" r="9" fill={avatar.visual.outfitAccent} /></>;
    case "locs": return <g fill="none" stroke={hair} strokeWidth="7" strokeLinecap="round"><path d="m57 47 4-21M67 39l3-23M79 35l1-20M90 37l-1-20M101 44l-5-22" /></g>;
    case "bob": return <path d="M49 60C45 34 59 17 80 17c22 0 36 18 32 44l-8 26-5-37c-13-2-23-10-28-20-3 14-10 23-18 28Z" fill={hair} />;
    case "crop": return <path d="M51 49C50 28 65 17 84 18c17 1 27 10 27 28-18-2-37-8-50-17l-3 20Z" fill={hair} />;
    case "braid": return <path d="M50 54C47 32 61 17 81 18c21 0 34 15 30 38-12-4-22-13-28-25-7 12-18 19-33 23Z" fill={hair} />;
    case "bun": return <path d="M50 53C48 31 61 20 80 20s32 12 30 34c-17-12-43-12-60-1Z" fill={hair} />;
    case "twists": return <g fill="none" stroke={hair} strokeWidth="7" strokeLinecap="round"><path d="m57 43 2-17M67 36l1-19M78 34V15M89 35l2-18M100 41l4-16" /></g>;
    case "ponytail": return <path d="M50 52C49 29 62 18 81 18s31 13 30 35c-17-2-33-9-43-21-3 10-9 16-18 20Z" fill={hair} />;
  }
}

function PersonaObject({ object, color, ink }: { object: string; color: string; ink: string }) {
  const common = { fill: "none", stroke: ink, strokeWidth: 2.4, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
  switch (object) {
    case "câmera": return <><rect x="-15" y="-10" width="30" height="22" rx="5" {...common} fill={color} /><circle r="6" {...common} /><path d="m-8-10 3-5h10l3 5" {...common} /></>;
    case "cédula": return <><rect x="-14" y="-19" width="28" height="38" rx="3" {...common} fill="#F7F3E8" /><path d="M-8-10H8M-8-4H5M-8 4H8M-8 10H2" {...common} /></>;
    case "rota": return <><path d="M-13 15C-13-3 11 8 11-9" {...common} /><circle cx="-13" cy="15" r="5" {...common} fill={color} /><path d="M11-20c-7 0-10 5-10 10 0 7 10 14 10 14s10-7 10-14c0-5-3-10-10-10Z" {...common} fill={color} /><circle cx="11" cy="-10" r="3" fill={ink} /></>;
    case "controle": return <><path d="M-20 8c0-14 6-20 14-15L0-4 6-7c8-5 14 1 14 15 0 12-7 14-12 5L0 5-8 13c-5 9-12 7-12-5Z" {...common} fill={color} /><path d="M-11-1v8M-15 3h8M10 0h.1M15 5h.1" {...common} /></>;
    case "semente": return <><path d="M0 18V-2M0 7C-18 6-18-10-18-10 0-11 0 7 0 7ZM0 1C18 0 18-16 18-16 0-17 0 1 0 1Z" {...common} fill={color} /></>;
    case "livro": case "lousa": return <><path d="M0-14C-7-19-17-18-20-16v30c8-3 15-1 20 3 5-4 12-6 20-3v-30c-3-2-13-3-20 2Z" {...common} fill={color} /><path d="M0-14v31" {...common} /></>;
    case "microfone": return <><rect x="-8" y="-20" width="16" height="28" rx="8" {...common} fill={color} /><path d="M-15-2c0 20 30 20 30 0M0 14v10M-9 24H9" {...common} /></>;
    case "antena": return <><path d="M-15 18 0-16l15 34ZM0-16v-8M-11-22a16 16 0 0 1 22 0M-18-29a25 25 0 0 1 36 0" {...common} /><circle cy="-16" r="4" fill={color} /></>;
    case "cuidado": return <path d="M0 18-18 0C-32-15-9-29 0-14 9-29 32-15 18 0Z" {...common} fill={color} />;
    case "escudo": return <><path d="M0-20 18-13V0c0 12-8 20-18 25C-10 20-18 12-18 0v-13Z" {...common} fill={color} /><path d="m-8 1 6 7L9-6" {...common} /></>;
    case "chave": return <><circle cx="-8" cy="-7" r="10" {...common} fill={color} /><path d="m-1 0 20 20M10 11l6-6M15 16l6-6" {...common} /></>;
    default: return null;
  }
}

export function AvatarGlyph({ id, size = 72, className = "" }: { id?: string | null; size?: number; className?: string }) {
  const avatar = avatarPersonaById(id);
  const { visual: v } = avatar;
  const layers = avatarLayerIndexes(id);
  const uid = useId().replaceAll(":", "");
  const bgId = `avatar-bg-${uid}`;
  const clipId = `avatar-clip-${uid}`;
  const headRx = v.ageGroup === "child" ? 23 : 25;
  const headRy = v.ageGroup === "child" ? 27 : 30;
  const arms = v.pose === "confident"
    ? <><path d="M49 108Q33 124 36 153" fill="none" stroke={v.skin} strokeWidth="15" strokeLinecap="round" /><path d="M111 107q20 14 5 31l-15-12" fill="none" stroke={v.skin} strokeWidth="15" strokeLinecap="round" strokeLinejoin="round" /></>
    : v.pose === "care"
      ? <><path d="M48 110q-7 25 24 32l25-12" fill="none" stroke={v.skin} strokeWidth="15" strokeLinecap="round" /><path d="M112 110q7 25-24 32l-24-12" fill="none" stroke={v.skinShade} strokeWidth="15" strokeLinecap="round" /></>
      : <><path d="M49 108Q34 126 37 153M111 108q15 18 12 45" fill="none" stroke={v.skin} strokeWidth="15" strokeLinecap="round" /></>;

  return <svg className={className} width={size} height={size} viewBox="0 0 160 160" role="img" aria-label={`Avatar corporal de ${avatar.name}, ${avatar.age} anos`}>
    <defs>
      <radialGradient id={bgId} cx="50%" cy="35%" r="70%"><stop offset="0" stopColor={avatar.accent} /><stop offset="1" stopColor={avatar.color} stopOpacity=".34" /></radialGradient>
      <clipPath id={clipId}><circle cx="80" cy="80" r="68" /></clipPath>
    </defs>
    <circle cx="80" cy="80" r="74" fill="#11182B" stroke={avatar.color} strokeOpacity=".5" />
    <circle cx="80" cy="80" r="68" fill={`url(#${bgId})`} />
    <g clipPath={`url(#${clipId})`}>
      <path d="M8 127 80 83l72 44v40H8Z" fill="#10182C" opacity=".16" />
      <path d="M17 39h24M119 31h23M18 104h13M129 90h18" stroke={avatar.color} strokeWidth="2" opacity=".5" />
      <g transform={v.ageGroup === "child" ? "translate(7 7) scale(.92)" : undefined}>
        <BackHair avatar={avatar} />
        {arms}
        <path d="M43 160 45 119q1-22 24-28h22q23 6 24 28l2 41Z" fill={v.outfit} />
        <path d="m45 116-8 28M115 116l8 28" fill="none" stroke={v.outfitAccent} strokeWidth="7" strokeLinecap="round" opacity=".9" />
        <path d="M66 91h28v15H66z" fill={v.skinShade} />
        <ellipse cx="80" cy="59" rx={headRx} ry={headRy} fill={v.skin} />
        <circle cx={80 - headRx + 1} cy="62" r="5" fill={v.skinShade} /><circle cx={80 + headRx - 1} cy="62" r="5" fill={v.skinShade} />
        <path d="M62 75q18 11 36 0" fill="none" stroke={v.skinShade} strokeWidth="2" opacity=".22" />
        <FrontHair avatar={avatar} />
        <path d="m65 94 15 14 15-14" fill="none" stroke={v.outfitAccent} strokeWidth="5" strokeLinejoin="round" />
        {avatar.id === "aurora" && <path d="M58 105q22 25 44 0" fill="none" stroke="#252337" strokeWidth="5" />}
        {avatar.id === "benedito" && <g fill="none" stroke="#D9F4FC" strokeWidth="2.5"><rect x="57" y="54" width="19" height="13" rx="5" /><rect x="84" y="54" width="19" height="13" rx="5" /><path d="M76 59h8" /></g>}
        {avatar.id === "camila" && <g fill="none" stroke="#FFCB57" strokeWidth="3"><circle cx="54" cy="69" r="6" /><circle cx="106" cy="69" r="6" /></g>}
        {avatar.id === "marta" && <><path d="M98 98v19" stroke="#DDE6FF" strokeWidth="2" /><rect x="91" y="112" width="15" height="18" rx="2" fill="#E8EEFF" /><path d="M95 117h7M95 121h7" stroke="#3658BD" strokeWidth="2" /></>}
        <g transform={`translate(${v.pose === "care" ? 80 : 105} ${v.pose === "care" ? 130 : 128}) scale(.7)`}>
          <circle r="27" fill="#F8F6EF" opacity=".94" />
          <PersonaObject object={avatar.object} color={avatar.color} ink="#182039" />
        </g>
      </g>
    </g>
    <g fill="none" strokeWidth="3.2" strokeLinecap="round">
      {layers.map((layer, layerIndex) => {
        const angle = -90 + layerIndex * 72 + layer * 5;
        const start = (angle - 18) * Math.PI / 180;
        const end = (angle + 18) * Math.PI / 180;
        const point = (a: number) => `${80 + Math.cos(a) * 74} ${80 + Math.sin(a) * 74}`;
        return <path key={layerIndex} d={`M${point(start)}A74 74 0 0 1 ${point(end)}`} stroke={["#70E1C0", "#FFD166", "#FF8A66", "#B999FF", "#77BFFF"][layer]} />;
      })}
    </g>
  </svg>;
}
