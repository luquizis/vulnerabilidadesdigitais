// Save before requesting entry, so a lost response cannot create a second pair.
export function joinTokenFor(code: string) {
  const key = `emd_pair_${code}`;
  let token = localStorage.getItem(key);
  if (!token) { token = crypto.randomUUID() + crypto.randomUUID(); localStorage.setItem(key, token); }
  return token;
}
