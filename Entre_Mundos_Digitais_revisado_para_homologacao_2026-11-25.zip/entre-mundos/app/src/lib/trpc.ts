import { createTRPCReact } from "@trpc/react-query";
import type { AppRouter } from "../../api/router";

// Cliente tRPC isolado do provider: o react-refresh exige que arquivos com
// componentes (TRPCProvider) exportem somente componentes.
export const trpc = createTRPCReact<AppRouter>();
