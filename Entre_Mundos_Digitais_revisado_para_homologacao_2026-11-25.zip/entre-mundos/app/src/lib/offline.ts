type Draft = { key: string; value: unknown; updatedAt: number };
export type QueuedSubmission = { id?: number; code: string; payload: Record<string, unknown>; createdAt: number };

const DB_NAME = "entre-mundos-digitais";
const DB_VERSION = 1;

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains("drafts")) db.createObjectStore("drafts", { keyPath: "key" });
      if (!db.objectStoreNames.contains("queue")) db.createObjectStore("queue", { keyPath: "id", autoIncrement: true });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function transaction<T>(store: "drafts" | "queue", mode: IDBTransactionMode, action: (objectStore: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, mode);
    const request = action(tx.objectStore(store));
    tx.oncomplete = () => { resolve(request.result); db.close(); };
    tx.onabort = () => { reject(tx.error || request.error || new Error("A gravação local foi cancelada.")); db.close(); };
    tx.onerror = () => { reject(tx.error || request.error); db.close(); };
  });
}

export async function saveDraft(key: string, value: unknown) {
  await transaction("drafts", "readwrite", (store) => store.put({ key, value, updatedAt: Date.now() } satisfies Draft));
}
export async function loadDraft<T>(key: string): Promise<T | undefined> {
  const result = await transaction("drafts", "readonly", (store) => store.get(key) as IDBRequest<Draft | undefined>);
  return result?.value as T | undefined;
}
export async function clearDraft(key: string) { await transaction("drafts", "readwrite", (store) => store.delete(key)); }
export async function enqueueSubmission(code: string, payload: Record<string, unknown>) {
  const db = await openDatabase();
  return new Promise<void>((resolve, reject) => {
    const tx = db.transaction("queue", "readwrite");
    const store = tx.objectStore("queue");
    const request = store.getAll() as IDBRequest<QueuedSubmission[]>;
    request.onsuccess = () => {
      const existing = request.result.find((row) => row.code === code && row.payload.token === payload.token && row.payload.stopId === payload.stopId);
      if (!existing) store.add({ code, payload, createdAt: Date.now() } satisfies QueuedSubmission);
    };
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onabort = () => { db.close(); reject(tx.error || new Error("Não foi possível guardar a resposta.")); };
  });
}
export async function pendingSubmissions(code: string, token?: string): Promise<QueuedSubmission[]> {
  const rows = await transaction("queue", "readonly", (store) => store.getAll() as IDBRequest<QueuedSubmission[]>);
  return rows.filter((row) => row.code === code && (!token || row.payload.token === token)).sort((a, b) => a.createdAt - b.createdAt);
}
export async function removeQueuedSubmission(id: number) { await transaction("queue", "readwrite", (store) => store.delete(id)); }
