import { useEffect, useState } from "react";

export type ConnectionMode = "sse" | "polling" | "offline";

export function useRealtime(code: string | undefined, onUpdate: () => void, role: "projection" | "team" | "mediator" = "projection", credential = ""): ConnectionMode {
  const [mode, setMode] = useState<ConnectionMode>("offline");
  useEffect(() => {
    if (!code || (role !== "projection" && !credential)) return;
    let disposed = false;
    let source: EventSource | null = null;
    let retry: ReturnType<typeof setTimeout> | undefined;
    let attempts = 0;
    let cursor = 0;
    const poll = setInterval(() => { if (!disposed && navigator.onLine) onUpdate(); }, 15000);
    const controller = new AbortController();
    async function connect() {
      if (disposed || !navigator.onLine) { if (!disposed) setMode("offline"); return; }
      source?.close();
      try {
        const result = await fetch("/api/events/ticket", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ code, role, credential }), signal: controller.signal });
        if (!result.ok) throw new Error("Não autorizado.");
        if (disposed) return;
        source = new EventSource(`/api/events?code=${encodeURIComponent(code!)}&role=${role}&cursor=${cursor}`);
        source.addEventListener("ready", () => { attempts = 0; setMode("sse"); onUpdate(); });
        source.addEventListener("update", (event) => {
          const seq = Number((event as MessageEvent).lastEventId);
          if (!Number.isSafeInteger(seq) || seq <= cursor) return;
          cursor = seq; onUpdate();
        });
        source.onerror = reconnect;
      } catch { if (!disposed) reconnect(); }
    }
    function reconnect() {
      source?.close();
      if (disposed) return;
      setMode(navigator.onLine ? "polling" : "offline");
      clearTimeout(retry);
      if (navigator.onLine) retry = setTimeout(() => { void connect(); }, Math.min(30000, 1000 * 2 ** Math.min(attempts++, 5)) + Math.random() * 500);
    }
    const online = () => { clearTimeout(retry); void connect(); };
    const offline = () => { source?.close(); clearTimeout(retry); setMode("offline"); };
    window.addEventListener("online", online); window.addEventListener("offline", offline);
    void connect();
    return () => { disposed = true; controller.abort(); source?.close(); clearTimeout(retry); clearInterval(poll); window.removeEventListener("online", online); window.removeEventListener("offline", offline); };
  }, [code, onUpdate, role, credential]);
  return mode;
}
