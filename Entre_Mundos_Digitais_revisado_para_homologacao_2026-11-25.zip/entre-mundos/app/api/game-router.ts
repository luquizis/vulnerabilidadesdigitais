import { randomInt } from "node:crypto";
import { z } from "zod";
import { and, asc, desc, eq } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { adminQuery, createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { gameSessions, moderationItems, responses, teams } from "@db/schema";
import { avatarBaseId, isAvatarProfileId, makeAvatarProfileId } from "@contracts/game";
import { appendEvent, findSession, hash, makeCode, makeToken, needsCarefulReview, parseList, publishEvent, requireMediator, requireTeam } from "./game-utils";

import { credentials, mediatorCredentials, submissionSchema } from "./inputs";
import { changeSession, moderateResponses } from "./session-control";
import { recordSubmission } from "./submission";
import { pinCurrentContent, sessionContent } from "./content";
import { canJoin, reviewSignals } from "../contracts/policy.ts";

async function publicProjection(code: string) {
  const session = await findSession(code);
  const content = await sessionContent(session);
  const db = getDb();
  const teamRows = await db.select().from(teams).where(eq(teams.sessionId, session.id)).orderBy(asc(teams.id));
  const responseRows = await db.select().from(responses).where(and(eq(responses.sessionId, session.id), eq(responses.stopId, session.currentStopId || ""))).orderBy(desc(responses.createdAt));
  const approvedRows = responseRows.length ? await db.select().from(moderationItems).where(eq(moderationItems.sessionId, session.id)) : [];
  const approved = new Set(approvedRows.filter((item) => item.status === "approved").map((item) => item.responseId));
  const publicResponses = responseRows.filter((row) => row.allowProjection).map((row) => ({
    id: row.id, choiceId: row.choiceId, sourceClassification: row.sourceClassification,
    ontoResponse: row.ontoResponse, ontoVisibility: row.ontoVisibility, skipped: row.skipped,
    justification: approved.has(row.id) ? row.justification : null,
    contestation: approved.has(row.id) ? row.contestation : null,
    candidateConcept: approved.has(row.id) ? row.candidateConcept : null,
  }));
  return {
    session: { id: session.id, code: session.publicCode, title: session.title, status: session.status, visibility: session.visibility, currentStopId: session.currentStopId, registrationOpen: session.registrationOpen, capacity: session.capacity },
    teams: teamRows.map((team) => ({ id: team.id, name: team.name, avatarId: team.avatarId, currentStopId: team.currentStopId, completed: parseList(team.completedStopIds).length, immunity: team.immunity })),
    responses: session.visibility === "reserved" ? [] : publicResponses,
    answerCount: publicResponses.length,
    stop: content.stops.find((stop) => stop.id === session.currentStopId) || null,
    contentVersionId: session.contentVersionId,
  };
}

async function assignAvatar(input: { code: string; token: string }, selected?: string) {
  const access = await requireTeam(input.code, input.token);
  return getDb().transaction(async (tx) => {
    const [session] = await tx.select().from(gameSessions).where(eq(gameSessions.id, access.session.id)).for("update");
    const [team] = await tx.select().from(teams).where(eq(teams.id, access.team.id)).for("update");
    if (session.status === "finished" || parseList(team.completedStopIds).length) throw new TRPCError({ code: "CONFLICT", message: "Não é possível trocar o avatar após a primeira resposta ou o encerramento." });
    const content = await sessionContent(session);
    let avatarId = selected;
    if (!avatarId) {
      const rows = await tx.select({ id: teams.id, avatarId: teams.avatarId }).from(teams).where(eq(teams.sessionId, session.id));
      const counts = new Map(content.avatars.map((persona) => [persona.id, 0]));
      for (const row of rows) if (row.id !== team.id && row.avatarId) { const base = avatarBaseId(row.avatarId); counts.set(base, (counts.get(base) || 0) + 1); }
      const min = Math.min(...counts.values());
      const candidates = content.avatars.filter((persona) => counts.get(persona.id) === min);
      avatarId = makeAvatarProfileId(candidates[randomInt(candidates.length)].id, Array.from({ length: 5 }, () => randomInt(3)));
    }
    if (!isAvatarProfileId(avatarId) || !content.avatars.some((persona) => persona.id === avatarBaseId(avatarId))) throw new TRPCError({ code: "BAD_REQUEST", message: "Avatar inválido para esta sessão." });
    await tx.update(teams).set({ avatarId }).where(eq(teams.id, team.id));
    await appendEvent(tx, session.id, "avatar_selected");
    return { ok: true, avatarId };
  });
}

export const gameRouter = createRouter({
  createSession: adminQuery.input(z.object({ title: z.string().trim().min(3).max(120), capacity: z.number().int().min(1).max(200).default(40) })).mutation(async ({ input }) => {
    const publicCode = makeCode();
    const mediatorKey = makeToken(18);
    const [{ id }] = await getDb().insert(gameSessions).values({ publicCode, mediatorKeyHash: hash(mediatorKey), title: input.title, capacity: input.capacity, contentVersionId: await pinCurrentContent() }).$returningId();
    await publishEvent(id, "session_created");
    return { code: publicCode, key: mediatorKey, id };
  }),

  join: publicQuery.input(z.object({ code: credentials.shape.code, joinToken: z.string().min(32).max(100) })).mutation(async ({ input }) => {
    const found = await findSession(input.code);
    return getDb().transaction(async (tx) => {
      const [session] = await tx.select().from(gameSessions).where(eq(gameSessions.id, found.id)).for("update");
      const tokenHash = hash(input.joinToken);
      const [existing] = await tx.select().from(teams).where(and(eq(teams.sessionId, session.id), eq(teams.pairTokenHash, tokenHash)));
      if (existing) return { token: input.joinToken, code: session.publicCode, teamId: existing.id };
      const rows = await tx.select({ id: teams.id }).from(teams).where(eq(teams.sessionId, session.id));
      if (!canJoin(session.status, session.registrationOpen, rows.length, session.capacity)) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "As inscrições estão encerradas ou a sessão atingiu sua capacidade." });
      const [{ id }] = await tx.insert(teams).values({ sessionId: session.id, pairTokenHash: tokenHash, joinKeyHash: tokenHash, name: "Dupla " + String(rows.length + 1).padStart(2, "0"), completedStopIds: "[]", lastSeenAt: new Date() }).$returningId();
      await appendEvent(tx, session.id, "team_joined");
      return { token: input.joinToken, code: session.publicCode, teamId: id };
    });
  }),

  resume: publicQuery.input(credentials).query(async ({ input }) => {
    const { session, team } = await requireTeam(input.code, input.token);
    return { session: { code: session.publicCode, title: session.title, status: session.status }, team: { id: team.id, name: team.name, avatarId: team.avatarId } };
  }),

  selectAvatar: publicQuery.input(credentials.extend({ avatarId: z.string().min(2).max(40) })).mutation(({ input }) => assignAvatar(input, input.avatarId)),
  randomAvatar: publicQuery.input(credentials).mutation(({ input }) => assignAvatar(input)),

  state: publicQuery.input(credentials).query(async ({ input }) => {
    const { session, team } = await requireTeam(input.code, input.token);
    const content = await sessionContent(session);
    await getDb().update(teams).set({ lastSeenAt: new Date() }).where(eq(teams.id, team.id));
    const ownResponses = await getDb().select({ stopId: responses.stopId, choiceId: responses.choiceId, skipped: responses.skipped, createdAt: responses.createdAt }).from(responses).where(eq(responses.teamId, team.id));
    return {
      session: { code: session.publicCode, title: session.title, status: session.status },
      team: { id: team.id, name: team.name, avatarId: team.avatarId, currentStopId: team.currentStopId, completedStopIds: parseList(team.completedStopIds), immunity: team.immunity },
      responses: ownResponses,
      stop: content.stops.find((stop) => stop.id === team.currentStopId) || null,
      contentVersionId: session.contentVersionId,
      content,
    };
  }),

  projection: publicQuery.input(z.object({ code: z.string().min(4).max(8) })).query(({ input }) => publicProjection(input.code)),

  submit: publicQuery.input(submissionSchema).mutation(({ input }) => recordSubmission(input)),

  skip: publicQuery.input(credentials.extend({ stopId: z.string().min(2).max(80), idempotencyKey: z.string().min(12).max(80) })).mutation(({ input }) => recordSubmission(submissionSchema.parse({ ...input, choiceId: "__skip__" }), true)),

  moderator: publicQuery.input(mediatorCredentials).query(async ({ input }) => {
    const session = await requireMediator(input.code, input.key);
    const db = getDb();
    const teamRows = await db.select().from(teams).where(eq(teams.sessionId, session.id)).orderBy(asc(teams.id));
    const responseRows = await db.select().from(responses).where(eq(responses.sessionId, session.id)).orderBy(desc(responses.createdAt));
    const moderation = await db.select().from(moderationItems).where(eq(moderationItems.sessionId, session.id));
    const moderationMap = new Map(moderation.map((item) => [item.responseId, item]));
    return {
      session: { id: session.id, code: session.publicCode, title: session.title, status: session.status, visibility: session.visibility, currentStopId: session.currentStopId, registrationOpen: session.registrationOpen, capacity: session.capacity },
      teams: teamRows.map((team) => ({ id: team.id, name: team.name, avatarId: team.avatarId, currentStopId: team.currentStopId, completed: parseList(team.completedStopIds).length, immunity: team.immunity, lastSeenAt: team.lastSeenAt })),
      content: await sessionContent(session),
      responses: responseRows.map((row) => ({
        id: row.id, teamId: row.teamId, stopId: row.stopId, choiceId: row.choiceId, sourceClassification: row.sourceClassification,
        hiddenFactor: row.hiddenFactor, hiddenFactorUnknown: row.hiddenFactorUnknown, justification: row.justification, contestation: row.contestation,
        candidateConcept: row.candidateConcept, allowProjection: row.allowProjection, skipped: row.skipped, createdAt: row.createdAt,
        moderationStatus: moderationMap.get(row.id)?.status || null,
        reviewSignals: [row.hiddenFactor, row.justification, row.contestation, row.candidateConcept].flatMap(reviewSignals),
        needsCarefulReview: [row.hiddenFactor, row.justification, row.contestation, row.candidateConcept].some(needsCarefulReview),
      })),
    };
  }),

  start: publicQuery.input(mediatorCredentials).mutation(({ input }) => changeSession(input, "start")),
  finish: publicQuery.input(mediatorCredentials).mutation(({ input }) => changeSession(input, "finish")),
  setRegistration: publicQuery.input(mediatorCredentials.extend({ open: z.boolean() })).mutation(({ input }) => changeSession(input, "registration", input.open)),
  setVisibility: publicQuery.input(mediatorCredentials.extend({ visibility: z.enum(["reserved", "open", "debate"]) })).mutation(({ input }) => changeSession(input, "visibility", input.visibility)),
  setStop: publicQuery.input(mediatorCredentials.extend({ stopId: z.string().min(2).max(80) })).mutation(({ input }) => changeSession(input, "stop", input.stopId)),
  moderate: publicQuery.input(mediatorCredentials.extend({ responseId: z.number().int().positive(), decision: z.enum(["approved", "rejected", "hidden", "revision_requested"]), note: z.string().max(1000).optional() })).mutation(({ input }) => moderateResponses({ ...input, responseIds: [input.responseId] })),
  moderateBatch: publicQuery.input(mediatorCredentials.extend({ responseIds: z.array(z.number().int().positive()).min(1).max(40), decision: z.enum(["approved", "rejected", "hidden", "revision_requested"]), note: z.string().max(1000).optional() })).mutation(({ input }) => moderateResponses(input)),
});
