import { eq } from "drizzle-orm";
import { createHash } from "node:crypto";
import { TRPCError } from "@trpc/server";
import { avatars, avatarLayerFamilies, phases, stops, optionSets, privacyGroups, hateDimensions, ontologyProvenance } from "../contracts/game.ts";
import { taxonomyVersions, type GameSession } from "@db/schema";
import { getDb } from "./queries/connection";

export const suppliedContent = { format: 1, avatars, avatarLayerFamilies, phases, stops, optionSets, privacyGroups, hateDimensions, ontologyProvenance };
export type ContentSnapshot = typeof suppliedContent;

export async function pinCurrentContent() {
  const snapshot = JSON.stringify(suppliedContent);
  const digest = createHash("sha256").update(snapshot).digest("hex");
  const db = getDb();
  // Unique digest provides deduplication. Do not update an existing snapshot.
  await db.insert(taxonomyVersions).values({ digest, snapshot }).onDuplicateKeyUpdate({ set: { digest } });
  const version = await db.query.taxonomyVersions.findFirst({ where: eq(taxonomyVersions.digest, digest) });
  if (!version) throw new Error("Não foi possível preservar a versão do conteúdo.");
  return version.id;
}

export async function sessionContent(session: Pick<GameSession, "contentVersionId">): Promise<ContentSnapshot> {
  if (!session.contentVersionId) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Sessão anterior sem versão comprovada. Exporte os dados históricos e crie uma nova sessão para continuar." });
  const version = await getDb().query.taxonomyVersions.findFirst({ where: eq(taxonomyVersions.id, session.contentVersionId) });
  if (!version || createHash("sha256").update(version.snapshot).digest("hex") !== version.digest) throw new Error("A versão do conteúdo está ausente ou foi alterada.");
  return JSON.parse(version.snapshot) as ContentSnapshot;
}
