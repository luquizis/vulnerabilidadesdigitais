import { z } from "zod";

export const credentials = z.object({ code: z.string().trim().toUpperCase().regex(/^[A-HJ-NP-Z2-9]{6}$/), token: z.string().min(12).max(100) });
export const mediatorCredentials = z.object({ code: credentials.shape.code, key: z.string().min(12).max(100) });
export const submissionSchema = credentials.extend({
  stopId: z.string().min(2).max(80), idempotencyKey: z.string().min(12).max(80), choiceId: z.string().min(1).max(80),
  sourceClassification: z.string().max(80).optional(), ontoType: z.string().max(80).optional(), ontoIntensity: z.string().max(80).optional(),
  ontoScale: z.string().max(80).optional(), ontoOrigin: z.string().max(80).optional(), ontoManifestation: z.string().max(80).optional(),
  ontoVisibility: z.string().max(80).optional(), ontoObstacle: z.string().max(80).optional(), ontoResponse: z.string().max(80).optional(),
  privacyGroup: z.string().max(100).optional(), privacyProblems: z.array(z.string().max(180)).max(16).default([]),
  hiddenFactor: z.string().max(600).optional(), hiddenFactorUnknown: z.boolean().default(false),
  hateMapping: z.enum(["exact", "close", "related", "none"]).default("none"), hateDimensions: z.array(z.string().max(100)).max(10).default([]),
  experience: z.enum(["vivenciada", "observada", "conhecida", "imaginada", "nao_informar"]).optional(),
  contributionKind: z.enum(["agreement", "contestation", "proposal", "unspecified"]).default("unspecified"),
  justification: z.string().max(800).optional(), contestation: z.string().max(800).optional(), candidateConcept: z.string().max(120).optional(),
  allowProjection: z.boolean().default(true),
});
