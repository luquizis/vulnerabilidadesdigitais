import { authRouter } from "./auth-router";
import { gameRouter } from "./game-router";
import { researchRouter } from "./research-router";
import { adminRouter } from "./admin-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  game: gameRouter,
  research: researchRouter,
  admin: adminRouter,
});

export type AppRouter = typeof appRouter;
