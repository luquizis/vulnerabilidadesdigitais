import { Hono } from "hono";
import { streamSSE } from "hono/streaming";
import { getCookie, setCookie } from "hono/cookie";
import { and, asc, eq, gt } from "drizzle-orm";
import { z } from "zod";
import { findSession, requireMediator, requireTeam } from "../game-utils";
import { getDb } from "../queries/connection";
import { sessionEvents, teams } from "@db/schema";
import { env } from "../lib/env";
import { parseCursor, publicEvent } from "../../contracts/policy.ts";
import { signStreamTicket, verifyStreamTicket } from "../domain/stream-ticket.ts";

export const eventRoutes = new Hono();
const ticketInput = z.object({ code: z.string().regex(/^[A-HJ-NP-Z2-9]{6}$/), role: z.enum(["team", "mediator", "projection"]), credential: z.string().max(100).default("") });
const cookieName = (code: string, role: string) => `emd_stream_${code}_${role}`;

eventRoutes.post("/ticket", async (c) => {
  const parsed = ticketInput.safeParse(await c.req.json().catch(() => null));
  if (!parsed.success) return c.json({ error: "Acesso inválido." }, 400);
  const { code, role, credential } = parsed.data;
  let subject = "public";
  try {
    if (role === "team") { const access = await requireTeam(code, credential); subject = access.team.pairTokenHash; }
    else if (role === "mediator") { const session = await requireMediator(code, credential); subject = session.mediatorKeyHash; }
    else await findSession(code);
    const ticket = signStreamTicket({ code, role, subject, expires: Date.now() + 120000 }, env.sessionSecret);
    setCookie(c, cookieName(code, role), ticket, { httpOnly: true, secure: env.isProduction, sameSite: "Strict", path: "/api/events", maxAge: 120 });
    c.header("Cache-Control", "no-store");
    return c.json({ ok: true });
  } catch { return c.json({ error: "Acesso não autorizado." }, 403); }
});

eventRoutes.get("/", async (c) => {
  const code = c.req.query("code") || "";
  const role = c.req.query("role") || "projection";
  let cursor: number;
  let ticket: ReturnType<typeof verifyStreamTicket>;
  try {
    cursor = parseCursor(c.req.header("Last-Event-ID") || c.req.query("cursor"));
    ticket = verifyStreamTicket(getCookie(c, cookieName(code, role)) || "", env.sessionSecret);
    if (ticket.code !== code || ticket.role !== role) throw new Error("Escopo inválido.");
  } catch { return c.json({ error: "Acesso ou cursor inválido." }, 403); }
  const session = await findSession(code);
  const allowed = async () => {
    if (ticket.expires <= Date.now()) return false;
    if (role === "projection") return true;
    if (role === "mediator") return (await findSession(code)).mediatorKeyHash === ticket.subject;
    return Boolean(await getDb().query.teams.findFirst({ where: and(eq(teams.sessionId, session.id), eq(teams.pairTokenHash, ticket.subject)) }));
  };
  if (!await allowed()) return c.json({ error: "Acesso revogado." }, 403);
  c.header("Cache-Control", "no-store");
  c.header("X-Accel-Buffering", "no");
  return streamSSE(c, async (stream) => {
    let closed = false;
    stream.onAbort(() => { closed = true; });
    // Durable replay works across server processes without accumulating listeners.
    await stream.writeSSE({ event: "ready", data: "{}" });
    try {
      while (!closed && await allowed()) {
        const missed = await getDb().select().from(sessionEvents).where(and(eq(sessionEvents.sessionId, session.id), gt(sessionEvents.seq, cursor))).orderBy(asc(sessionEvents.seq)).limit(200);
        for (const event of missed) {
          if (closed) break;
          const visible = publicEvent(event.type, ticket.role, {});
          await stream.writeSSE({ id: String(event.seq), event: "update", data: JSON.stringify({ seq: event.seq, ...visible }) });
          cursor = event.seq;
        }
        if (missed.length === 200) continue;
        await stream.writeSSE({ event: "ping", data: "{}" });
        await new Promise((resolve) => setTimeout(resolve, 2000));
      }
    } catch { /* Browser reconnects using its last committed cursor. */ }
  });
});
