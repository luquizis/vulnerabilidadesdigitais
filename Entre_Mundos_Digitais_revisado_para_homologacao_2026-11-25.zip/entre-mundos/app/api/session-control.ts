import { and, eq, inArray } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { gameSessions, moderationItems, reviewDecisions } from "@db/schema";
import { getDb } from "./queries/connection";
import { appendEvent, requireMediator } from "./game-utils";
import { mayTransition } from "../contracts/policy.ts";
import { sessionContent } from "./content";

export async function changeSession(input: { code: string; key: string }, action: "start" | "finish" | "registration" | "stop" | "visibility", value?: string | boolean) {
  const access = await requireMediator(input.code, input.key);
  return getDb().transaction(async (tx) => {
    const [session] = await tx.select().from(gameSessions).where(eq(gameSessions.id, access.id)).for("update");
    if (session.status === "finished") throw new TRPCError({ code: "CONFLICT", message: "A sessão já foi encerrada." });
    const content = await sessionContent(session);
    const changes: Partial<typeof gameSessions.$inferInsert> = {};
    if (action === "start" || action === "finish") {
      const status = action === "start" ? "active" : "finished";
      if (!mayTransition(session.status, status)) throw new TRPCError({ code: "CONFLICT", message: "Transição de sessão inválida." });
      changes.status = status; changes.registrationOpen = false;
      changes.currentStopId = action === "finish" ? "pr-1" : session.currentStopId || "in-1";
    } else if (action === "registration") {
      if (session.status === "active") throw new TRPCError({ code: "CONFLICT", message: "As inscrições não podem mudar durante a travessia." });
      changes.registrationOpen = Boolean(value); changes.status = value ? "lobby" : "closed";
    } else if (action === "stop") {
      if (session.status !== "active" || !content.stops.some((stop) => stop.id === value)) throw new TRPCError({ code: "BAD_REQUEST", message: "Inicie a sessão e escolha uma parada válida." });
      changes.currentStopId = String(value);
    } else {
      if (!["reserved", "open", "debate"].includes(String(value))) throw new TRPCError({ code: "BAD_REQUEST", message: "Visibilidade inválida." });
      changes.visibility = value as "reserved" | "open" | "debate";
    }
    await tx.update(gameSessions).set(changes).where(eq(gameSessions.id, session.id));
    await appendEvent(tx, session.id, `session_${action}_changed`);
    return { ok: true };
  });
}

export type ModerationDecision = "approved" | "rejected" | "hidden" | "revision_requested";
export async function moderateResponses(input: { code: string; key: string; responseIds: number[]; decision: ModerationDecision; note?: string }) {
  const session = await requireMediator(input.code, input.key);
  return getDb().transaction(async (tx) => {
    await tx.select({ id: gameSessions.id }).from(gameSessions).where(eq(gameSessions.id, session.id)).for("update");
    const items = await tx.select().from(moderationItems).where(and(eq(moderationItems.sessionId, session.id), inArray(moderationItems.responseId, input.responseIds))).for("update");
    if (items.length !== new Set(input.responseIds).size) throw new TRPCError({ code: "NOT_FOUND", message: "Há respostas fora desta sessão ou sem texto para moderar." });
    for (const item of items) {
      await tx.insert(reviewDecisions).values({ sessionId: session.id, responseId: item.responseId, actor: `mediator:${session.id}`, kind: "moderation", previousStatus: item.status, decision: input.decision, note: input.note || null });
      await tx.update(moderationItems).set({ status: input.decision }).where(eq(moderationItems.id, item.id));
    }
    await appendEvent(tx, session.id, "moderation_decided");
    return { ok: true };
  });
}
