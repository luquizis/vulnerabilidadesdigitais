// Process-local protection. Configure a shared gateway limiter for multiple replicas.
export class RateLimiter {
  private buckets = new Map<string, { count: number; until: number }>();
  consume(key: string, limit: number, windowMs: number, now = Date.now()) {
    for (const [id, bucket] of this.buckets) if (bucket.until <= now) this.buckets.delete(id);
    let bucket = this.buckets.get(key);
    if (!bucket) {
      if (this.buckets.size >= 5000) return false;
      bucket = { count: 0, until: now + windowMs }; this.buckets.set(key, bucket);
    }
    return ++bucket.count <= limit;
  }
}
