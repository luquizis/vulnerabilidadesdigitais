import { createHmac, timingSafeEqual } from "node:crypto";

export type StreamTicket = { code: string; role: "projection" | "team" | "mediator"; subject: string; expires: number };
export function signStreamTicket(ticket: StreamTicket, secret: string) {
  if (secret.length < 32) throw new Error("SESSION_SECRET deve ter pelo menos 32 caracteres.");
  const body = Buffer.from(JSON.stringify(ticket)).toString("base64url");
  return `${body}.${createHmac("sha256", secret).update(body).digest("base64url")}`;
}
export function verifyStreamTicket(value: string, secret: string, now = Date.now()): StreamTicket {
  if (secret.length < 32 || value.length > 1000) throw new Error("Credencial inválida.");
  const [body, signature, extra] = value.split(".");
  if (!body || !signature || extra) throw new Error("Credencial inválida.");
  const expected = createHmac("sha256", secret).update(body).digest();
  const supplied = Buffer.from(signature, "base64url");
  if (expected.length !== supplied.length || !timingSafeEqual(expected, supplied)) throw new Error("Credencial inválida.");
  const ticket = JSON.parse(Buffer.from(body, "base64url").toString()) as StreamTicket;
  if (!Number.isFinite(ticket.expires) || ticket.expires <= now || !["projection", "team", "mediator"].includes(ticket.role)) throw new Error("Credencial expirada.");
  return ticket;
}
