import type { Stop } from "../../contracts/game.ts";

export type RecordedAnswer = { id: number; stopId: string; choiceId: string | null; skipped: boolean; nextStopId?: string | null };

export function recordedResult(answer: RecordedAnswer, stops: Record<string, Stop>) {
  const stop = stops[answer.stopId];
  const next = answer.nextStopId || (answer.skipped ? stop?.choices[0]?.next : stop?.choices.find((choice) => choice.id === answer.choiceId)?.next) || "finished";
  return { ok: true as const, duplicate: true, next, responseId: answer.id };
}

export function validateClassification(input: Record<string, unknown>, vocabulary: {
  optionSets: Record<string, readonly (readonly string[])[]>;
  privacyGroups: { id: string; group: string; items: readonly (readonly string[])[] }[];
  hateDimensions: readonly (readonly string[])[];
}, required = false) {
  const axes: Record<string, string> = { sourceClassification: "source", ontoType: "type", ontoIntensity: "intensity", ontoScale: "scale", ontoOrigin: "origin", ontoManifestation: "manifestation", ontoVisibility: "visibility", ontoObstacle: "obstacle", ontoResponse: "response" };
  if (required && Object.keys(axes).some((field) => !input[field])) throw new Error("Complete as classificações; a opção não sei é válida.");
  if (required && !input.hiddenFactorUnknown && !String(input.hiddenFactor || "").trim()) throw new Error("Registre uma hipótese ou indique que ainda não sabe identificar.");
  for (const [field, axis] of Object.entries(axes)) {
    if (input[field] && !vocabulary.optionSets[axis]?.some(([, id]) => id === input[field])) throw new Error(`Classificação inválida: ${field}.`);
  }
  const privacy = new Set(["unknown", ...vocabulary.privacyGroups.flatMap((group) => group.items.map(([, id]) => id))]);
  const hate = new Set(vocabulary.hateDimensions.map(([, id]) => id));
  const privacyValues = (input.privacyProblems || []) as string[];
  if (privacyValues.some((id) => !privacy.has(id)) || (privacyValues.includes("unknown") && privacyValues.length > 1)) throw new Error("Problema de privacidade inválido.");
  if (((input.hateDimensions || []) as string[]).some((id) => !hate.has(id))) throw new Error("Dimensão OntoHate inválida.");
  if (input.hateMapping === "none" && ((input.hateDimensions || []) as string[]).length) throw new Error("Remova as dimensões quando OntoHate não se aplica.");
  if (input.privacyGroup && !vocabulary.privacyGroups.some((group) => group.group === input.privacyGroup || group.id === input.privacyGroup)) throw new Error("Grupo de privacidade inválido.");
}
