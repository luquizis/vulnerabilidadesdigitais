import { createHash, randomBytes } from "node:crypto";
import { EventEmitter } from "node:events";
import { and, eq, sql } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { getDb } from "./queries/connection";
import { gameSessions, sessionEvents, teams } from "@db/schema";
import { reviewSignals } from "../contracts/policy.ts";

export const realtime = new EventEmitter();
realtime.setMaxListeners(200);

export const hash = (value: string) => createHash("sha256").update(value).digest("hex");
export const makeToken = (size = 24) => randomBytes(size).toString("base64url");

export function makeCode(length = 6) {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = randomBytes(length);
  return Array.from(bytes, (byte) => alphabet[byte % alphabet.length]).join("");
}

export async function findSession(code: string) {
  if (!/^[A-HJ-NP-Z2-9]{6}$/.test(code.trim().toUpperCase())) throw new TRPCError({ code: "BAD_REQUEST", message: "Código de sessão inválido." });
  const session = await getDb().query.gameSessions.findFirst({ where: eq(gameSessions.publicCode, code.trim().toUpperCase()) });
  if (!session) throw new TRPCError({ code: "NOT_FOUND", message: "Sessão não encontrada. Confira o código." });
  return session;
}

export async function requireMediator(code: string, key: string) {
  const session = await findSession(code);
  if (session.mediatorKeyHash !== hash(key)) throw new TRPCError({ code: "UNAUTHORIZED", message: "Chave de mediação inválida." });
  return session;
}

export async function requireTeam(code: string, token: string) {
  const session = await findSession(code);
  const team = await getDb().query.teams.findFirst({ where: and(eq(teams.sessionId, session.id), eq(teams.pairTokenHash, hash(token))) });
  if (!team) throw new TRPCError({ code: "UNAUTHORIZED", message: "Não foi possível retomar esta dupla. Entre novamente com o código da sessão." });
  return { session, team };
}

export async function publishEvent(sessionId: number, type: string, payload: Record<string, unknown> = {}) {
  const event = await getDb().transaction(async (tx) => appendEvent(tx, sessionId, type, payload));
  realtime.emit(`session:${sessionId}`, event);
  return event;
}

export type GameTransaction = Parameters<Parameters<ReturnType<typeof getDb>["transaction"]>[0]>[0];

export async function appendEvent(tx: GameTransaction, sessionId: number, type: string, payload: Record<string, unknown> = {}) {
    await tx.select({ id: gameSessions.id }).from(gameSessions).where(eq(gameSessions.id, sessionId)).for("update");
    const [row] = await tx.select({ max: sql<number>`coalesce(max(${sessionEvents.seq}), 0)` }).from(sessionEvents).where(eq(sessionEvents.sessionId, sessionId));
    const seq = Number(row?.max ?? 0) + 1;
    const [inserted] = await tx.insert(sessionEvents).values({ sessionId, seq, type, payload: JSON.stringify(payload) }).$returningId();
    return { id: inserted.id, sessionId, seq, type, payload };
}

export function parseList(value: string | null | undefined): string[] {
  try { const parsed = JSON.parse(value || "[]"); return Array.isArray(parsed) ? parsed.filter((item) => typeof item === "string") : []; }
  catch { return []; }
}

// Remove caracteres de controle sem regex de faixa (no-control-regex): filtra por
// ponto de codigo, preservando tabulacao e quebras de linha (\t, \n, \r).
export const safeText = (value: string | null | undefined) => {
  if (!value) return null;
  const cleaned = Array.from(value).filter((char) => {
    const code = char.codePointAt(0) ?? 0;
    return code >= 0x20 || code === 0x09 || code === 0x0a || code === 0x0d;
  }).join("").trim();
  return cleaned || null;
};

export function needsCarefulReview(value: string | null | undefined) {
  return reviewSignals(value).length > 0;
}
