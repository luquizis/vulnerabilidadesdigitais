import { z } from "zod";
import { desc, eq, inArray, sql, and, isNotNull, ne } from "drizzle-orm";
import type { Column } from "drizzle-orm";
import ExcelJS from "exceljs";
import { authedQuery, createRouter } from "./middleware";
import { getDb } from "./queries/connection";
import { candidateConcepts, gameSessions, responses, teams, taxonomyVersions, reviewDecisions } from "@db/schema";
import { ontologyProvenance, optionSets, privacyGroups } from "@contracts/game";
import { csvCell, ttlLiteral } from "./domain/export-text.ts";
import { researchAccess } from "./access";
import { parseList } from "./game-utils";
import { TRPCError } from "@trpc/server";

export const researchFilters = ["all", "invisible", "contested", "concepts", "hate"] as const;
export type ResearchFilter = typeof researchFilters[number];

function filterCondition(filter: ResearchFilter) {
  if (filter === "invisible") return eq(responses.ontoVisibility, "ontovuldig:MC3_Invisivel");
  if (filter === "contested") return and(isNotNull(responses.contestation), ne(responses.contestation, ""));
  if (filter === "concepts") return and(isNotNull(responses.candidateConcept), ne(responses.candidateConcept, ""));
  if (filter === "hate") return ne(responses.hateMapping, "none");
  return undefined;
}

function accessCondition(ids: number[], column: Column) {
  return ids.length ? inArray(column, ids) : sql`false`;
}

async function researchRows(ids: number[], options: { offset?: number; limit?: number; filter?: ResearchFilter } = {}) {
  const db = getDb();
  const conditions = [accessCondition(ids, responses.sessionId)];
  const filtered = options.filter ? filterCondition(options.filter) : undefined;
  if (filtered) conditions.push(filtered);
  const base = db.select({ response: responses, teamName: teams.name, sessionCode: gameSessions.publicCode, sessionTitle: gameSessions.title, contentVersionId: gameSessions.contentVersionId, snapshot: taxonomyVersions.snapshot, digest: taxonomyVersions.digest })
    .from(responses).innerJoin(teams, eq(responses.teamId, teams.id)).innerJoin(gameSessions, eq(responses.sessionId, gameSessions.id))
    .leftJoin(taxonomyVersions, eq(gameSessions.contentVersionId, taxonomyVersions.id))
    // Ordem determinística por id: createdAt tem precisão de segundo e empataria páginas.
    .orderBy(desc(responses.id));
  const scoped = base.where(and(...conditions));
  if (options.limit !== undefined) return scoped.limit(options.limit).offset(options.offset ?? 0);
  return scoped;
}

function flatRow(row: Awaited<ReturnType<typeof researchRows>>[number], includeExperience: boolean) {
  const r = row.response;
  const snapshot = row.snapshot ? JSON.parse(row.snapshot) as { ontologyProvenance: typeof ontologyProvenance; stops: { id: string; phase: string }[] } : null;
  const provenance = snapshot?.ontologyProvenance;
  return {
    resposta_id: r.id, sessao: row.sessionCode, sessao_titulo: row.sessionTitle, dupla: row.teamName, parada: r.stopId,
    fase: snapshot?.stops.find((stop) => stop.id === r.stopId)?.phase || "não comprovada", escolha: r.choiceId || "pulada", origem_vulnerabilidade: r.sourceClassification || "", mc1_tipo: r.ontoType || "",
    mc1_intensidade: r.ontoIntensity || "", mc1_escala: r.ontoScale || "", mc2_origem: r.ontoOrigin || "",
    mc3_manifestacao: r.ontoManifestation || "", mc3_visibilidade: r.ontoVisibility || "", mc4_obstaculo: r.ontoObstacle || "",
    mc5_resposta: r.ontoResponse || "", privacidade_grupo: r.privacyGroup || "", privacidade_problemas: parseList(r.privacyProblems).join(" | "),
    fator_invisivel: r.hiddenFactorUnknown ? "não sei" : r.hiddenFactor || "", relacao_ontohate: r.hateMapping,
    ontohate_dimensoes: parseList(r.hateDimensions).join(" | "), experiencia_privada: includeExperience ? r.experience || "não informado" : "acesso restrito",
    justificativa: r.justification || "", contestacao: r.contestation || "", conceito_candidato: r.candidateConcept || "",
    permite_projecao: r.allowProjection ? "sim" : "não", pulada: r.skipped ? "sim" : "não", criado_em: r.createdAt.toISOString(),
    contribuicao: r.contributionKind, visibilidade_no_envio: r.visibilityAtSubmit || "não registrada",
    versao_conteudo: row.contentVersionId, hash_conteudo: row.digest || "legado sem versão comprovada",
    proveniencia_ontovuldig: provenance?.ontoVulDig || "não comprovada", proveniencia_privacidade: provenance?.privacy || "não comprovada", proveniencia_ontohate: provenance?.ontoHate || "não comprovada",
  };
}

export const researchRouter = createRouter({
  overview: authedQuery.input(z.object({ sessionId: z.number().int().positive().optional() }).optional()).query(async ({ input, ctx }) => {
    const db = getDb();
    const access = await researchAccess(ctx.user, input?.sessionId);
    const sessionRows = await db.select({ session: gameSessions, digest: taxonomyVersions.digest }).from(gameSessions)
      .leftJoin(taxonomyVersions, eq(gameSessions.contentVersionId, taxonomyVersions.id))
      .where(accessCondition(access.ids, gameSessions.id)).orderBy(desc(gameSessions.createdAt));
    const candidateRows = await db.select({ candidate: candidateConcepts, teamName: teams.name, sessionCode: gameSessions.publicCode })
      .from(candidateConcepts).innerJoin(teams, eq(candidateConcepts.teamId, teams.id)).innerJoin(gameSessions, eq(candidateConcepts.sessionId, gameSessions.id))
      .where(accessCondition(access.ids, candidateConcepts.sessionId)).orderBy(desc(candidateConcepts.createdAt));
    const teamRows = await db.select().from(teams).where(accessCondition(access.ids, teams.sessionId));
    const [{ total }] = await db.select({ total: sql<number>`count(*)` }).from(responses).where(accessCondition(access.ids, responses.sessionId));
    // Agregados calculados no banco: a visão geral não carrega mais as respostas.
    const sourceCounts = await db.select({ id: responses.sourceClassification, count: sql<number>`count(*)` }).from(responses).where(accessCondition(access.ids, responses.sessionId)).groupBy(responses.sourceClassification);
    const stopCounts = await db.select({ id: responses.stopId, count: sql<number>`count(*)` }).from(responses).where(accessCondition(access.ids, responses.sessionId)).groupBy(responses.stopId);
    return {
      sessions: sessionRows.map((row) => ({ id: row.session.id, code: row.session.publicCode, title: row.session.title, status: row.session.status, createdAt: row.session.createdAt, contentVersionId: row.session.contentVersionId, contentHash: row.digest || null })),
      teams: teamRows.filter((t) => !input?.sessionId || t.sessionId === input.sessionId).map((t) => ({ id: t.id, sessionId: t.sessionId, name: t.name, avatarId: t.avatarId, completed: parseList(t.completedStopIds).length, immunity: t.immunity })),
      responseCount: Number(total),
      sourceCounts: sourceCounts.map((row) => ({ id: row.id || "", count: Number(row.count) })),
      stopCounts: stopCounts.map((row) => ({ id: row.id, count: Number(row.count) })),
      candidates: candidateRows.filter((c) => !input?.sessionId || c.candidate.sessionId === input.sessionId).map((c) => ({ ...c.candidate, teamName: c.teamName, sessionCode: c.sessionCode })),
      provenance: ontologyProvenance,
    };
  }),

  // Consulta paginada das classificações: o overview não carrega mais respostas em
  // memória; a leitura analítica usa páginas com filtro aplicado no banco.
  // O campo chama-se cursor para integrar com useInfiniteQuery; semanticamente é um deslocamento.
  responsesPage: authedQuery.input(z.object({
    sessionId: z.number().int().positive().optional(),
    filter: z.enum(researchFilters).default("all"),
    cursor: z.number().int().min(0).default(0),
    limit: z.number().int().min(1).max(200).default(50),
  })).query(async ({ input, ctx }) => {
    const access = await researchAccess(ctx.user, input.sessionId);
    const conditions = [accessCondition(access.ids, responses.sessionId)];
    const filtered = filterCondition(input.filter);
    if (filtered) conditions.push(filtered);
    const [{ total }] = await getDb().select({ total: sql<number>`count(*)` }).from(responses).where(and(...conditions));
    const rows = await researchRows(access.ids, { offset: input.cursor, limit: input.limit, filter: input.filter });
    return {
      total: Number(total),
      nextCursor: input.cursor + rows.length < Number(total) ? input.cursor + rows.length : null,
      rows: rows.map((row) => flatRow(row, access.experience(row.response.sessionId))),
    };
  }),

  curate: authedQuery.input(z.object({ id: z.number().int().positive(), status: z.enum(["proposed", "accepted", "related", "setaside"]), mappedClass: z.string().max(160).optional(), note: z.string().max(1000).optional() })).mutation(async ({ input, ctx }) => {
    const candidate = await getDb().query.candidateConcepts.findFirst({ where: eq(candidateConcepts.id, input.id) });
    if (!candidate) throw new TRPCError({ code: "NOT_FOUND", message: "Conceito inexistente." });
    await researchAccess(ctx.user, candidate.sessionId, "curate");
    const session = await getDb().query.gameSessions.findFirst({ where: eq(gameSessions.id, candidate.sessionId) });
    const version = session?.contentVersionId ? await getDb().query.taxonomyVersions.findFirst({ where: eq(taxonomyVersions.id, session.contentVersionId) }) : null;
    if (input.mappedClass) {
      if (!version) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Vocabulário histórico não comprovado." });
      const snapshot = JSON.parse(version.snapshot) as { optionSets: typeof optionSets; privacyGroups: typeof privacyGroups; hateDimensions: string[][] };
      const ids = [...Object.values(snapshot.optionSets).flatMap((v) => v.map(([, id]) => String(id))), ...snapshot.privacyGroups.flatMap((g) => g.items.map(([, id]) => id)), ...snapshot.hateDimensions.map(([, id]) => id)];
      if (!ids.includes(input.mappedClass)) throw new TRPCError({ code: "BAD_REQUEST", message: "A classe não existe no vocabulário desta sessão." });
    }
    await getDb().transaction(async (tx) => {
      const [locked] = await tx.select().from(candidateConcepts).where(eq(candidateConcepts.id, input.id)).for("update");
      await tx.update(candidateConcepts).set({ status: input.status, mappedClass: input.mappedClass || null, curatorNote: input.note || null }).where(eq(candidateConcepts.id, input.id));
      await tx.insert(reviewDecisions).values({ sessionId: candidate.sessionId, responseId: candidate.responseId, actor: "user:" + ctx.user.id, kind: "curation", previousStatus: locked.status, decision: input.status, note: input.note || null, mappedClass: input.mappedClass || null });
    });
    return { ok: true, curator: ctx.user.id };
  }),

  export: authedQuery.input(z.object({ sessionId: z.number().int().positive().optional(), format: z.enum(["csv", "xlsx", "jsonld", "ttl"]) })).mutation(async ({ input, ctx }) => {
    const access = await researchAccess(ctx.user, input.sessionId, "export");
    const originalRows = await researchRows(access.ids);
    const rows = originalRows.map((row) => flatRow(row, access.experience(row.response.sessionId)));
    if (!rows.length) throw new TRPCError({ code: "BAD_REQUEST", message: "Ainda não há respostas para exportar neste recorte." });
    const suffix = input.sessionId ? `sessao_${input.sessionId}` : "todas_as_sessoes";
    if (input.format === "csv") {
      const headers = Object.keys(rows[0]);
      const csv = `\uFEFF${headers.map(csvCell).join(",")}\n${rows.map((row) => headers.map((key) => csvCell(row[key as keyof typeof row])).join(",")).join("\n")}`;
      return { filename: `entre_mundos_${suffix}.csv`, mime: "text/csv;charset=utf-8", base64: Buffer.from(csv).toString("base64") };
    }
    if (input.format === "jsonld") {
      const graph = rows.map((row) => ({
        "@id": `https://entre-mundos.local/response/${row.resposta_id}`, "@type": "ontovuldig:ClassificacaoDidatica",
        "prov:wasGeneratedBy": { "@id": `https://entre-mundos.local/session/${row.sessao}` },
        "ontovuldig:stop": row.parada, "ontovuldig:sourceClassification": row.origem_vulnerabilidade,
        "ontovuldig:mc1Type": row.mc1_tipo, "ontovuldig:mc1Intensity": row.mc1_intensidade, "ontovuldig:mc1Scale": row.mc1_escala,
        "ontovuldig:mc2Origin": row.mc2_origem, "ontovuldig:mc3Manifestation": row.mc3_manifestacao, "ontovuldig:mc3Visibility": row.mc3_visibilidade,
        "ontovuldig:mc4Obstacle": row.mc4_obstaculo, "ontovuldig:mc5Response": row.mc5_resposta,
        "ontovuldig:team": row.dupla, "ontovuldig:choice": row.escolha,
        "privacy:group": row.privacidade_grupo || undefined,
        "privacy:problem": row.privacidade_problemas.split(" | ").filter(Boolean), "ontohate:mappingState": row.relacao_ontohate,
        "ontohate:dimension": row.ontohate_dimensoes.split(" | ").filter(Boolean), "ontovuldig:candidateConcept": row.conceito_candidato || undefined,
        "ontovuldig:hiddenFactor": row.fator_invisivel || undefined, "ontovuldig:justification": row.justificativa || undefined,
        "ontovuldig:contestation": row.contestacao || undefined, "ontovuldig:privateExperience": row.experiencia_privada,
        "ontovuldig:allowProjection": row.permite_projecao === "sim", "ontovuldig:skipped": row.pulada === "sim",
        "prov:generatedAtTime": row.criado_em, "contentVersion": row.versao_conteudo, "contentHash": row.hash_conteudo, "ontovuldig:provisionalMapping": true,
      }));
      const document = { "@context": { ontovuldig: "https://entre-mundos.local/ontovuldig#", ontohate: "https://luquizis.github.io/Ontohate#", privacy: "https://entre-mundos.local/privacy#", prov: "http://www.w3.org/ns/prov#" }, "provenance": [...new Set(rows.map((r) => r.hash_conteudo))], "@graph": graph };
      return { filename: `entre_mundos_${suffix}.jsonld`, mime: "application/ld+json", base64: Buffer.from(JSON.stringify(document, null, 2)).toString("base64") };
    }
    if (input.format === "ttl") {
      let ttl = `@prefix ontovuldig: <https://entre-mundos.local/ontovuldig#> .\n@prefix ontohate: <https://luquizis.github.io/Ontohate#> .\n@prefix privacy: <https://entre-mundos.local/privacy#> .\n@prefix prov: <http://www.w3.org/ns/prov#> .\n@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .\n\n`;
      for (const row of rows) {
        ttl += `<https://entre-mundos.local/response/${row.resposta_id}> a ontovuldig:ClassificacaoDidatica ;\n`;
        if (/^[a-f0-9]{64}$/.test(row.hash_conteudo)) ttl += `  prov:wasDerivedFrom <urn:sha256:${row.hash_conteudo}> ;\n`;
        ttl += `  prov:wasGeneratedBy <https://entre-mundos.local/session/${row.sessao}> ;\n`;
        ttl += `  ontovuldig:team ${ttlLiteral(row.dupla)} ;\n  ontovuldig:stop ${ttlLiteral(row.parada)} ;\n  ontovuldig:choice ${ttlLiteral(row.escolha)} ;\n`;
        ttl += `  ontovuldig:sourceClassification ${ttlLiteral(row.origem_vulnerabilidade)} ;\n`;
        ttl += `  ontovuldig:mc1Type ${ttlLiteral(row.mc1_tipo)} ;\n  ontovuldig:mc1Intensity ${ttlLiteral(row.mc1_intensidade)} ;\n  ontovuldig:mc1Scale ${ttlLiteral(row.mc1_escala)} ;\n`;
        ttl += `  ontovuldig:mc2Origin ${ttlLiteral(row.mc2_origem)} ;\n  ontovuldig:mc3Manifestation ${ttlLiteral(row.mc3_manifestacao)} ;\n  ontovuldig:mc3Visibility ${ttlLiteral(row.mc3_visibilidade)} ;\n`;
        ttl += `  ontovuldig:mc4Obstacle ${ttlLiteral(row.mc4_obstaculo)} ;\n  ontovuldig:mc5Response ${ttlLiteral(row.mc5_resposta)} ;\n`;
        if (row.privacidade_grupo) ttl += `  privacy:group ${ttlLiteral(row.privacidade_grupo)} ;\n`;
        for (const problem of row.privacidade_problemas.split(" | ").filter(Boolean)) ttl += `  privacy:problem ${ttlLiteral(problem)} ;\n`;
        ttl += `  ontohate:mappingState ${ttlLiteral(row.relacao_ontohate)} ;\n`;
        for (const dimension of row.ontohate_dimensoes.split(" | ").filter(Boolean)) ttl += `  ontohate:dimension ${ttlLiteral(dimension)} ;\n`;
        if (row.fator_invisivel) ttl += `  ontovuldig:hiddenFactor ${ttlLiteral(row.fator_invisivel)} ;\n`;
        if (row.justificativa) ttl += `  ontovuldig:justification ${ttlLiteral(row.justificativa)} ;\n`;
        if (row.contestacao) ttl += `  ontovuldig:contestation ${ttlLiteral(row.contestacao)} ;\n`;
        if (row.conceito_candidato) ttl += `  ontovuldig:candidateConcept ${ttlLiteral(row.conceito_candidato)} ;\n`;
        ttl += `  ontovuldig:privateExperience ${ttlLiteral(row.experiencia_privada)} ;\n`;
        ttl += `  ontovuldig:allowProjection ${row.permite_projecao === "sim"} ;\n  ontovuldig:skipped ${row.pulada === "sim"} ;\n`;
        ttl += `  ontovuldig:provisionalMapping true ;\n  prov:generatedAtTime ${ttlLiteral(row.criado_em)}^^xsd:dateTime .\n\n`;
      }
      return { filename: `entre_mundos_${suffix}.ttl`, mime: "text/turtle", base64: Buffer.from(ttl).toString("base64") };
    }
    const workbook = new ExcelJS.Workbook();
    workbook.creator = "Entre Mundos Digitais";
    workbook.created = new Date();
    const sheet = workbook.addWorksheet("Respostas");
    sheet.columns = Object.keys(rows[0]).map((key) => ({ header: key, key, width: Math.min(42, Math.max(14, key.length + 2)) }));
    rows.forEach((row) => sheet.addRow(row));
    sheet.getRow(1).font = { bold: true, color: { argb: "FFFFFFFF" } };
    sheet.getRow(1).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF183C4A" } };
    sheet.autoFilter = { from: "A1", to: { row: 1, column: sheet.columnCount } };
    const provenanceSheet = workbook.addWorksheet("Proveniência");
    provenanceSheet.addRows([["Vocabulário", "Proveniência"], ...rows.map((row) => [row.sessao, row.hash_conteudo])]);
    const codebook = workbook.addWorksheet("Codebooks das sessões");
    codebook.addRow(["Hash da versão", "Camada", "Rótulo", "Identificador"]);
    const seen = new Set<string>();
    for (const row of originalRows) {
      if (!row.snapshot || !row.digest || seen.has(row.digest)) continue;
      seen.add(row.digest);
      const snapshot = JSON.parse(row.snapshot) as { optionSets: typeof optionSets; privacyGroups: typeof privacyGroups; hateDimensions: string[][] };
      Object.entries(snapshot.optionSets).forEach(([axis, values]) => values.forEach(([label, id]) => codebook.addRow([row.digest, axis, label, id])));
      snapshot.privacyGroups.forEach((group) => group.items.forEach(([label, id]) => codebook.addRow([row.digest, group.group, label, id])));
      snapshot.hateDimensions.forEach(([label, id]) => codebook.addRow([row.digest, "OntoHate", label, id]));
    }
    const buffer = await workbook.xlsx.writeBuffer();
    return { filename: `entre_mundos_${suffix}.xlsx`, mime: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", base64: Buffer.from(buffer).toString("base64") };
  }),
});
