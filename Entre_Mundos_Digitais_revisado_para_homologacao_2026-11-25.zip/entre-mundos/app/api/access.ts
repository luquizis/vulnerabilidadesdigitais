import { and, eq } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { gameSessions, sessionAccess, type User } from "@db/schema";
import { getDb } from "./queries/connection";
import { canCurate, canResearch } from "../contracts/policy.ts";

export async function researchAccess(user: User, sessionId?: number, action: "read" | "export" | "curate" = "read") {
  if (!canResearch(user.role) || (action === "curate" && !canCurate(user.role))) throw new TRPCError({ code: "FORBIDDEN", message: "Seu papel não permite esta operação." });
  const grants = user.role === "admin" ? [] : await getDb().select().from(sessionAccess).where(eq(sessionAccess.userId, user.id));
  const allSessions = user.role === "admin" ? await getDb().select({ id: gameSessions.id }).from(gameSessions) : [];
  const allowed = user.role === "admin" ? allSessions.map((s) => s.id) : grants.filter((grant) => action === "read" || (action === "export" ? grant.canExport : grant.canCurate)).map((grant) => grant.sessionId);
  if (sessionId && !allowed.includes(sessionId)) throw new TRPCError({ code: "FORBIDDEN", message: "Você não tem acesso a esta sessão." });
  const ids = sessionId ? [sessionId] : allowed;
  return { ids, experience: (id: number) => user.role === "admin" || grants.some((grant) => grant.sessionId === id && grant.canReadExperience) };
}

export async function grantFor(userId: number, sessionId: number) {
  return getDb().query.sessionAccess.findFirst({ where: and(eq(sessionAccess.userId, userId), eq(sessionAccess.sessionId, sessionId)) });
}
