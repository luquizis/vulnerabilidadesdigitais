import type { z } from "zod";
import { and, eq, or } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { candidateConcepts, gameSessions, moderationItems, responses, teams } from "@db/schema";
import { getDb } from "./queries/connection";
import { appendEvent, parseList, requireTeam, safeText } from "./game-utils";
import { sessionContent } from "./content";
import { recordedResult, validateClassification } from "./domain/replay.ts";
import type { submissionSchema } from "./inputs";

export async function recordSubmission(input: z.infer<typeof submissionSchema>, skip = false) {
  const access = await requireTeam(input.code, input.token);
  return getDb().transaction(async (tx) => {
    // All game writes lock the session before its teams. Concurrent tabs cannot
    // validate against a stale stop or overwrite one another's progression.
    const [session] = await tx.select().from(gameSessions).where(eq(gameSessions.id, access.session.id)).for("update");
    const [team] = await tx.select().from(teams).where(eq(teams.id, access.team.id)).for("update");
    const previous = await tx.select().from(responses).where(or(eq(responses.idempotencyKey, input.idempotencyKey), and(eq(responses.teamId, team.id), eq(responses.stopId, input.stopId))));
    const keyMatch = previous.find((row) => row.idempotencyKey === input.idempotencyKey);
    if (keyMatch && (keyMatch.teamId !== team.id || keyMatch.sessionId !== session.id || keyMatch.stopId !== input.stopId)) throw new TRPCError({ code: "CONFLICT", message: "Chave de envio utilizada em outro contexto." });
    const original = keyMatch || previous.find((row) => row.teamId === team.id && row.stopId === input.stopId);
    // Persisted nextStopId permits retries even when the session has since ended.
    if (original?.nextStopId) return recordedResult(original, {});
    const content = await sessionContent(session);
    const stopById = Object.fromEntries(content.stops.map((stop) => [stop.id, stop]));
    if (original) return recordedResult(original, stopById);
    if (session.status !== "active") throw new TRPCError({ code: "PRECONDITION_FAILED", message: "A sessão não está em andamento." });
    if (!team.avatarId) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Escolham um avatar antes de responder." });
    const stop = stopById[input.stopId];
    if (!stop || team.currentStopId !== stop.id) throw new TRPCError({ code: "BAD_REQUEST", message: "Esta parada não está ativa para a dupla." });
    if (skip && !stop.sensitive) throw new TRPCError({ code: "BAD_REQUEST", message: "Somente paradas sensíveis podem ser puladas." });
    const choice = skip ? stop.choices[0] : stop.choices.find((item) => item.id === input.choiceId);
    if (!choice) throw new TRPCError({ code: "BAD_REQUEST", message: "Escolha uma travessia válida." });
    if (!skip) {
      try { validateClassification(input, content, stop.phase !== "protection"); }
      catch (error) { throw new TRPCError({ code: "BAD_REQUEST", message: error instanceof Error ? error.message : "Classificação inválida." }); }
    }
    const hiddenFactor = skip || input.hiddenFactorUnknown ? null : safeText(input.hiddenFactor);
    const justification = skip ? null : safeText(input.justification);
    const contestation = skip ? null : safeText(input.contestation);
    const candidateConcept = skip ? null : safeText(input.candidateConcept);
    const next = choice.next || "finished";
    const [inserted] = await tx.insert(responses).values({
      sessionId: session.id, teamId: team.id, stopId: stop.id, idempotencyKey: input.idempotencyKey,
      choiceId: skip ? null : choice.id, nextStopId: next, visibilityAtSubmit: session.visibility,
      sourceClassification: skip ? null : input.sourceClassification, ontoType: skip ? null : input.ontoType,
      ontoIntensity: skip ? null : input.ontoIntensity, ontoScale: skip ? null : input.ontoScale,
      ontoOrigin: skip ? null : input.ontoOrigin, ontoManifestation: skip ? null : input.ontoManifestation,
      ontoVisibility: skip ? null : input.ontoVisibility, ontoObstacle: skip ? null : input.ontoObstacle,
      ontoResponse: skip ? null : input.ontoResponse, privacyGroup: skip ? null : input.privacyGroup,
      privacyProblems: JSON.stringify(skip ? [] : [...new Set(input.privacyProblems)]),
      hiddenFactor, hiddenFactorUnknown: skip || input.hiddenFactorUnknown,
      hateMapping: skip ? "none" : input.hateMapping, hateDimensions: JSON.stringify(skip ? [] : [...new Set(input.hateDimensions)]),
      experience: skip || input.experience === "nao_informar" ? null : input.experience,
      contributionKind: candidateConcept ? "proposal" : contestation ? "contestation" : input.contributionKind,
      justification, contestation, candidateConcept, allowProjection: !skip && input.allowProjection, skipped: skip,
    }).$returningId();
    const completed = [...new Set([...parseList(team.completedStopIds), stop.id])];
    await tx.update(teams).set({ currentStopId: next, completedStopIds: JSON.stringify(completed), immunity: team.immunity + (skip ? 0 : 1), lastSeenAt: new Date() }).where(eq(teams.id, team.id));
    if (hiddenFactor || justification || contestation || candidateConcept) await tx.insert(moderationItems).values({ responseId: inserted.id, sessionId: session.id, status: "pending" });
    if (candidateConcept) await tx.insert(candidateConcepts).values({ responseId: inserted.id, sessionId: session.id, teamId: team.id, term: candidateConcept, definition: contestation });
    await appendEvent(tx, session.id, skip ? "stop_skipped" : "response_recorded");
    return { ok: true as const, duplicate: false, next, responseId: inserted.id };
  });
}
