import { z } from "zod";
import { and, eq } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { adminQuery, createRouter } from "./middleware";
import { getDb } from "./queries/connection";
import { users, sessionAccess, gameSessions, reviewDecisions } from "@db/schema";

export const adminRouter = createRouter({
  users: adminQuery.query(() => getDb().select({ id: users.id, name: users.name, role: users.role }).from(users)),
  access: adminQuery.input(z.object({ sessionId: z.number().int().positive() })).query(({ input }) => getDb().select().from(sessionAccess).where(eq(sessionAccess.sessionId, input.sessionId))),
  setRole: adminQuery.input(z.object({ userId: z.number().int().positive(), role: z.enum(["user", "researcher", "curator", "admin"]) })).mutation(async ({ input, ctx }) => {
    if (input.userId === ctx.user.id && input.role !== "admin") throw new TRPCError({ code: "BAD_REQUEST", message: "Use outro administrador para alterar seu próprio papel." });
    const [user] = await getDb().select({ id: users.id }).from(users).where(eq(users.id, input.userId));
    if (!user) throw new TRPCError({ code: "NOT_FOUND", message: "Usuário inexistente." });
    await getDb().update(users).set({ role: input.role }).where(eq(users.id, input.userId));
    return { ok: true };
  }),
  setAccess: adminQuery.input(z.object({ userId: z.number().int().positive(), sessionId: z.number().int().positive(), canCurate: z.boolean(), canExport: z.boolean(), canReadExperience: z.boolean(), revoke: z.boolean().default(false) })).mutation(async ({ input, ctx }) => {
    const { revoke, ...grant } = input;
    await getDb().transaction(async (tx) => {
      const [session] = await tx.select({ id: gameSessions.id }).from(gameSessions).where(eq(gameSessions.id, input.sessionId)).for("update");
      if (!session) throw new TRPCError({ code: "NOT_FOUND", message: "Sessão inexistente." });
      if (revoke) await tx.delete(sessionAccess).where(and(eq(sessionAccess.sessionId, input.sessionId), eq(sessionAccess.userId, input.userId)));
      else await tx.insert(sessionAccess).values(grant).onDuplicateKeyUpdate({ set: grant });
      await tx.insert(reviewDecisions).values({ sessionId: input.sessionId, actor: `user:${ctx.user.id}`, kind: "access", decision: revoke ? "revoked" : "granted", note: `user:${input.userId};curate:${input.canCurate};export:${input.canExport};experience:${input.canReadExperience}` });
    });
    return { ok: true };
  }),
});
