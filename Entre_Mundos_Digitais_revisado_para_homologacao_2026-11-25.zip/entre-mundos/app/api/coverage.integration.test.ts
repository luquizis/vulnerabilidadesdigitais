import { beforeAll, describe, expect, test, vi } from "vitest";
import { randomUUID } from "node:crypto";
import type { AppRouter } from "./router";
import type { inferRouterInputs } from "@trpc/server";
import type { User } from "@db/schema";

const database = process.env.TEST_DATABASE_URL;
// Integration tests only connect to a deliberately named disposable test DB.
if (database && !new URL(database).pathname.endsWith("_test")) throw new Error("TEST_DATABASE_URL deve apontar para um banco terminado em _test.");

type SubmitInput = inferRouterInputs<AppRouter>["game"]["submit"];

async function makeCaller(role: User["role"] | null) {
  const { appRouter } = await import("./router");
  const request = new Request("http://localhost/api/trpc");
  if (!role) return appRouter.createCaller({ req: request, resHeaders: new Headers() });
  const { getDb } = await import("./queries/connection");
  const { users } = await import("@db/schema");
  const [{ id }] = await getDb().insert(users).values({ unionId: `coverage-${randomUUID()}`, name: "Cobertura", role }).$returningId();
  const now = new Date();
  const user = { id, unionId: "coverage", name: "Cobertura", email: null, avatar: null, role, createdAt: now, updatedAt: now, lastSignInAt: now } satisfies User;
  return appRouter.createCaller({ req: request, resHeaders: new Headers(), user });
}

function fullInput(session: { code: string }, pair: { token: string }, stopId: string, choiceId: string, overrides: Partial<SubmitInput> = {}): SubmitInput {
  return {
    code: session.code, token: pair.token, stopId, choiceId, idempotencyKey: randomUUID(),
    sourceClassification: "ontovuldig:Fonte_Arquitetural", ontoType: "ontovuldig:MC1_Tipo_Decisional", ontoIntensity: "ontovuldig:MC1_Intensidade_Uma_Camada",
    ontoScale: "ontovuldig:MC1_Escala_Individual", ontoOrigin: "ontovuldig:MC2_Origem_Sociocultural", ontoManifestation: "ontovuldig:MC3_Risco_Puro",
    ontoVisibility: "ontovuldig:MC3_Invisivel", ontoObstacle: "ontovuldig:MC4_Demonstrabilidade", ontoResponse: "ontovuldig:MC5_Transparencia",
    hiddenFactorUnknown: true, allowProjection: true, ...overrides,
  };
}

describe.skipIf(!database)("MySQL: cobertura de fluxos do jogo e da pesquisa", () => {
  beforeAll(() => {
    vi.stubEnv("DATABASE_URL", database!);
    vi.stubEnv("APP_SECRET", "integration-test-only-secret-32-characters");
    vi.stubEnv("SESSION_SECRET", "integration-test-only-secret-32-characters");
    vi.stubEnv("KIMI_AUTH_URL", "https://auth.example.invalid");
  });

  test("estado da sessão bloqueia envios e inscrições fora de hora", async () => {
    const admin = await makeCaller("admin");
    const participant = await makeCaller(null);
    const session = await admin.game.createSession({ title: "Bloqueios" });
    const joinToken = randomUUID() + randomUUID();
    const pair = await participant.game.join({ code: session.code, joinToken });
    await participant.game.selectAvatar({ code: session.code, token: pair.token, avatarId: "aurora:01210" });
    // Antes do início: envio bloqueado.
    await expect(participant.game.submit(fullInput(session, pair, "in-1", "listen"))).rejects.toThrow(/andamento/);
    // Avatar inexistente é rejeitado antes do início e depois dele.
    await expect(participant.game.selectAvatar({ code: session.code, token: pair.token, avatarId: "avatar-inexistente" })).rejects.toThrow(/Avatar inválido/);
    await admin.game.start({ code: session.code, key: session.key });
    // Inscrições não mudam durante a travessia.
    await expect(participant.game.setRegistration({ code: session.code, key: session.key, open: true })).rejects.toThrow(/inscrições/);
    // Nova entrada bloqueada após o início; a mesma credencial recupera a dupla.
    await expect(participant.game.join({ code: session.code, joinToken: randomUUID() + randomUUID() })).rejects.toThrow(/inscrições/);
    const rejoined = await participant.game.join({ code: session.code, joinToken: joinToken });
    expect(rejoined.teamId).toBe(pair.teamId);
    // Envio após o encerramento: replay preservado, novo envio bloqueado.
    const input = fullInput(session, pair, "in-1", "listen");
    const saved = await participant.game.submit(input);
    await admin.game.finish({ code: session.code, key: session.key });
    await expect(participant.game.submit(fullInput(session, pair, "in-2a", "default"))).rejects.toThrow(/andamento/);
    const replay = await participant.game.submit(input);
    expect(replay.responseId).toBe(saved.responseId);
    await expect(participant.game.join({ code: session.code, joinToken: randomUUID() + randomUUID() })).rejects.toThrow(/inscrições/);
  });

  test("recuperação exige a credencial da dupla", async () => {
    const admin = await makeCaller("admin");
    const participant = await makeCaller(null);
    const session = await admin.game.createSession({ title: "Recuperação" });
    const pair = await participant.game.join({ code: session.code, joinToken: randomUUID() + randomUUID() });
    await expect(participant.game.resume({ code: session.code, token: randomUUID() + randomUUID() })).rejects.toThrow(/retomar/);
    const resumed = await participant.game.resume({ code: session.code, token: pair.token });
    expect(resumed.team.id).toBe(pair.teamId);
  });

  test("pulo restrito a paradas sensíveis e sem camada de proteção", async () => {
    const admin = await makeCaller("admin");
    const participant = await makeCaller(null);
    const session = await admin.game.createSession({ title: "Pulos" });
    const pair = await participant.game.join({ code: session.code, joinToken: randomUUID() + randomUUID() });
    await participant.game.selectAvatar({ code: session.code, token: pair.token, avatarId: "aurora:01210" });
    // Antes do início, qualquer envio (inclusive pulo) é bloqueado pelo estado da sessão.
    await expect(participant.game.skip({ code: session.code, token: pair.token, stopId: "in-1", idempotencyKey: randomUUID() })).rejects.toThrow(/andamento/);
    await admin.game.start({ code: session.code, key: session.key });
    // in-1 não é sensível: pulo recusado com a sessão em andamento.
    await expect(participant.game.skip({ code: session.code, token: pair.token, stopId: "in-1", idempotencyKey: randomUUID() })).rejects.toThrow(/sensíveis/);
    // Avança por in-1 escolhendo o caminho da parada sensível in-2b.
    await participant.game.submit(fullInput(session, pair, "in-1", "limits"));
    const state = await participant.game.state({ code: session.code, token: pair.token });
    expect(state.team.currentStopId).toBe("in-2b");
    const skipped = await participant.game.skip({ code: session.code, token: pair.token, stopId: "in-2b", idempotencyKey: randomUUID() });
    expect(skipped.next).toBe("si-1");
    const after = await participant.game.state({ code: session.code, token: pair.token });
    expect(after.team.immunity).toBe(1);
    expect(after.responses.find((row) => row.stopId === "in-2b")?.skipped).toBe(true);
  });

  test("projeção reserva textos, mostra escolhas autorizadas e acompanha a moderação", async () => {
    const admin = await makeCaller("admin");
    const participant = await makeCaller(null);
    const session = await admin.game.createSession({ title: "Projeção" });
    const pair = await participant.game.join({ code: session.code, joinToken: randomUUID() + randomUUID() });
    await participant.game.selectAvatar({ code: session.code, token: pair.token, avatarId: "aurora:01210" });
    await admin.game.start({ code: session.code, key: session.key });
    const saved = await participant.game.submit(fullInput(session, pair, "in-1", "listen", { justification: "Leitura da dupla", experience: "observada" }));
    let projection = await participant.game.projection({ code: session.code });
    expect(projection.responses).toHaveLength(0);
    await participant.game.setVisibility({ code: session.code, key: session.key, visibility: "open" });
    projection = await participant.game.projection({ code: session.code });
    expect(projection.responses).toHaveLength(1);
    expect(projection.responses[0].choiceId).toBe("listen");
    expect(projection.responses[0].justification).toBeNull();
    expect(JSON.stringify(projection)).not.toContain("observada");
    await participant.game.moderate({ code: session.code, key: session.key, responseId: saved.responseId, decision: "approved" });
    projection = await participant.game.projection({ code: session.code });
    expect(projection.responses[0].justification).toBe("Leitura da dupla");
    await participant.game.moderate({ code: session.code, key: session.key, responseId: saved.responseId, decision: "hidden" });
    projection = await participant.game.projection({ code: session.code });
    expect(projection.responses[0].justification).toBeNull();
    // Resposta marcada como não projetar nunca entra no mural.
    const pair2 = await participant.game.join({ code: session.code, joinToken: randomUUID() + randomUUID() }).catch(() => null);
    expect(pair2).toBeNull();
  });

  test("resposta sem autorização não aparece na projeção nem no painel coletivo", async () => {
    const admin = await makeCaller("admin");
    const participant = await makeCaller(null);
    const session = await admin.game.createSession({ title: "Reservada" });
    const pair = await participant.game.join({ code: session.code, joinToken: randomUUID() + randomUUID() });
    await participant.game.selectAvatar({ code: session.code, token: pair.token, avatarId: "aurora:01210" });
    await admin.game.start({ code: session.code, key: session.key });
    await participant.game.submit(fullInput(session, pair, "in-1", "listen", { allowProjection: false, justification: "Somente pesquisa" }));
    await participant.game.setVisibility({ code: session.code, key: session.key, visibility: "debate" });
    const projection = await participant.game.projection({ code: session.code });
    expect(projection.responses).toHaveLength(0);
    expect(JSON.stringify(projection)).not.toContain("Somente pesquisa");
    const moderator = await participant.game.moderator({ code: session.code, key: session.key });
    const row = moderator.responses.find((item) => item.justification === "Somente pesquisa");
    expect(row?.allowProjection).toBe(false);
  });

  test("exportação exige concessão, aplica escape e protege a experiência pessoal", async () => {
    const admin = await makeCaller("admin");
    const researcher = await makeCaller("researcher");
    const participant = await makeCaller(null);
    const session = await admin.game.createSession({ title: "Exportação" });
    const pair = await participant.game.join({ code: session.code, joinToken: randomUUID() + randomUUID() });
    await participant.game.selectAvatar({ code: session.code, token: pair.token, avatarId: "aurora:01210" });
    await admin.game.start({ code: session.code, key: session.key });
    await participant.game.submit(fullInput(session, pair, "in-1", "listen", { justification: "=formula+perigosa", experience: "vivenciada", candidateConcept: "vulnerabilidade de interface" }));

    await expect(researcher.research.export({ sessionId: session.id, format: "csv" })).rejects.toThrow(/acesso|papel/i);

    // Administrador concede exportação, sem liberar a experiência pessoal.
    const me = await researcher.auth.me();
    await admin.admin.setAccess({ userId: me.id, sessionId: session.id, canCurate: false, canExport: true, canReadExperience: false });

    const csv = await researcher.research.export({ sessionId: session.id, format: "csv" });
    const text = Buffer.from(csv.base64, "base64").toString("utf8");
    expect(text).toContain("resposta_id");
    expect(text).toContain("\"'=formula+perigosa\"");
    expect(text).toContain("acesso restrito");
    expect(text).not.toContain("vivenciada");
    expect(text).toContain(session.code);

    const jsonld = await researcher.research.export({ sessionId: session.id, format: "jsonld" });
    const document = JSON.parse(Buffer.from(jsonld.base64, "base64").toString("utf8")) as { "@context": Record<string, string>; provenance: string[]; "@graph": Record<string, unknown>[] };
    expect(document["@context"].ontovuldig).toContain("ontovuldig");
    expect(document.provenance[0]).toMatch(/^[a-f0-9]{64}$/);
    expect(document["@graph"][0]["contentHash"]).toBe(document.provenance[0]);
    expect(document["@graph"][0]["ontovuldig:privateExperience"]).toBe("acesso restrito");

    const ttl = await researcher.research.export({ sessionId: session.id, format: "ttl" });
    const turtle = Buffer.from(ttl.base64, "base64").toString("utf8");
    expect(turtle).toContain("@prefix ontovuldig:");
    expect(turtle).toContain("prov:wasDerivedFrom <urn:sha256:");

    const xlsx = await researcher.research.export({ sessionId: session.id, format: "xlsx" });
    expect(xlsx.mime).toContain("spreadsheetml");
    expect(Buffer.from(xlsx.base64, "base64").length).toBeGreaterThan(1000);
  });

  test("experiência pessoal só aparece com concessão específica", async () => {
    const admin = await makeCaller("admin");
    const researcher = await makeCaller("researcher");
    const participant = await makeCaller(null);
    const session = await admin.game.createSession({ title: "Experiência" });
    const pair = await participant.game.join({ code: session.code, joinToken: randomUUID() + randomUUID() });
    await participant.game.selectAvatar({ code: session.code, token: pair.token, avatarId: "aurora:01210" });
    await admin.game.start({ code: session.code, key: session.key });
    await participant.game.submit(fullInput(session, pair, "in-1", "listen", { experience: "vivenciada" }));
    const me = await researcher.auth.me();
    await admin.admin.setAccess({ userId: me.id, sessionId: session.id, canCurate: false, canExport: true, canReadExperience: true });
    const csv = await researcher.research.export({ sessionId: session.id, format: "csv" });
    expect(Buffer.from(csv.base64, "base64").toString("utf8")).toContain("vivenciada");
  });

  test("curadoria valida a classe no vocabulário da sessão e registra histórico", async () => {
    const admin = await makeCaller("admin");
    const curator = await makeCaller("curator");
    const researcher = await makeCaller("researcher");
    const participant = await makeCaller(null);
    const session = await admin.game.createSession({ title: "Curadoria" });
    const pair = await participant.game.join({ code: session.code, joinToken: randomUUID() + randomUUID() });
    await participant.game.selectAvatar({ code: session.code, token: pair.token, avatarId: "aurora:01210" });
    await admin.game.start({ code: session.code, key: session.key });
    await participant.game.submit(fullInput(session, pair, "in-1", "listen", { candidateConcept: "reciprocidade algorítmica", contestation: "A taxonomia não cobre esta relação." }));

    const overview = await admin.research.overview({ sessionId: session.id });
    const candidate = overview.candidates.find((item) => item.term === "reciprocidade algorítmica");
    expect(candidate).toBeTruthy();
    expect(candidate?.status).toBe("proposed");

    // Pesquisador sem papel de curador não cura.
    await expect(researcher.research.curate({ id: candidate!.id, status: "accepted" })).rejects.toThrow(/papel/i);
    // Curador sem concessão nesta sessão não cura.
    await expect(curator.research.curate({ id: candidate!.id, status: "accepted" })).rejects.toThrow(/sessão/i);
    const me = await curator.auth.me();
    await admin.admin.setAccess({ userId: me.id, sessionId: session.id, canCurate: true, canExport: false, canReadExperience: false });
    // Classe inexistente no vocabulário da sessão é recusada.
    await expect(curator.research.curate({ id: candidate!.id, status: "related", mappedClass: "ontovuldig:Inventada" })).rejects.toThrow(/vocabulário/);
    // Classe existente é aceita e o histórico preserva as decisões.
    await curator.research.curate({ id: candidate!.id, status: "related", mappedClass: "ontovuldig:MC5_Participacao", note: "Relacionada à participação." });
    const after = await admin.research.overview({ sessionId: session.id });
    expect(after.candidates.find((item) => item.id === candidate!.id)?.status).toBe("related");
    const { getDb } = await import("./queries/connection");
    const { reviewDecisions } = await import("@db/schema");
    const { eq, and } = await import("drizzle-orm");
    const history = await getDb().select().from(reviewDecisions).where(and(eq(reviewDecisions.sessionId, session.id), eq(reviewDecisions.kind, "curation")));
    expect(history.map((row) => row.decision)).toEqual(["related"]);
    expect(history[0].mappedClass).toBe("ontovuldig:MC5_Participacao");
  });

  test("sessão sem versão comprovada bloqueia o jogo mas permanece exportável como legado", async () => {
    const admin = await makeCaller("admin");
    const participant = await makeCaller(null);
    const { getDb } = await import("./queries/connection");
    const { gameSessions, teams, responses } = await import("@db/schema");
    const { hash } = await import("./game-utils");
    // Código aleatório no alfabeto da sessão, para o teste poder repetir no mesmo banco.
    const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    const legacyCode = Array.from(randomUUID().replaceAll("-", "").slice(0, 6), (char) => alphabet[parseInt(char, 16) % alphabet.length]).join("");
    const legacyKey = randomUUID() + randomUUID();
    const [{ id: sessionId }] = await getDb().insert(gameSessions).values({ publicCode: legacyCode, mediatorKeyHash: hash(legacyKey), title: "Histórica", status: "finished" }).$returningId();
    const teamToken = randomUUID() + randomUUID();
    const [{ id: teamId }] = await getDb().insert(teams).values({ sessionId, pairTokenHash: hash(teamToken), name: "Dupla 01", completedStopIds: "[\"in-1\"]" }).$returningId();
    await getDb().insert(responses).values({ sessionId, teamId, stopId: "in-1", idempotencyKey: randomUUID(), choiceId: "listen", privacyProblems: "[]", hateDimensions: "[]" });
    // Retomar o jogo exigiria o vocabulário original, que não pode ser reconstituído.
    await expect(participant.game.state({ code: legacyCode, token: teamToken })).rejects.toThrow(/versão/);
    // A pesquisa autorizada continua lendo o registro, marcado como sem versão.
    const csv = await admin.research.export({ sessionId, format: "csv" });
    const text = Buffer.from(csv.base64, "base64").toString("utf8");
    expect(text).toContain("legado sem versão comprovada");
    expect(text).toContain("não comprovada");
  });
});

describe.skipIf(!database)("MySQL: consulta paginada e agregados de pesquisa", () => {
  beforeAll(() => {
    vi.stubEnv("DATABASE_URL", database!);
    vi.stubEnv("APP_SECRET", "integration-test-only-secret-32-characters");
    vi.stubEnv("SESSION_SECRET", "integration-test-only-secret-32-characters");
    vi.stubEnv("KIMI_AUTH_URL", "https://auth.example.invalid");
  });

  test("paginação é determinística, filtra no banco e preserva totais", async () => {
    const admin = await makeCaller("admin");
    const participant = await makeCaller(null);
    const session = await admin.game.createSession({ title: "Paginação" });
    const joinA = randomUUID() + randomUUID();
    const joinB = randomUUID() + randomUUID();
    const pairA = await participant.game.join({ code: session.code, joinToken: joinA });
    const pairB = await participant.game.join({ code: session.code, joinToken: joinB });
    await participant.game.selectAvatar({ code: session.code, token: pairA.token, avatarId: "aurora:01210" });
    await participant.game.selectAvatar({ code: session.code, token: pairB.token, avatarId: "aurora:12012" });
    await admin.game.start({ code: session.code, key: session.key });
    await participant.game.submit(fullInput(session, pairA, "in-1", "listen", { candidateConcept: "termo candidato" }));
    await participant.game.submit(fullInput(session, pairB, "in-1", "limits"));

    const page1 = await admin.research.responsesPage({ sessionId: session.id, filter: "all", cursor: 0, limit: 1 });
    expect(page1.total).toBe(2);
    expect(page1.rows).toHaveLength(1);
    expect(page1.nextCursor).toBe(1);
    const page2 = await admin.research.responsesPage({ sessionId: session.id, filter: "all", cursor: page1.nextCursor ?? 0, limit: 1 });
    expect(page2.rows).toHaveLength(1);
    expect(page2.nextCursor).toBeNull();
    expect(new Set([...page1.rows, ...page2.rows].map((row) => row.resposta_id)).size).toBe(2);

    const concepts = await admin.research.responsesPage({ sessionId: session.id, filter: "concepts", cursor: 0, limit: 50 });
    expect(concepts.total).toBe(1);
    expect(concepts.rows[0].conceito_candidato).toBe("termo candidato");
    const invisible = await admin.research.responsesPage({ sessionId: session.id, filter: "invisible", cursor: 0, limit: 50 });
    expect(invisible.total).toBe(2);

    const overview = await admin.research.overview({ sessionId: session.id });
    expect(overview.responseCount).toBe(2);
    expect(overview.sourceCounts.find((row) => row.id === "ontovuldig:Fonte_Arquitetural")?.count).toBe(2);
    expect(overview.stopCounts.find((row) => row.id === "in-1")?.count).toBe(2);
    const listed = overview.sessions.find((row) => row.id === session.id);
    expect(listed?.contentVersionId).toBeGreaterThan(0);
    expect(listed?.contentHash).toMatch(/^[a-f0-9]{64}$/);
    // A visão geral não expõe mais a lista completa de respostas.
    expect("responses" in overview).toBe(false);
  });
});
