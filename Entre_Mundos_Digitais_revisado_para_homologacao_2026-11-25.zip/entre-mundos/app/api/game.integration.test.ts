import { beforeAll, describe, expect, test, vi } from "vitest";
import { randomUUID } from "node:crypto";
import type { AppRouter } from "./router";
import type { inferRouterInputs } from "@trpc/server";
import type { User } from "@db/schema";

type Caller = ReturnType<AppRouter["createCaller"]>;
const database = process.env.TEST_DATABASE_URL;
// Integration tests only connect to a deliberately named disposable test DB.
if (database && !new URL(database).pathname.endsWith("_test")) throw new Error("TEST_DATABASE_URL deve apontar para um banco terminado em _test.");

describe.skipIf(!database)("MySQL: transações, autorizações e repetição", () => {
  let admin: Caller;
  let participant: Caller;
  let researcher: Caller;
  let session: Awaited<ReturnType<Caller["game"]["createSession"]>>;
  let pair: Awaited<ReturnType<Caller["game"]["join"]>>;
  let saved: Awaited<ReturnType<Caller["game"]["submit"]>>;
  let input: inferRouterInputs<AppRouter>["game"]["submit"];

  beforeAll(async () => {
    vi.stubEnv("DATABASE_URL", database!);
    vi.stubEnv("APP_SECRET", "integration-test-only-secret-32-characters");
    vi.stubEnv("SESSION_SECRET", "integration-test-only-secret-32-characters");
    vi.stubEnv("KIMI_AUTH_URL", "https://auth.example.invalid");
    const { appRouter } = await import("./router");
    const { getDb } = await import("./queries/connection");
    const { users } = await import("@db/schema");
    const makeUser = async (role: User["role"]) => {
      const [{ id }] = await getDb().insert(users).values({ unionId: `integration-${randomUUID()}`, name: "Teste", role }).$returningId();
      const now = new Date();
      return { id, unionId: "test", name: "Teste", email: null, avatar: null, role, createdAt: now, updatedAt: now, lastSignInAt: now } satisfies User;
    };
    const request = new Request("http://localhost/api/trpc");
    admin = appRouter.createCaller({ req: request, resHeaders: new Headers(), user: await makeUser("admin") });
    researcher = appRouter.createCaller({ req: request, resHeaders: new Headers(), user: await makeUser("researcher") });
    participant = appRouter.createCaller({ req: request, resHeaders: new Headers() });
  });

  test("somente administrador cria sessão e novas sessões têm versão", async () => {
    await expect(participant.game.createSession({ title: "Sem autorização" })).rejects.toThrow();
    await expect(researcher.game.createSession({ title: "Sem papel admin" })).rejects.toThrow();
    session = await admin.game.createSession({ title: "Integração", capacity: 2 });
    expect(session.code).toMatch(/^[A-HJ-NP-Z2-9]{6}$/);
  });
  test("entrada simultânea com a mesma credencial cria apenas uma dupla", async () => {
    const joinToken = randomUUID() + randomUUID();
    const result = await Promise.all(Array.from({ length: 6 }, () => participant.game.join({ code: session.code, joinToken })));
    expect(new Set(result.map((row) => row.teamId)).size).toBe(1);
    pair = result[0];
    const state = await participant.game.state({ code: session.code, token: pair.token });
    expect(state.contentVersionId).toBeGreaterThan(0);
  });
  test("capacidade e inscrições encerradas são verificadas no servidor", async () => {
    await participant.game.join({ code: session.code, joinToken: randomUUID() + randomUUID() });
    await expect(participant.game.join({ code: session.code, joinToken: randomUUID() + randomUUID() })).rejects.toThrow();
    await participant.game.setRegistration({ code: session.code, key: session.key, open: false });
    expect((await participant.game.resume({ code: session.code, token: pair.token })).team.id).toBe(pair.teamId);
    await expect(participant.game.start({ code: session.code, key: randomUUID() })).rejects.toThrow();
    await participant.game.selectAvatar({ code: session.code, token: pair.token, avatarId: "aurora:01210" });
    await participant.game.start({ code: session.code, key: session.key });
  });
  test("envios simultâneos mantêm uma resposta e o mesmo percurso", async () => {
    const state = await participant.game.state({ code: session.code, token: pair.token });
    const choice = state.stop!.choices[0];
    const options = state.content.optionSets;
    input = { code: session.code, token: pair.token, stopId: state.stop!.id, idempotencyKey: randomUUID(), choiceId: choice.id,
      sourceClassification: options.source[0][1], ontoType: options.type[0][1], ontoIntensity: options.intensity[0][1], ontoScale: options.scale[0][1], ontoOrigin: options.origin[0][1], ontoManifestation: options.manifestation[0][1], ontoVisibility: options.visibility[0][1], ontoObstacle: options.obstacle[0][1], ontoResponse: options.response[0][1], hiddenFactorUnknown: true, allowProjection: false, justification: "Texto de teste" };
    const answers = await Promise.all(Array.from({ length: 6 }, () => participant.game.submit(input)));
    expect(new Set(answers.map((row) => row.responseId)).size).toBe(1);
    saved = answers[0];
    const replay = await participant.game.submit({ ...input, idempotencyKey: randomUUID(), choiceId: state.stop!.choices[1].id });
    expect(replay.responseId).toBe(saved.responseId);
    expect(replay.next).toBe(choice.next);
    const after = await participant.game.state({ code: session.code, token: pair.token });
    expect(after.team.immunity).toBe(1);
    expect(after.responses).toHaveLength(1);
  });
  test("pesquisador sem concessão não lê nem exporta esta sessão", async () => {
    await expect(researcher.research.overview({ sessionId: session.id })).rejects.toThrow();
    await expect(researcher.research.export({ sessionId: session.id, format: "csv" })).rejects.toThrow();
    const projection = await participant.game.projection({ code: session.code });
    expect(projection.responses).toHaveLength(0);
  });
  test("moderação preserva histórico e revoga publicação", async () => {
    await participant.game.moderate({ code: session.code, key: session.key, responseId: saved.responseId, decision: "approved" });
    await participant.game.moderate({ code: session.code, key: session.key, responseId: saved.responseId, decision: "hidden" });
    const { getDb } = await import("./queries/connection");
    const { reviewDecisions } = await import("@db/schema");
    const { eq } = await import("drizzle-orm");
    const history = await getDb().select().from(reviewDecisions).where(eq(reviewDecisions.responseId, saved.responseId));
    expect(history.map((row) => row.decision)).toEqual(["approved", "hidden"]);
  });
  test("sessão encerrada aceita repetição mas bloqueia novas respostas", async () => {
    await participant.game.finish({ code: session.code, key: session.key });
    const replay = await participant.game.submit(input);
    expect(replay.responseId).toBe(saved.responseId);
    await expect(participant.game.start({ code: session.code, key: session.key })).rejects.toThrow();
  });
});
