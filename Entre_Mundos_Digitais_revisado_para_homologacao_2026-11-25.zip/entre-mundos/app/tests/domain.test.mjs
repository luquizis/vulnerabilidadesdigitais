import test from "node:test";
import assert from "node:assert/strict";
import { canJoin, mayTransition, canResearch, canCurate, parseCursor, publicEvent, reviewSignals } from "../contracts/policy.ts";
import { recordedResult, validateClassification } from "../api/domain/replay.ts";
import { signStreamTicket, verifyStreamTicket } from "../api/domain/stream-ticket.ts";
import { RateLimiter } from "../api/domain/rate-limit.ts";
import { csvCell, ttlLiteral } from "../api/domain/export-text.ts";
import { stops, phases, optionSets, privacyGroups, hateDimensions, avatars, makeAvatarProfileId, isAvatarProfileId } from "../contracts/game.ts";

const stopMap = Object.fromEntries(stops.map((stop) => [stop.id, stop]));
const vocabulary = { optionSets, privacyGroups, hateDimensions };

test("inscrições respeitam estado, abertura e capacidade", () => {
  assert.equal(canJoin("lobby", true, 39, 40), true);
  for (const status of ["closed", "active", "finished"]) assert.equal(canJoin(status, true, 0, 40), false);
  assert.equal(canJoin("lobby", false, 0, 40), false);
  assert.equal(canJoin("lobby", true, 40, 40), false);
});
test("sessões encerradas não podem ser reabertas", () => {
  for (const status of ["lobby", "closed", "active", "finished"]) assert.equal(mayTransition("finished", status), false);
  assert.equal(mayTransition("lobby", "closed"), true);
  assert.equal(mayTransition("closed", "active"), true);
  assert.equal(mayTransition("active", "lobby"), false);
});
test("papéis de pesquisa e curadoria permanecem separados", () => {
  assert.equal(canResearch("user"), false);
  assert.equal(canResearch("researcher"), true);
  assert.equal(canCurate("researcher"), false);
  assert.equal(canCurate("curator"), true);
  assert.equal(canCurate("admin"), true);
});
test("reenvios recuperam o percurso da resposta originalmente registrada", () => {
  for (const stop of stops) for (const choice of stop.choices) {
    assert.deepEqual(recordedResult({ id: 9, stopId: stop.id, choiceId: choice.id, skipped: false }, stopMap), { ok: true, duplicate: true, responseId: 9, next: choice.next || "finished" });
  }
});
test("parada pulada e resultado congelado independem de novas escolhas", () => {
  const stop = stops.find((item) => item.sensitive);
  assert.equal(recordedResult({ id: 1, stopId: stop.id, choiceId: null, skipped: true }, stopMap).next, stop.choices[0].next || "finished");
  assert.equal(recordedResult({ id: 1, stopId: "old", choiceId: "old", skipped: false, nextStopId: "saved" }, {}).next, "saved");
});
test("todos os percursos preservam as cinco fases e terminam sem ciclos", () => {
  assert.equal(new Set(stops.map((stop) => stop.id)).size, stops.length);
  assert.equal(phases.length, 5);
  const walk = (id, seen, visited) => {
    assert.ok(stopMap[id], `parada ausente: ${id}`);
    assert.ok(!seen.has(id), `ciclo: ${id}`);
    const stop = stopMap[id];
    for (const choice of stop.choices) {
      const nextVisited = new Set([...visited, stop.phase]);
      if (choice.next) walk(choice.next, new Set([...seen, id]), nextVisited);
      else assert.equal(nextVisited.size, 5);
    }
  };
  walk("in-1", new Set(), new Set());
});
test("classificações aceitam somente os termos fornecidos", () => {
  validateClassification({ sourceClassification: optionSets.source[0][1], privacyProblems: [privacyGroups[0].items[0][1]], hateMapping: "none" }, vocabulary);
  assert.throws(() => validateClassification({ sourceClassification: "inventado" }, vocabulary));
  assert.throws(() => validateClassification({ privacyProblems: ["unknown", privacyGroups[0].items[0][1]] }, vocabulary));
  assert.throws(() => validateClassification({ hateMapping: "none", hateDimensions: [hateDimensions[0][1]] }, vocabulary));
  assert.throws(() => validateClassification({ hateDimensions: ["ontohate:inventado"] }, vocabulary));
});
test("a API exige as etapas conceituais, mantendo não sei como resposta válida", () => {
  assert.throws(() => validateClassification({}, vocabulary, true));
  const fields = ["sourceClassification", "ontoType", "ontoIntensity", "ontoScale", "ontoOrigin", "ontoManifestation", "ontoVisibility", "ontoObstacle", "ontoResponse"];
  const response = Object.fromEntries(fields.map((field) => [field, "unknown"]));
  validateClassification({ ...response, hiddenFactorUnknown: true }, vocabulary, true);
  assert.throws(() => validateClassification(response, vocabulary, true));
});
test("exportação escapa fórmulas e preserva aspas e quebras de linha", () => {
  for (const value of ["=1+1", "  =1+1", "\t@SUM(1)", "+1", "-1", "@SUM(1)"]) assert.ok(csvCell(value).startsWith('"\''));
  assert.equal(csvCell('texto "citado"'), '"texto ""citado"""');
  const text = 'linha\r\n"citada"\\fim';
  assert.equal(JSON.parse(ttlLiteral(text)), text);
});
test("avatares preservam combinações e rejeitam sufixos inesperados", () => {
  for (const avatar of avatars) {
    assert.equal(isAvatarProfileId(makeAvatarProfileId(avatar.id, [0, 1, 2, 1, 0])), true);
    assert.equal(isAvatarProfileId(`${avatar.id}:01210:extra`), false);
  }
});
test("triagem sinaliza contatos e contexto sensível sem decidir moderação", () => {
  assert.ok(reviewSignals("Contato: estudante@example.org").includes("contact"));
  assert.ok(reviewSignals("CPF 123.456.789-00").includes("identifier"));
  assert.ok(reviewSignals("Estamos denunciando racismo").includes("sensitive_context"));
  assert.deepEqual(reviewSignals("Precisamos de proteção coletiva."), []);
});
test("eventos nunca transportam textos, identificadores ou experiência privada", () => {
  for (const role of ["projection", "team", "mediator"]) {
    const output = publicEvent("response_recorded", role, { teamId: 5, experience: "vivenciada", text: "sigiloso", flagged: true });
    assert.deepEqual(output.payload, {});
    assert.ok(!JSON.stringify(output).includes("sigiloso"));
  }
});
test("cursor rejeita números negativos, fracionários e infinitos", () => {
  assert.equal(parseCursor("201"), 201);
  assert.equal(parseCursor(undefined), 0);
  for (const value of ["-1", "0.5", "NaN", "Infinity", "9007199254740992"]) assert.throws(() => parseCursor(value));
});
test("credenciais de eventos são assinadas, limitadas por escopo e expiram", () => {
  const secret = "test-only-secret-with-at-least-32-characters";
  const ticket = { code: "ABC234", role: "team", subject: "opaque-hash", expires: 2000 };
  const signed = signStreamTicket(ticket, secret);
  assert.deepEqual(verifyStreamTicket(signed, secret, 1000), ticket);
  assert.throws(() => verifyStreamTicket(signed, secret, 2000));
  assert.throws(() => verifyStreamTicket(signed, "another-secret-with-at-least-32-characters", 1000));
  assert.throws(() => verifyStreamTicket(signed.replace(".", "x."), secret, 1000));
  assert.throws(() => signStreamTicket(ticket, ""));
});
test("limitação de tentativas expira e separa grupos", () => {
  const limiter = new RateLimiter();
  assert.equal(limiter.consume("a", 2, 1000, 0), true);
  assert.equal(limiter.consume("a", 2, 1000, 0), true);
  assert.equal(limiter.consume("a", 2, 1000, 0), false);
  assert.equal(limiter.consume("b", 2, 1000, 0), true);
  assert.equal(limiter.consume("a", 2, 1000, 1000), true);
});
