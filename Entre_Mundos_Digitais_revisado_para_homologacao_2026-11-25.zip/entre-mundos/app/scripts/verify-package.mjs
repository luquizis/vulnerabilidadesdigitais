import fs from "node:fs";
import path from "node:path";
import { stripTypeScriptTypes } from "node:module";
import { spawnSync } from "node:child_process";

const root = path.resolve(import.meta.dirname, "..");
const reportDirectory = path.resolve(root, "..", "documentacao");
fs.mkdirSync(reportDirectory, { recursive: true });
const result = { date: new Date().toISOString(), runtime: process.version, domain: null, typescriptSyntax: { checked: 0, failures: [] }, javascriptSyntax: { checked: 0, failures: [] }, checks: {} };
const domain = spawnSync(process.execPath, ["--test", "--test-reporter=tap", "tests/domain.test.mjs"], { cwd: root, encoding: "utf8" });
fs.writeFileSync(path.join(reportDirectory, "testes-dominio.tap"), domain.stdout + domain.stderr);
result.domain = { exitCode: domain.status, report: "testes-dominio.tap" };
function scan(directory) {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    if (["node_modules", "dist", ".git"].includes(entry.name)) continue;
    const file = path.join(directory, entry.name);
    if (entry.isDirectory()) { scan(file); continue; }
    if (file.endsWith(".ts")) {
      try { stripTypeScriptTypes(fs.readFileSync(file, "utf8")); result.typescriptSyntax.checked++; }
      catch (error) { result.typescriptSyntax.failures.push({ file: path.relative(root, file), message: error.message }); }
    } else if (/\.(?:mjs|js)$/.test(file)) {
      const syntax = spawnSync(process.execPath, ["--check", file], { encoding: "utf8" });
      result.javascriptSyntax.checked++;
      if (syntax.status) result.javascriptSyntax.failures.push({ file: path.relative(root, file), message: syntax.stderr });
    }
  }
}
scan(root);
const checks = {
  integration: ["node_modules/vitest/vitest.mjs", "run"],
  typecheck: ["node_modules/typescript/bin/tsc", "-b"],
  lint: ["node_modules/eslint/bin/eslint.js", "."],
  frontendBuild: ["node_modules/vite/bin/vite.js", "build"],
  backendBuild: ["node_modules/esbuild/bin/esbuild", "api/boot.ts", "--platform=node", "--bundle", "--format=esm", "--outfile=dist/boot.js", "--banner:js=import { createRequire } from 'module';const require = createRequire(import.meta.url);"],
};
for (const [name, args] of Object.entries(checks)) {
  const available = fs.existsSync(path.join(root, args[0]));
  if (!available) {
    result.checks[name] = { status: "blocked", reason: "Dependências do projeto ausentes; a instalação não ficou disponível neste ambiente." };
    continue;
  }
  if (name === "integration" && !process.env.TEST_DATABASE_URL) {
    result.checks[name] = { status: "blocked", reason: "TEST_DATABASE_URL não configurada." }; continue;
  }
  const execution = spawnSync(process.execPath, args, { cwd: root, encoding: "utf8" });
  result.checks[name] = { status: execution.status === 0 ? "passed" : "failed", exitCode: execution.status };
  fs.writeFileSync(path.join(reportDirectory, `${name}.log`), execution.stdout + execution.stderr);
}
result.checks.databaseMigration = { status: "not_executed", reason: "Sem MySQL e sem DATABASE_URL de homologação." };
result.checks.browserFlows = { status: "not_executed", reason: "Aplicação completa não iniciada; login Kimi e MySQL externos não disponíveis." };
result.checks.tsx = { status: "not_typechecked", reason: "A checagem nativa de sintaxe não substitui TypeScript, lint nem valida JSX/TSX." };
fs.writeFileSync(path.join(reportDirectory, "validacao.json"), JSON.stringify(result, null, 2) + "\n");
console.log(JSON.stringify(result, null, 2));
if (domain.status || result.typescriptSyntax.failures.length || result.javascriptSyntax.failures.length) process.exitCode = 1;
