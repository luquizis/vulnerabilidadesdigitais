import "dotenv/config";
import mysql from "mysql2/promise";
import { readFile } from "node:fs/promises";

if (!process.env.DATABASE_URL) throw new Error("Defina DATABASE_URL para o banco de homologação ou a cópia de segurança.");
const db = await mysql.createConnection(process.env.DATABASE_URL);
let locked = false;
try {
  const [[identity]] = await db.query("SELECT DATABASE() AS name");
  const lockName = `emd_migrate_${identity.name}`.slice(0, 64);
  const [[lock]] = await db.query("SELECT GET_LOCK(?, 5) AS acquired", [lockName]);
  if (lock.acquired !== 1) throw new Error("Outra migração está em andamento.");
  locked = true;
  const [base] = await db.query("SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME IN ('users','game_sessions','teams','responses','moderation_items')");
  if (base.length !== 5) throw new Error("Esta migração atualiza o projeto original. Para um banco vazio, use npm run db:push, somente em banco novo.");
  const [duplicates] = await db.query("SELECT team_id, stop_id, COUNT(*) AS count FROM responses GROUP BY team_id, stop_id HAVING COUNT(*) > 1");
  if (duplicates.length) {
    console.error(JSON.stringify({ conflicts: duplicates }, null, 2));
    throw new Error("Existem respostas históricas duplicadas. Nenhum dado foi removido. Resolva os conflitos com o pesquisador antes de migrar.");
  }
  const [[legacy]] = await db.query("SELECT COUNT(*) AS count FROM game_sessions");
  if (process.argv.includes("--check")) {
    console.log(JSON.stringify({ preflight: "ok", sessions: legacy.count, destructiveChanges: false }));
  } else {
    const statements = (await readFile(new URL("../db/migrations/001_hardening.sql", import.meta.url), "utf8")).split("-- statement-breakpoint");
    for (const statement of statements) if (statement.trim()) await db.query(statement);
    const additions = {
      game_sessions: { registration_open: "BOOLEAN NOT NULL DEFAULT TRUE", capacity: "INT NOT NULL DEFAULT 40", content_version_id: "BIGINT UNSIGNED NULL" },
      teams: { join_key_hash: "VARCHAR(64) NULL", last_seen_at: "TIMESTAMP NULL" },
      responses: { next_stop_id: "VARCHAR(80) NULL", visibility_at_submit: "VARCHAR(30) NULL", contribution_kind: "ENUM('agreement','contestation','proposal','unspecified') NOT NULL DEFAULT 'unspecified'" },
    };
    for (const [table, columns] of Object.entries(additions)) {
      const [existing] = await db.query("SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=?", [table]);
      const names = new Set(existing.map((row) => row.COLUMN_NAME));
      for (const [column, definition] of Object.entries(columns)) if (!names.has(column)) await db.query(`ALTER TABLE \`${table}\` ADD COLUMN \`${column}\` ${definition}`);
    }
    await db.query("ALTER TABLE users MODIFY COLUMN role ENUM('user','admin','researcher','curator') NOT NULL DEFAULT 'user'");
    await db.query("ALTER TABLE game_sessions MODIFY COLUMN status ENUM('lobby','active','finished','closed') NOT NULL DEFAULT 'lobby'");
    await db.query("ALTER TABLE moderation_items MODIFY COLUMN status ENUM('pending','approved','rejected','hidden','revision_requested') NOT NULL DEFAULT 'pending'");
    for (const [table, name, columns] of [["teams", "team_join_unique", "session_id, join_key_hash"], ["responses", "response_team_stop_unique", "team_id, stop_id"]]) {
      const [indexes] = await db.query("SELECT INDEX_NAME FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND INDEX_NAME=?", [table, name]);
      if (!indexes.length) await db.query(`ALTER TABLE \`${table}\` ADD UNIQUE INDEX \`${name}\` (${columns})`);
    }
    const [foreignKeys] = await db.query("SELECT CONSTRAINT_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='game_sessions' AND COLUMN_NAME='content_version_id' AND REFERENCED_TABLE_NAME='taxonomy_versions'");
    if (!foreignKeys.length) await db.query("ALTER TABLE game_sessions ADD CONSTRAINT session_content_version_fk FOREIGN KEY (content_version_id) REFERENCES taxonomy_versions(id)");
    // Null legacy version ids are intentional. Inventing a historical version
    // or inferring the original route from today's code would corrupt evidence.
    console.log(JSON.stringify({ migration: "001_hardening", status: "applied", legacyVersions: "not_inferred" }));
  }
  if (locked) await db.query("SELECT RELEASE_LOCK(?)", [lockName]);
} finally { await db.end(); }
