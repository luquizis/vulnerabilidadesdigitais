export type PhaseId = "inherent" | "situational" | "pathogenic" | "architectural" | "protection";
export type Choice = { id: string; label: string; detail: string; protection: string; next: string | null };
export type CaseSource = { label: string; url: string; note: string };
export type Stop = {
  id: string; phase: PhaseId; title: string; kicker: string; scenario: string;
  investigation: string; debate: string; sensitive?: boolean; hateCase?: boolean;
  privacyChain: string[]; source: CaseSource; choices: Choice[];
};
export type Phase = { id: PhaseId; number: number; short: string; title: string; color: string; lightColor: string; principle: string; startsAt: string };

export const phases: Phase[] = [
  { id: "inherent", number: 1, short: "IN", title: "Vulnerabilidade inerente", color: "#B5502F", lightColor: "#E18B70", principle: "Faz parte da condição humana: não se elimina, mas se acumulam camadas de proteção.", startsAt: "in-1" },
  { id: "situational", number: 2, short: "SI", title: "Vulnerabilidade situacional", color: "#1F6F8B", lightColor: "#62B8D2", principle: "Contextos e relações concretas podem ampliar ou reduzir a exposição ao risco.", startsAt: "si-1" },
  { id: "pathogenic", number: 3, short: "PA", title: "Vulnerabilidade patogênica", color: "#7A3E8E", lightColor: "#C98BD8", principle: "Práticas, abusos e dinâmicas institucionais produzem ou agravam o dano.", startsAt: "pa-1" },
  { id: "architectural", number: 4, short: "AR", title: "Vulnerabilidade arquitetural", color: "#0E7C66", lightColor: "#54C7AE", principle: "Interfaces, métricas, algoritmos e regras estruturam assimetrias e podem ser redesenhados.", startsAt: "ar-1" },
  { id: "protection", number: 5, short: "PR", title: "Proteção coletiva", color: "#8F6200", lightColor: "#E3B95C", principle: "Não há vencedores: a turma combina resiliência, participação, transparência e reparação.", startsAt: "pr-1" },
];

const sources = {
  world: { label: "ANPD · World ID, 24 jan. 2025", url: "https://www.gov.br/anpd/pt-br/assuntos/noticias/anpd-determina-suspensao-de-incentivos-financeiros-por-coleta-de-iris", note: "Caso público adaptado. A ANPD suspendeu incentivos financeiros pela coleta de íris e discutiu consentimento livre, dados biométricos e hipossuficiência." },
  facebook: { label: "FTC · Facebook e Cambridge Analytica, 24 jul. 2019", url: "https://www.ftc.gov/news-events/news/press-releases/2019/07/ftc-imposes-5-billion-penalty-sweeping-new-privacy-restrictions-facebook", note: "Caso público adaptado. A FTC descreveu controles de privacidade enganosos, compartilhamento com aplicativos e uso secundário de números de telefone." },
  tiktok: { label: "DPC · TikTok, 15 set. 2023", url: "https://www.dataprotection.ie/en/news-media/press-releases/DPC-announces-345-million-euro-fine-of-TikTok", note: "Caso público adaptado. A decisão examinou configurações públicas por padrão, transparência para crianças, verificação de idade e dark patterns." },
  replika: { label: "IAPP · medidas do Garante sobre Replika, 2023–2025", url: "https://iapp.org/news/a/italy-s-dpa-reaffirms-ban-on-replika-over-ai-and-children-s-privacy-concerns", note: "Caso público adaptado. A autoridade italiana tratou de riscos a menores, transparência e verificação etária em um chatbot de companhia." },
  meta: { label: "Agência Brasil · medida da ANPD sobre Meta e IA, 2 jul. 2024", url: "https://agenciabrasil.ebc.com.br/justica/noticia/2024-07/anpd-suspende-uso-de-dados-no-facebook-e-instagram-para-treinar-ia", note: "Caso público adaptado. A medida cautelar tratou de dados públicos usados para treinar IA, transparência, oposição e proteção de crianças e adolescentes." },
  x: { label: "Comissão Europeia · conclusões preliminares sobre X, 12 jul. 2024", url: "https://ec.europa.eu/commission/presscorner/detail/en/ip_24_3761", note: "Caso público adaptado. A Comissão apontou preliminarmente questões de dark patterns, transparência de anúncios e acesso de pesquisadores a dados públicos." },
};

export const stops: Stop[] = [
  { id: "in-1", phase: "inherent", kicker: "Portal de entrada · escolha e corpo", title: "Uma íris vale uma recompensa?", scenario: "Um serviço oferece criptomoedas para registrar a íris e comprovar que uma pessoa é única. A decisão parece individual, mas a recompensa pode pesar de modos diferentes conforme as condições de quem decide.", investigation: "O que torna essa decisão menos livre sem aparecer no botão “aceitar”? Observe a irreversibilidade do dado biométrico e a assimetria entre pessoa e empresa.", debate: "Quando uma recompensa deixa de ser um incentivo e passa a pressionar a decisão?", privacyChain: ["Coleta de Informações:Vigilância", "Processamento de Informações:Identificação"], source: sources.world, choices: [
    { id: "listen", label: "Ampliar o tempo de decisão", detail: "Separar oferta e consentimento, com informação acessível e apoio independente.", protection: "Resiliência e participação", next: "in-2a" },
    { id: "limits", label: "Criar limites institucionais", detail: "Impedir incentivos que comprometam consentimento sobre dados sensíveis.", protection: "Interdição e procedimentos", next: "in-2b" },
  ] },
  { id: "in-2a", phase: "inherent", kicker: "Investigação · configuração inicial", title: "O perfil já nasce público?", scenario: "Na plataforma analisada, contas de crianças eram públicas por padrão no período investigado. A dupla deve observar a diferença entre existir uma configuração e conseguir compreendê-la e alterá-la.", investigation: "Que camada invisível está no padrão pré-definido? Quem precisa agir para que a proteção aconteça?", debate: "Privacidade por padrão é responsabilidade de quem usa ou de quem desenha?", privacyChain: ["Processamento de Informações:Insegurança", "Disseminação de Informações:Exposição"], source: sources.tiktok, choices: [
    { id: "default", label: "Mudar o padrão", detail: "Começar com a configuração mais protetiva e explicar consequências.", protection: "Procedimentos e transparência", next: "si-1" },
    { id: "participate", label: "Testar com quem usa", detail: "Ouvir adolescentes e redesenhar linguagem, navegação e controles.", protection: "Participação e competência ética", next: "si-1" },
  ] },
  { id: "in-2b", phase: "inherent", kicker: "Investigação · vínculo com IA", title: "Uma conversa é só uma conversa?", scenario: "Um chatbot de companhia combina diálogo, vínculo emocional e tratamento de dados. Autoridades examinaram riscos para menores, informação insuficiente e mecanismos etários.", investigation: "Que vulnerabilidades decisionais e emocionais podem existir sem que a interface as torne visíveis?", debate: "Como proteger sem tratar toda pessoa como incapaz de decidir?", sensitive: true, privacyChain: ["Coleta de Informações:Interrogatório", "Processamento de Informações:Uso Secundário"], source: sources.replika, choices: [
    { id: "support", label: "Oferecer apoio e controle", detail: "Criar pausas, limites e canais de ajuda sem exigir relatos pessoais.", protection: "Resiliência e participação", next: "si-1" },
    { id: "design", label: "Rever o desenho do serviço", detail: "Transparência adequada à idade e avaliação prévia de riscos.", protection: "Procedimentos e transparência", next: "si-1" },
  ] },

  { id: "si-1", phase: "situational", kicker: "Território · condições concretas", title: "O peso desigual de uma oferta", scenario: "O caso World ID é revisitado: a mesma compensação financeira pode ter pesos distintos em situações de necessidade. Não é a identidade da pessoa que produz o risco, mas a relação entre oferta, contexto e poder.", investigation: "Quais condições externas mudam a escolha sem estarem registradas no formulário de consentimento?", debate: "Uma escolha formalmente igual pode ser materialmente desigual?", sensitive: true, privacyChain: ["Coleta de Informações:Vigilância", "Invasão:Interferência Decisória"], source: sources.world, choices: [
    { id: "context", label: "Reduzir a pressão do contexto", detail: "Remover recompensa e oferecer alternativas que não exijam biometria.", protection: "Interdição e resiliência", next: "si-2a" },
    { id: "collective", label: "Criar proteção coletiva", detail: "Estabelecer regras comuns para que a proteção não dependa de recursos individuais.", protection: "Participação e reparação coletiva", next: "si-2b" },
  ] },
  { id: "si-2a", phase: "situational", kicker: "Investigação · dados de amizades", title: "Quando a escolha de um alcança outro", scenario: "No caso examinado pela FTC, dados de contatos podiam alcançar aplicativos usados por amizades. A configuração individual não bastava para interromper toda a circulação.", investigation: "Quem é afetado sem ter interagido com o aplicativo? Que relação fica invisível quando olhamos apenas para uma conta?", debate: "Como consentir por dados que envolvem mais de uma pessoa?", privacyChain: ["Coleta de Informações:Vigilância", "Processamento de Informações:Agregação", "Processamento de Informações:Uso Secundário"], source: sources.facebook, choices: [
    { id: "network", label: "Mapear a rede de efeitos", detail: "Considerar pessoas alcançadas indiretamente antes de liberar acesso.", protection: "Transparência e procedimentos", next: "pa-1" },
    { id: "minimize", label: "Limitar a circulação", detail: "Restringir dados de contatos e usos fora da finalidade informada.", protection: "Interdição e resiliência", next: "pa-1" },
  ] },
  { id: "si-2b", phase: "situational", kicker: "Investigação · conteúdo público", title: "Público significa disponível para tudo?", scenario: "Conteúdos publicados para convivência em uma plataforma passaram a ser considerados para treinamento de IA. A ANPD apontou problemas de informação e obstáculos à oposição.", investigation: "O que muda quando um dado muda de finalidade? Por que “estar público” não esgota a análise de contexto?", debate: "Que expectativas sociais acompanham uma publicação?", privacyChain: ["Processamento de Informações:Agregação", "Processamento de Informações:Uso Secundário", "Disseminação de Informações:Aumento da Acessibilidade"], source: sources.meta, choices: [
    { id: "purpose", label: "Preservar a finalidade", detail: "Distinguir convivência, publicidade e treinamento de modelos.", protection: "Transparência e procedimentos", next: "pa-1" },
    { id: "oppose", label: "Tornar a oposição possível", detail: "Oferecer informação clara e controles simples, inclusive para menores.", protection: "Participação e resiliência", next: "pa-1" },
  ] },

  { id: "pa-1", phase: "pathogenic", kicker: "Zona de tensão · práticas e danos", title: "Quando a prática produz o dano", scenario: "A FTC descreveu promessas de controle incompatíveis com a circulação efetiva dos dados. A vulnerabilidade não está apenas no contexto: é produzida pela prática institucional.", investigation: "Qual prática transforma um risco possível em dano? Que evidência seria necessária para demonstrá-lo?", debate: "Quem deve comprovar o dano quando só a instituição conhece o fluxo dos dados?", privacyChain: ["Processamento de Informações:Uso Secundário", "Disseminação de Informações:Violação de Confidencialidade"], source: sources.facebook, choices: [
    { id: "evidence", label: "Produzir evidências auditáveis", detail: "Registrar fluxos e permitir avaliação independente.", protection: "Transparência e procedimentos", next: "pa-2a" },
    { id: "repair", label: "Reparar e transformar", detail: "Combinar responsabilização, mudança de prática e reparação coletiva.", protection: "Reparação coletiva", next: "pa-2b" },
  ] },
  { id: "pa-2a", phase: "pathogenic", kicker: "Vulnerabilidade invisível · amplificação", title: "O que o sistema faz com a violência?", scenario: "Uma plataforma pode ampliar alcance e repetição de conteúdos lesivos por meio de recomendações e métricas. Esta parada não presume discurso de ódio: a dupla só usa OntoHate se houver alvo, marcador protegido e proposição odienta identificáveis.", investigation: "O dano vem só da mensagem inicial ou também da amplificação? Distinguir ofensa, assédio, desinformação e discurso de ódio.", debate: "Como moderar sem apagar denúncias, testemunhos ou contra-discursos?", sensitive: true, hateCase: true, privacyChain: ["Disseminação de Informações:Divulgação", "Disseminação de Informações:Distorção"], source: sources.x, choices: [
    { id: "moderate", label: "Moderar com contexto", detail: "Examinar alvo, proposição, estratégia, alcance e consequência.", protection: "Procedimentos e participação", next: "ar-1" },
    { id: "amplify", label: "Interromper a amplificação", detail: "Rever recomendação e métricas sem depender apenas de remover conteúdo.", protection: "Interdição e reparação coletiva", next: "ar-1" },
  ] },
  { id: "pa-2b", phase: "pathogenic", kicker: "Vulnerabilidade invisível · oposição", title: "O obstáculo também causa dano?", scenario: "No caso Meta e IA, a autoridade apontou informação inadequada e obstáculos excessivos para oposição. A análise agora se concentra no efeito da própria barreira institucional.", investigation: "Que dano nasce quando exercer um direito exige tempo, leitura técnica ou passos difíceis de localizar?", debate: "Um direito existe na prática se seu exercício for excessivamente difícil?", privacyChain: ["Processamento de Informações:Exclusão [verificar definição na fonte]", "Invasão:Interferência Decisória"], source: sources.meta, choices: [
    { id: "barrier", label: "Remover a barreira", detail: "Simplificar a oposição e medir se pessoas conseguem concluí-la.", protection: "Procedimentos e resiliência", next: "ar-1" },
    { id: "accountability", label: "Deslocar o ônus", detail: "Exigir que a instituição demonstre proteção, em vez de transferir tudo ao titular.", protection: "Transparência e reparação coletiva", next: "ar-1" },
  ] },

  { id: "ar-1", phase: "architectural", kicker: "Infraestrutura · regras e interfaces", title: "A interface organiza a escolha", scenario: "A Comissão Europeia examinou o desenho da verificação azul e barreiras de transparência no X. A arquitetura pode induzir interpretações e dificultar escolhas livres e informadas.", investigation: "Que elemento visual parece neutro, mas distribui confiança e visibilidade? Como pesquisar o problema se os dados ficam inacessíveis?", debate: "Que mudança de arquitetura protegeria sem apenas orientar usuários a “prestar atenção”?", privacyChain: ["Processamento de Informações:Agregação", "Disseminação de Informações:Distorção"], source: sources.x, choices: [
    { id: "redesign", label: "Redesenhar sinais e acessos", detail: "Separar pagamento, identidade e credibilidade; ampliar transparência.", protection: "Transparência e procedimentos", next: "ar-2a" },
    { id: "audit", label: "Abrir à avaliação", detail: "Permitir pesquisa independente e auditoria dos efeitos sistêmicos.", protection: "Participação e transparência", next: "ar-2b" },
  ] },
  { id: "ar-2a", phase: "architectural", kicker: "Vulnerabilidade invisível · padrões", title: "A configuração como estrutura de poder", scenario: "O caso TikTok permite investigar padrões, dark patterns e informação destinada a crianças como elementos de arquitetura, não como falhas de atenção dos usuários.", investigation: "O que acontece se ninguém alterar nada? Quem se beneficia do padrão e quem suporta seus custos?", debate: "Como uma configuração padrão distribui risco em escala coletiva?", privacyChain: ["Disseminação de Informações:Exposição", "Processamento de Informações:Exclusão [verificar definição na fonte]"], source: sources.tiktok, choices: [
    { id: "protective", label: "Proteção por padrão", detail: "Privacidade e segurança desde a concepção, verificadas em uso real.", protection: "Procedimentos e resiliência", next: "pr-1" },
    { id: "governance", label: "Governança participativa", detail: "Incluir crianças, adolescentes e educadores na avaliação de padrões.", protection: "Participação e transparência", next: "pr-1" },
  ] },
  { id: "ar-2b", phase: "architectural", kicker: "Vulnerabilidade invisível · escala de IA", title: "Quando o treinamento muda a estrutura", scenario: "A coleta em escala para IA transforma publicações em matéria-prima para outro sistema. A análise arquitetural pergunta como finalidades, oposição e responsabilidade foram incorporadas ao desenho.", investigation: "Que relação entre plataforma, modelo e pessoas desaparece quando o dado é descrito apenas como “público”?", debate: "Que partes dessa arquitetura precisam ser alteradas para reduzir a vulnerabilidade?", privacyChain: ["Processamento de Informações:Agregação", "Processamento de Informações:Uso Secundário", "Disseminação de Informações:Aumento da Acessibilidade"], source: sources.meta, choices: [
    { id: "separate", label: "Separar finalidades", detail: "Reprojetar coleta, oposição e documentação para cada uso.", protection: "Transparência e procedimentos", next: "pr-1" },
    { id: "rights", label: "Direitos por arquitetura", detail: "Integrar proteção de menores e canais de contestação ao sistema.", protection: "Participação e reparação coletiva", next: "pr-1" },
  ] },

  { id: "pr-1", phase: "protection", kicker: "Síntese final · imunidade coletiva", title: "Que mundo digital a turma constrói?", scenario: "As duplas reúnem o que descobriram. O objetivo não é eliminar a vulnerabilidade inerente nem declarar vencedores, mas combinar respostas que reduzam danos situacionais, patogênicos e arquiteturais.", investigation: "Qual proteção continua funcionando mesmo quando uma pessoa está cansada, com pouco tempo ou sem conhecimento técnico?", debate: "Que compromisso coletivo pode ser levado para a escola e para as plataformas?", privacyChain: [], source: { label: "Síntese pedagógica · construída pela turma", url: "", note: "Não há caso externo nesta parada. A síntese combina as classificações e propostas produzidas pelas duplas." }, choices: [
    { id: "resilience", label: "Resiliência sem culpabilização", detail: "Apoio, competências e redes de cuidado que não transferem toda a responsabilidade ao indivíduo.", protection: "Resiliência + participação", next: null },
    { id: "institutional", label: "Mudança institucional", detail: "Transparência, procedimentos, desenho protetivo e reparação coletiva.", protection: "Transparência + reparação coletiva", next: null },
  ] },
];

export const stopById = Object.fromEntries(stops.map((stop) => [stop.id, stop]));
export const phaseById = Object.fromEntries(phases.map((phase) => [phase.id, phase]));

export type AvatarVisual = {
  skin: string;
  skinShade: string;
  hair: string;
  hairStyle: "waves" | "senior" | "afro" | "curls" | "headwrap" | "locs" | "bob" | "crop" | "braid" | "bun" | "twists" | "ponytail";
  outfit: string;
  outfitAccent: string;
  ageGroup: "child" | "teen" | "adult" | "older";
  pose: "open" | "confident" | "care";
};

export type AvatarPersona = {
  id: string; name: string; age: number; territory: string; routine: string;
  color: string; accent: string; object: string; visual: AvatarVisual;
};

export const avatars: AvatarPersona[] = [
  { id: "aurora", name: "Aurora", age: 15, territory: "Cidade média do interior", routine: "Estuda no ensino médio e grava vídeos curtos com a turma.", color: "#FF8A66", accent: "#FFE0D5", object: "câmera", visual: { skin: "#B96F4F", skinShade: "#925039", hair: "#251D2A", hairStyle: "waves", outfit: "#EF6A4C", outfitAccent: "#FFD166", ageGroup: "teen", pose: "open" } },
  { id: "benedito", name: "Benedito", age: 68, territory: "Bairro urbano consolidado", routine: "Resolve serviços públicos e bancários pelo aplicativo.", color: "#55C5E9", accent: "#D9F4FC", object: "cédula", visual: { skin: "#704531", skinShade: "#523124", hair: "#F2F0E9", hairStyle: "senior", outfit: "#276B87", outfitAccent: "#BEE9E2", ageGroup: "older", pose: "open" } },
  { id: "camila", name: "Camila", age: 34, territory: "Periferia de capital", routine: "Entrega por plataforma, com rotas definidas por algoritmo.", color: "#D897FF", accent: "#F1DFFF", object: "rota", visual: { skin: "#4A2B25", skinShade: "#321C19", hair: "#17131B", hairStyle: "afro", outfit: "#7C3F98", outfitAccent: "#FFCB57", ageGroup: "adult", pose: "confident" } },
  { id: "davi", name: "Davi", age: 11, territory: "Litoral", routine: "Joga com amigos em plataformas com bate-papo.", color: "#54D6B5", accent: "#D7F8ED", object: "controle", visual: { skin: "#8E543A", skinShade: "#693B2B", hair: "#241A20", hairStyle: "curls", outfit: "#13806B", outfitAccent: "#9BE7C9", ageGroup: "child", pose: "open" } },
  { id: "eliana", name: "Eliana", age: 42, territory: "Zona rural", routine: "Vende em grupos de mensagem e usa crédito digital.", color: "#F0BD4E", accent: "#FFF0C9", object: "semente", visual: { skin: "#A86442", skinShade: "#7F452F", hair: "#302127", hairStyle: "headwrap", outfit: "#A56A16", outfitAccent: "#F8DA7E", ageGroup: "adult", pose: "open" } },
  { id: "felipe", name: "Felipe", age: 19, territory: "Capital", routine: "Universitário bolsista que usa IA generativa nos trabalhos.", color: "#7D9CFF", accent: "#E2E8FF", object: "livro", visual: { skin: "#6F422F", skinShade: "#4E2D22", hair: "#19151D", hairStyle: "locs", outfit: "#3455D1", outfitAccent: "#AFC4FF", ageGroup: "teen", pose: "open" } },
  { id: "graca", name: "Graça", age: 55, territory: "Cidade pequena", routine: "Professora que usa plataformas educacionais e grupos de famílias.", color: "#FF9078", accent: "#FFE4DC", object: "lousa", visual: { skin: "#C58560", skinShade: "#9C6248", hair: "#E4DFD7", hairStyle: "bob", outfit: "#B94F3A", outfitAccent: "#FFD2B8", ageGroup: "older", pose: "open" } },
  { id: "ariel", name: "Ariel", age: 27, territory: "Região de fronteira", routine: "Cria humor e lida com monetização e moderação.", color: "#55C5E9", accent: "#D9F4FC", object: "microfone", visual: { skin: "#B97855", skinShade: "#92553D", hair: "#173A4B", hairStyle: "crop", outfit: "#16738C", outfitAccent: "#6CE0D2", ageGroup: "adult", pose: "confident" } },
  { id: "iara", name: "Iara", age: 23, territory: "Comunidade ribeirinha", routine: "Conecta-se por satélite e representa a comunidade em reuniões.", color: "#D897FF", accent: "#F1DFFF", object: "antena", visual: { skin: "#9B5E40", skinShade: "#75412E", hair: "#211821", hairStyle: "braid", outfit: "#78458D", outfitAccent: "#64D8C0", ageGroup: "adult", pose: "confident" } },
  { id: "joana", name: "Joana", age: 38, territory: "Região metropolitana", routine: "Cuida de um familiar e usa serviços digitais de saúde.", color: "#54D6B5", accent: "#D7F8ED", object: "cuidado", visual: { skin: "#553126", skinShade: "#3C211B", hair: "#19141A", hairStyle: "bun", outfit: "#167967", outfitAccent: "#A6E8D4", ageGroup: "adult", pose: "care" } },
  { id: "kelvin", name: "Kelvin", age: 17, territory: "Bairro urbano", routine: "Modera voluntariamente um servidor de comunidade de jogos.", color: "#F0BD4E", accent: "#FFF0C9", object: "escudo", visual: { skin: "#633B2D", skinShade: "#45281F", hair: "#18151B", hairStyle: "twists", outfit: "#A66A13", outfitAccent: "#FFE08A", ageGroup: "teen", pose: "confident" } },
  { id: "marta", name: "Marta", age: 47, territory: "Cidade média", routine: "Opera caixa com ponto biométrico e câmeras no trabalho.", color: "#7D9CFF", accent: "#E2E8FF", object: "chave", visual: { skin: "#D49A78", skinShade: "#AC7357", hair: "#392830", hairStyle: "ponytail", outfit: "#3658BD", outfitAccent: "#B7C9FF", ageGroup: "adult", pose: "open" } },
];

export const avatarLayerFamilies = [
  { id: "context", label: "Contexto de vida", values: ["Moradia compartilhada e rotina de estudo", "Arranjo familiar com cuidado de outra pessoa", "Rotina entre trabalho, estudo e deslocamentos"] },
  { id: "access", label: "Acesso e infraestrutura", values: ["Aparelho próprio e conexão estável", "Aparelho compartilhado e dados móveis limitados", "Conexão comunitária e acesso alternado"] },
  { id: "skills", label: "Competências", values: ["Técnica em destaque · ética em desenvolvimento", "Estética em destaque · política em desenvolvimento", "Política em destaque · técnica em desenvolvimento"] },
  { id: "networks", label: "Redes e recursos", values: ["Apoio familiar e comunitário", "Apoio institucional e de colegas", "Apoio sindical e redes de solidariedade"] },
  { id: "practices", label: "Práticas digitais", values: ["Vídeos e mensagens ao longo do dia", "Jogos e fóruns no período noturno", "Serviços e plataformas em horários de pausa"] },
] as const;

const legacyAvatars: Record<string, string> = { orbita: "aurora", raiz: "eliana", faisca: "felipe", brisa: "iara", horizonte: "ariel", nevoa: "joana" };
export function avatarBaseId(id?: string | null) {
  const raw = id?.split(":")[0] || "aurora";
  return legacyAvatars[raw] || raw;
}
export function avatarPersonaById(id?: string | null) {
  return avatars.find((avatar) => avatar.id === avatarBaseId(id)) || avatars[0];
}
export function avatarLayerIndexes(id?: string | null) {
  const code = id?.split(":")[1] || "00000";
  return avatarLayerFamilies.map((_, index) => Math.min(2, Math.max(0, Number(code[index]) || 0)));
}
export function makeAvatarProfileId(baseId: string, layers: readonly number[]) {
  return `${baseId}:${avatarLayerFamilies.map((_, index) => Math.min(2, Math.max(0, layers[index] || 0))).join("")}`;
}
export function isAvatarProfileId(id: string) {
  const [base, code, extra] = id.split(":");
  return extra === undefined && avatars.some((avatar) => avatar.id === base) && /^[0-2]{5}$/.test(code || "");
}

export const optionSets = {
  source: [
    ["Inerente", "ontovuldig:Fonte_Inerente"], ["Situacional", "ontovuldig:Fonte_Situacional"], ["Patogênica", "ontovuldig:Fonte_Patogenica"], ["Arquitetural", "ontovuldig:Fonte_Arquitetural"], ["Não sei", "unknown"],
  ],
  type: [["Decisional", "ontovuldig:MC1_Tipo_Decisional"], ["Resultado", "ontovuldig:MC1_Tipo_Resultado"], ["Não sei", "unknown"]],
  intensity: [["Uma camada", "ontovuldig:MC1_Intensidade_Uma_Camada"], ["Camadas cumulativas", "ontovuldig:MC1_Intensidade_Camadas_Cumulativas"], ["Não sei", "unknown"]],
  scale: [["Individual", "ontovuldig:MC1_Escala_Individual"], ["Grupal", "ontovuldig:MC1_Escala_Grupal"], ["Coletivo", "ontovuldig:MC1_Escala_Coletivo"], ["Não sei", "unknown"]],
  origin: [["Natural", "ontovuldig:MC2_Origem_Natural"], ["Sociocultural", "ontovuldig:MC2_Origem_Sociocultural"], ["Socioeconômica", "ontovuldig:MC2_Origem_Socioeconomica"], ["Geopolítica", "ontovuldig:MC2_Origem_Geopolitica"], ["Material", "ontovuldig:MC2_Origem_Material"], ["Técnico-científica", "ontovuldig:MC2_Origem_Tecnico_Cientifica"], ["Não sei", "unknown"]],
  manifestation: [["Risco puro", "ontovuldig:MC3_Risco_Puro"], ["Risco-dano", "ontovuldig:MC3_Risk_Harm"], ["Dano demonstrável", "ontovuldig:MC3_Dano_Demonstravel"], ["Dano compensado", "ontovuldig:MC3_Dano_Compensado"], ["Não sei", "unknown"]],
  visibility: [["Visível", "ontovuldig:MC3_Visivel"], ["Parcialmente visível", "ontovuldig:MC3_Parcialmente_Visivel"], ["Invisível", "ontovuldig:MC3_Invisivel"], ["Não sei", "unknown"]],
  obstacle: [["Demonstrabilidade", "ontovuldig:MC4_Demonstrabilidade"], ["Compensabilidade", "ontovuldig:MC4_Compensabilidade"], ["Quantificabilidade", "ontovuldig:MC4_Quantificabilidade"], ["Alcance jurisdicional", "ontovuldig:MC4_Alcance_Jurisdicional"], ["Nenhum identificado", "none"], ["Não sei", "unknown"]],
  response: [["Resiliência", "ontovuldig:MC5_Resiliencia"], ["Transparência", "ontovuldig:MC5_Transparencia"], ["Participação", "ontovuldig:MC5_Participacao"], ["Procedimentos", "ontovuldig:MC5_Procedimentais"], ["Interdição", "ontovuldig:MC5_Interdicao"], ["Reparação coletiva", "ontovuldig:MC5_Reparacao_Coletiva"], ["Não sei", "unknown"]],
} as const;

export const privacyGroups = [
  { group: "Grupo I — Coleta de Informações", id: "privacy:I_Coleta", items: [["Vigilância", "privacy:Vigilancia"], ["Interrogatório", "privacy:Interrogatorio"]] },
  { group: "Grupo II — Processamento de Informações", id: "privacy:II_Processamento", items: [["Agregação", "privacy:Agregacao"], ["Identificação", "privacy:Identificacao"], ["Insegurança", "privacy:Inseguranca"], ["Uso Secundário", "privacy:Uso_Secundario"], ["Exclusão [verificar definição na fonte]", "privacy:Exclusao_VERIFICAR"]] },
  { group: "Grupo III — Disseminação de Informações", id: "privacy:III_Disseminacao", items: [["Violação de Confidencialidade", "privacy:Violacao_Confidencialidade"], ["Divulgação", "privacy:Divulgacao"], ["Exposição", "privacy:Exposicao"], ["Aumento da Acessibilidade", "privacy:Aumento_Acessibilidade"], ["Chantagem", "privacy:Chantagem"], ["Apropriação", "privacy:Apropriacao"], ["Distorção", "privacy:Distorcao"]] },
  { group: "Grupo IV — Invasão", id: "privacy:IV_Invasao", items: [["Intrusão", "privacy:Intrusao"], ["Interferência Decisória", "privacy:Interferencia_Decisoria"]] },
];

export const hateDimensions = [
  ["Núcleo", "ontohate:Nucleo"], ["Natureza", "ontohate:Natureza_principal"], ["Proposição odienta", "ontohate:Proposicao_odienta"], ["Manifestação", "ontohate:Manifestacao_explicita"], ["Estratégia discursiva", "ontohate:Estrategias_Discursivas"], ["Recurso / dispositivo", "ontohate:Dispositivo_odiador"], ["Motivação", "ontohate:Motivacao"], ["Contexto", "ontohate:Contexto"], ["Consequência / dano", "ontohate:Dano_provocado"], ["Moderação", "ontohate:Moderacao_humana"],
];

export const ontologyProvenance = {
  ontoVulDig: "OntovulDig · estrutura MC1–MC5 derivada do artigo Taxonomia de vulnerabilidades digitais · relações didáticas provisórias",
  ontoHate: "OntoHate · artefato público versão 1.0.2 · sem inferência OWL automática",
  privacy: "Vocabulário de problemas de privacidade fornecido pelo usuário · fonte bibliográfica e definição de Exclusão em verificação",
};
