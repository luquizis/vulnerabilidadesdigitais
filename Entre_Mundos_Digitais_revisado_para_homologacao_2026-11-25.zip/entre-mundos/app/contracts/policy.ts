export type Role = "user" | "researcher" | "curator" | "admin";
export type SessionStatus = "lobby" | "closed" | "active" | "finished";

export function canResearch(role: string) {
  return ["researcher", "curator", "admin"].includes(role);
}
export function canCurate(role: string) {
  return role === "curator" || role === "admin";
}
export function canJoin(status: SessionStatus, registrationOpen: boolean, count: number, capacity: number) {
  return status === "lobby" && registrationOpen && count < capacity;
}
export function mayTransition(from: SessionStatus, to: SessionStatus) {
  if (from === "finished") return false;
  return to === "finished" || (from === "lobby" && ["closed", "active"].includes(to)) ||
    (from === "closed" && ["lobby", "active"].includes(to));
}

export type ReviewSignal = "contact" | "identifier" | "sensitive_context" | "potentially_offensive";
// Signals request human attention. No signal decides publication or diagnoses hate speech.
export function reviewSignals(value: string | null | undefined): ReviewSignal[] {
  if (!value) return [];
  const signals: ReviewSignal[] = [];
  if (/[\w.+-]+@[\w.-]+\.[a-z]{2,}|(?:\+?\d[\s().-]*){8,}|(?:https?:\/\/|www\.)\S+|@[\p{L}\d_.]{3,}/iu.test(value)) signals.push("contact");
  if (/\b(?:cpf|rg|telefone|endere[çc]o|senha|meu nome|nome dele|nome dela)\b|\b\d{3}\.\d{3}\.\d{3}-\d{2}\b/iu.test(value)) signals.push("identifier");
  if (/\b(?:suic[ií]dio|abuso|amea[çc]a|viol[eê]ncia|persegui[çc][aã]o|den[uú]ncia|discrimin|racis|homofob|transfob)/iu.test(value)) signals.push("sensitive_context");
  if (/\b(?:porra|caralho|merda|fdp|filh[oa]s?\s+da\s+puta|retardad[oa]s?|seu\s+lixo|vai\s+tomar\s+no\s+cu)\b/iu.test(value)) signals.push("potentially_offensive");
  return signals;
}

export function parseCursor(value: string | null | undefined) {
  const number = Number(value || 0);
  if (!Number.isSafeInteger(number) || number < 0) throw new Error("Cursor inválido.");
  return number;
}

export function publicEvent(type: string, role: "projection" | "team" | "mediator", payload: Record<string, unknown>) {
  // Every audience gets invalidations only, never free text or moderation details.
  if (role === "mediator") return { type, payload: {} };
  const isPrivate = ["response_recorded", "stop_skipped", "moderation_decided", "moderation_batch_decided"].includes(type);
  if (role === "team" && isPrivate) return { type: "state_changed", payload: {} };
  void payload;
  return { type: "projection_changed", payload: {} };
}
