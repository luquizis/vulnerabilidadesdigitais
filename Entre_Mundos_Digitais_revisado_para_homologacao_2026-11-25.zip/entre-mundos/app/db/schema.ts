import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  mediumtext,
  timestamp,
  bigint,
  int,
  boolean,
  uniqueIndex,
  index,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin", "researcher", "curator"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

// A content-addressed snapshot contains exactly the supplied labels, narratives and choices.
export const taxonomyVersions = mysqlTable("taxonomy_versions", {
  id: serial("id").primaryKey(),
  digest: varchar("digest", { length: 64 }).notNull().unique(),
  snapshot: mediumtext("snapshot").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const gameSessions = mysqlTable("game_sessions", {
  id: serial("id").primaryKey(),
  publicCode: varchar("public_code", { length: 8 }).notNull().unique(),
  mediatorKeyHash: varchar("mediator_key_hash", { length: 64 }).notNull(),
  title: varchar("title", { length: 120 }).notNull(),
  status: mysqlEnum("status", ["lobby", "active", "finished", "closed"]).default("lobby").notNull(),
  registrationOpen: boolean("registration_open").default(true).notNull(),
  capacity: int("capacity").default(40).notNull(),
  contentVersionId: bigint("content_version_id", { mode: "number", unsigned: true }).references(() => taxonomyVersions.id),
  currentStopId: varchar("current_stop_id", { length: 80 }),
  visibility: mysqlEnum("visibility", ["reserved", "open", "debate"]).default("reserved").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const teams = mysqlTable("teams", {
  id: serial("id").primaryKey(),
  sessionId: bigint("session_id", { mode: "number", unsigned: true }).notNull().references(() => gameSessions.id),
  pairTokenHash: varchar("pair_token_hash", { length: 64 }).notNull(),
  joinKeyHash: varchar("join_key_hash", { length: 64 }),
  lastSeenAt: timestamp("last_seen_at"),
  name: varchar("name", { length: 40 }).notNull(),
  avatarId: varchar("avatar_id", { length: 40 }),
  currentStopId: varchar("current_stop_id", { length: 80 }).default("in-1").notNull(),
  completedStopIds: text("completed_stop_ids").notNull(),
  immunity: int("immunity").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  tokenIdx: index("team_token_idx").on(table.pairTokenHash),
  sessionIdx: index("team_session_idx").on(table.sessionId),
  joinUnique: uniqueIndex("team_join_unique").on(table.sessionId, table.joinKeyHash),
}));

export const responses = mysqlTable("responses", {
  id: serial("id").primaryKey(),
  sessionId: bigint("session_id", { mode: "number", unsigned: true }).notNull().references(() => gameSessions.id),
  teamId: bigint("team_id", { mode: "number", unsigned: true }).notNull().references(() => teams.id),
  stopId: varchar("stop_id", { length: 80 }).notNull(),
  idempotencyKey: varchar("idempotency_key", { length: 80 }).notNull().unique(),
  choiceId: varchar("choice_id", { length: 80 }),
  nextStopId: varchar("next_stop_id", { length: 80 }),
  visibilityAtSubmit: varchar("visibility_at_submit", { length: 30 }),
  contributionKind: mysqlEnum("contribution_kind", ["agreement", "contestation", "proposal", "unspecified"]).default("unspecified").notNull(),
  sourceClassification: varchar("source_classification", { length: 40 }),
  ontoType: varchar("onto_type", { length: 40 }),
  ontoIntensity: varchar("onto_intensity", { length: 80 }),
  ontoScale: varchar("onto_scale", { length: 40 }),
  ontoOrigin: varchar("onto_origin", { length: 60 }),
  ontoManifestation: varchar("onto_manifestation", { length: 60 }),
  ontoVisibility: varchar("onto_visibility", { length: 40 }),
  ontoObstacle: varchar("onto_obstacle", { length: 60 }),
  ontoResponse: varchar("onto_response", { length: 60 }),
  privacyGroup: varchar("privacy_group", { length: 60 }),
  privacyProblems: text("privacy_problems").notNull(),
  hiddenFactor: text("hidden_factor"),
  hiddenFactorUnknown: boolean("hidden_factor_unknown").default(false).notNull(),
  hateMapping: varchar("hate_mapping", { length: 30 }).default("none").notNull(),
  hateDimensions: text("hate_dimensions").notNull(),
  experience: varchar("experience", { length: 30 }),
  justification: text("justification"),
  contestation: text("contestation"),
  candidateConcept: varchar("candidate_concept", { length: 120 }),
  allowProjection: boolean("allow_projection").default(true).notNull(),
  skipped: boolean("skipped").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  responseTeamIdx: index("response_team_idx").on(table.teamId),
  responseSessionIdx: index("response_session_idx").on(table.sessionId),
  teamStopUnique: uniqueIndex("response_team_stop_unique").on(table.teamId, table.stopId),
}));

export const sessionEvents = mysqlTable("session_events", {
  id: serial("id").primaryKey(),
  sessionId: bigint("session_id", { mode: "number", unsigned: true }).notNull().references(() => gameSessions.id),
  seq: int("seq").notNull(),
  type: varchar("type", { length: 50 }).notNull(),
  payload: text("payload").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  sequenceUnique: uniqueIndex("session_sequence_unique").on(table.sessionId, table.seq),
}));

export const moderationItems = mysqlTable("moderation_items", {
  id: serial("id").primaryKey(),
  responseId: bigint("response_id", { mode: "number", unsigned: true }).notNull().unique().references(() => responses.id),
  sessionId: bigint("session_id", { mode: "number", unsigned: true }).notNull().references(() => gameSessions.id),
  status: mysqlEnum("status", ["pending", "approved", "rejected", "hidden", "revision_requested"]).default("pending").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const candidateConcepts = mysqlTable("candidate_concepts", {
  id: serial("id").primaryKey(),
  responseId: bigint("response_id", { mode: "number", unsigned: true }).notNull().references(() => responses.id),
  sessionId: bigint("session_id", { mode: "number", unsigned: true }).notNull().references(() => gameSessions.id),
  teamId: bigint("team_id", { mode: "number", unsigned: true }).notNull().references(() => teams.id),
  term: varchar("term", { length: 120 }).notNull(),
  definition: text("definition"),
  status: mysqlEnum("status", ["proposed", "accepted", "related", "setaside"]).default("proposed").notNull(),
  mappedClass: varchar("mapped_class", { length: 160 }),
  curatorNote: text("curator_note"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull().$onUpdate(() => new Date()),
});

export const sessionAccess = mysqlTable("session_access", {
  id: serial("id").primaryKey(),
  sessionId: bigint("session_id", { mode: "number", unsigned: true }).notNull().references(() => gameSessions.id),
  userId: bigint("user_id", { mode: "number", unsigned: true }).notNull().references(() => users.id),
  canCurate: boolean("can_curate").default(false).notNull(),
  canExport: boolean("can_export").default(false).notNull(),
  canReadExperience: boolean("can_read_experience").default(false).notNull(),
}, (table) => ({ accessUnique: uniqueIndex("session_access_unique").on(table.sessionId, table.userId) }));

export const reviewDecisions = mysqlTable("review_decisions", {
  id: serial("id").primaryKey(),
  sessionId: bigint("session_id", { mode: "number", unsigned: true }).notNull().references(() => gameSessions.id),
  responseId: bigint("response_id", { mode: "number", unsigned: true }).references(() => responses.id),
  actor: varchar("actor", { length: 100 }).notNull(),
  kind: mysqlEnum("kind", ["moderation", "curation", "legacy_pin", "access"]).notNull(),
  previousStatus: varchar("previous_status", { length: 40 }),
  decision: varchar("decision", { length: 40 }).notNull(),
  note: text("note"),
  mappedClass: varchar("mapped_class", { length: 160 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({ sessionIdx: index("review_session_idx").on(table.sessionId) }));

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type GameSession = typeof gameSessions.$inferSelect;
export type Team = typeof teams.$inferSelect;
export type ResponseRecord = typeof responses.$inferSelect;
