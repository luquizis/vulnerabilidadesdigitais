-- Executado pelo script scripts/migrate.mjs. Preserva todas as tabelas existentes.
CREATE TABLE IF NOT EXISTS taxonomy_versions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  digest VARCHAR(64) NOT NULL UNIQUE,
  snapshot MEDIUMTEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
-- statement-breakpoint
CREATE TABLE IF NOT EXISTS session_access (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  session_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  can_curate BOOLEAN NOT NULL DEFAULT FALSE,
  can_export BOOLEAN NOT NULL DEFAULT FALSE,
  can_read_experience BOOLEAN NOT NULL DEFAULT FALSE,
  UNIQUE KEY session_access_unique (session_id, user_id),
  FOREIGN KEY (session_id) REFERENCES game_sessions(id),
  FOREIGN KEY (user_id) REFERENCES users(id)
);
-- statement-breakpoint
CREATE TABLE IF NOT EXISTS review_decisions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  session_id BIGINT UNSIGNED NOT NULL,
  response_id BIGINT UNSIGNED NULL,
  actor VARCHAR(100) NOT NULL,
  kind ENUM('moderation','curation','legacy_pin','access') NOT NULL,
  previous_status VARCHAR(40) NULL,
  decision VARCHAR(40) NOT NULL,
  note TEXT NULL,
  mapped_class VARCHAR(160) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY review_session_idx (session_id),
  FOREIGN KEY (session_id) REFERENCES game_sessions(id),
  FOREIGN KEY (response_id) REFERENCES responses(id)
);
